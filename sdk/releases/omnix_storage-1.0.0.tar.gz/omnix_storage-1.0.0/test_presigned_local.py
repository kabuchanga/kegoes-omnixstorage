#!/usr/bin/env python3
"""
Test presigned URL signing without requiring live server connection.
This validates AWS SigV4 implementation locally.
"""

from datetime import datetime
from omnixstorage._signer import AwsSignatureV4Signer


def test_presigned_urls_locally():
    """Test presigned URL generation locally."""
    
    endpoint = "localhost:9000"
    access_key = "admin"
    secret_key = "password"
    bucket_name = "presigned-test-bucket-py"
    test_file_name = "test-file-py.txt"
    
    print("\n" + "="*70)
    print("PYTHON SDK PRESIGNED URL TEST - LOCAL VALIDATION")
    print("="*70)
    print(f"Target Host: http://{endpoint}")
    print(f"Access Key: {access_key}")
    print(f"Bucket: {bucket_name}")
    print("="*70 + "\n")
    
    try:
        # Step 1: Initialize signer
        print("✓ Step 1: Initializing AWS Signature V4 Signer...")
        signer = AwsSignatureV4Signer(access_key, secret_key)
        print(f"  Signer ready\n")
        
        # Step 2: Generate GET presigned URL
        print("✓ Step 2: Generating GET presigned URL...")
        timestamp = datetime(2026, 2, 8, 12, 0, 0)
        
        get_url = signer.generate_presigned_url(
            method="GET",
            host=endpoint,
            path=f"/s3/{bucket_name}/{test_file_name}",
            expires_in=3600,
            timestamp=timestamp
        )
        print(f"  GET URL:\n    {get_url}\n")
        
        # Step 3: Generate PUT presigned URL  
        print("✓ Step 3: Generating PUT presigned URL...")
        put_url = signer.generate_presigned_url(
            method="PUT",
            host=endpoint,
            path=f"/s3/{bucket_name}/test-put-file-py.txt",
            expires_in=3600,
            timestamp=timestamp
        )
        print(f"  PUT URL:\n    {put_url}\n")
        
        # Step 4: Analyze signatures
        print("✓ Step 4: Analyzing signatures...")
        get_sig = None
        put_sig = None
        
        if "X-Amz-Signature=" in get_url:
            sig_start = get_url.find("X-Amz-Signature=") + len("X-Amz-Signature=")
            sig_end = get_url.find("&", sig_start) if "&" in get_url[sig_start:] else len(get_url)
            get_sig = get_url[sig_start:sig_end]
            print(f"  GET Signature: {get_sig}")
        
        if "X-Amz-Signature=" in put_url:
            sig_start = put_url.find("X-Amz-Signature=") + len("X-Amz-Signature=")
            sig_end = put_url.find("&", sig_start) if "&" in put_url[sig_start:] else len(put_url)
            put_sig = put_url[sig_start:sig_end]
            print(f"  PUT Signature: {put_sig}")
        
        if get_sig and put_sig:
            if get_sig != put_sig:
                print(f"  ✓ Signatures are different (method-specific): CORRECT\n")
            else:
                print(f"  ✗ Signatures are identical (should be different)\n")
        
        # Step 5: Verify URL components
        print("✓ Step 5: Verifying AWS SigV4 components...")
        required_components = [
            "X-Amz-Algorithm=AWS4-HMAC-SHA256",
            "X-Amz-Credential=",
            "X-Amz-Date=",
            "X-Amz-Expires=",
            "X-Amz-Signature=",
            "X-Amz-SignedHeaders="
        ]
        
        all_present = True
        for component in required_components:
            if component in get_url:
                print(f"  ✓ {component.split('=')[0]}: Present")
            else:
                print(f"  ✗ {component.split('=')[0]}: Missing")
                all_present = False
        
        if all_present:
            print("\n  ✓ All AWS SigV4 components present\n")
        
        # Step 6: Verify credential scope
        print("✓ Step 6: Verifying credential scope...")
        if "X-Amz-Credential=" in get_url:
            cred_start = get_url.find("X-Amz-Credential=") + len("X-Amz-Credential=")
            cred_end = get_url.find("&", cred_start) if "&" in get_url[cred_start:] else len(get_url)
            credential = get_url[cred_start:cred_end]
            print(f"  Credential: {credential}")
            
            # Verify format: accessKey/date/region/service/aws4_request
            parts = credential.split("/")
            if len(parts) == 5:
                print(f"    - Access Key: {parts[0]}")
                print(f"    - Date: {parts[1]}")
                print(f"    - Region: {parts[2]}")
                print(f"    - Service: {parts[3]}")
                print(f"    - Request Type: {parts[4]}")
                
                if parts[0] == access_key and parts[2] == "us-east-1" and parts[3] == "s3":
                    print("    ✓ Credential scope is correct\n")
            else:
                print(f"    ✗ Invalid credential format\n")
        
        # Step 7: Test signing with different timestamps
        print("✓ Step 7: Testing timestamp sensitivity...")
        timestamp2 = datetime(2026, 2, 8, 12, 0, 1)  # 1 second later
        
        get_url_2 = signer.generate_presigned_url(
            method="GET",
            host=endpoint,
            path=f"/s3/{bucket_name}/{test_file_name}",
            expires_in=3600,
            timestamp=timestamp2
        )
        
        if "X-Amz-Signature=" in get_url_2:
            sig_start_2 = get_url_2.find("X-Amz-Signature=") + len("X-Amz-Signature=")
            sig_end_2 = get_url_2.find("&", sig_start_2) if "&" in get_url_2[sig_start_2:] else len(get_url_2)
            get_sig_2 = get_url_2[sig_start_2:sig_end_2]
        
        if get_sig != get_sig_2:
            print(f"  ✓ Different timestamps produce different signatures: CORRECT\n")
        else:
            print(f"  ✗ Same signature for different timestamps\n")
        
        # Step 8: Test signing with different methods
        print("✓ Step 8: Testing method-specific signing...")
        delete_url = signer.generate_presigned_url(
            method="DELETE",
            host=endpoint,
            path=f"/s3/{bucket_name}/{test_file_name}",
            expires_in=3600,
            timestamp=timestamp
        )
        
        if "X-Amz-Signature=" in delete_url:
            sig_start_d = delete_url.find("X-Amz-Signature=") + len("X-Amz-Signature=")
            sig_end_d = delete_url.find("&", sig_start_d) if "&" in delete_url[sig_start_d:] else len(delete_url)
            delete_sig = delete_url[sig_start_d:sig_end_d]
        
        if get_sig != delete_sig and put_sig != delete_sig:
            print(f"  ✓ GET, PUT, and DELETE have different signatures: CORRECT\n")
        else:
            print(f"  ✗ Signatures not unique per method\n")
        
        # Summary
        print("="*70)
        print("✅ PYTHON SDK PRESIGNED URL VALIDATION COMPLETE")
        print("="*70)
        print("Summary:")
        print("  ✓ AWS SigV4 signing implementation verified")
        print("  ✓ Presigned URLs generated successfully")
        print("  ✓ Method-specific signatures working")
        print("  ✓ Timestamp sensitivity verified")
        print("  ✓ Credential scope correct")
        print("  ✓ All AWS SigV4 components present")
        print("="*70 + "\n")
        
    except Exception as e:
        print(f"\n❌ ERROR: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    test_presigned_urls_locally()
