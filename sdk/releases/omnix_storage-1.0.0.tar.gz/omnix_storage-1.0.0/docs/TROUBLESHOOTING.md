# OmnixStorage Python SDK - Troubleshooting Guide

Common issues and solutions when using the OmnixStorage Python SDK.

## Table of Contents

1. [Connection Issues](#connection-issues)
2. [Authentication Issues](#authentication-issues)
3. [Bucket Operations](#bucket-operations)
4. [Object Operations](#object-operations)
5. [Performance Issues](#performance-issues)
6. [Async/Await Issues](#asyncawait-issues)
7. [Network Issues](#network-issues)

## Connection Issues

### Connection Refused

**Problem:** `ConnectionRefusedError` or connection timeout

**Possible Causes:**
- OmnixStorage server is not running
- Wrong endpoint address or port
- Firewall blocking the connection
- Network connectivity issues

**Solutions:**

1. **Verify server is running:**
   ```bash
   # Check if server is listening on the port
   netstat -an | grep 9000
   telnet localhost 9000
   ```

2. **Verify endpoint configuration:**
   ```python
   client = OmnixClient(
       endpoint="localhost:9000",  # Correct format: host:port
       access_key="admin",
       secret_key="password"
   )
   ```

3. **Check firewall:**
   ```bash
   # Linux
   sudo ufw allow 9000
   
   # Windows (PowerShell as admin)
   netsh advfirewall firewall add rule name="OmnixStorage" dir=in action=allow protocol=tcp localport=9000
   ```

4. **Test connectivity:**
   ```bash
   ping <server-address>
   curl http://localhost:9000/api/health
   ```

### Timeout Errors

**Problem:** `asyncio.TimeoutError` or request timeout

**Solutions:**

1. **Increase timeout:**
   ```python
   client = OmnixClient(
       endpoint="localhost:9000",
       access_key="admin",
       secret_key="password",
       request_timeout=60  # Increase to 60 seconds
   )
   ```

2. **Check network latency:**
   ```bash
   ping <server-address>
   # Look for round-trip time (RTT)
   ```

3. **Check server load:**
   - Monitor server CPU and memory usage
   - Check server logs for issues
   - Check network bandwidth

## Authentication Issues

### Authentication Failed

**Problem:** `AuthenticationException: Failed to authenticate with the server`

**Solutions:**

1. **Verify credentials:**
   ```python
   # Make sure access_key and secret_key are correct
   client = OmnixClient(
       endpoint="localhost:9000",
       access_key="correct-access-key",  # Check this
       secret_key="correct-secret-key"   # Check this
   )
   ```

2. **Check server logs:**
   ```bash
   # Look for authentication-related errors
   docker logs <container-name>
   tail -f /var/log/omnix/auth.log
   ```

3. **Verify user exists:**
   - Check if the user account is created on the server
   - Verify user permissions
   - Check if user is active/not locked

### Invalid Credentials

**Problem:** `AuthenticationException: No token in authentication response`

**Solutions:**

1. **Verify endpoint:**
   ```python
   # Make sure /api/admin/login endpoint is available
   # Test with curl:
   curl -X POST http://localhost:9000/api/admin/login \
     -H "Content-Type: application/json" \
     -d '{"AccessKey":"admin","SecretKey":"password"}'
   ```

2. **Check server configuration:**
   - Verify authentication is enabled
   - Check if JWT token service is running
   - Verify token signing keys

## Bucket Operations

### Bucket Already Exists

**Problem:** `ServerException: Bucket already exists`

**Solution:**

```python
# Check if bucket exists before creating
if not await client.bucket_exists("my-bucket"):
    await client.make_bucket("my-bucket")
else:
    print("Bucket already exists")
```

### Bucket Not Found

**Problem:** `BucketNotFoundException: Bucket 'xxx' not found`

**Solution:**

```python
# Check if bucket exists
if await client.bucket_exists("my-bucket"):
    # Proceed with operations
else:
    print("Bucket does not exist, creating it...")
    await client.make_bucket("my-bucket")
```

### Cannot Remove Non-Empty Bucket

**Problem:** `ServerException: Bucket is not empty`

**Solution:**

```python
# Delete all objects first
result = await client.list_objects("my-bucket")
for obj in result.objects:
    await client.remove_object("my-bucket", obj.name)

# Now remove the bucket
await client.remove_bucket("my-bucket")
```

## Object Operations

### Object Not Found

**Problem:** `ObjectNotFoundException: Object 'xxx' not found`

**Solution:**

```python
# Check if object exists before accessing
try:
    metadata = await client.stat_object("my-bucket", "my-file.txt")
except ObjectNotFoundException:
    print("Object does not exist")
    # Handle accordingly
```

### Upload Large Files

**Problem:** Memory usage or slow uploads

**Solutions:**

1. **Stream large files:**
   ```python
   # Good: streaming
   with open("large-file.bin", "rb") as f:
       await client.put_object(
           bucket_name="my-bucket",
           object_name="large-file.bin",
           data=f
       )
   
   # Bad: loading entire file into memory
   data = open("large-file.bin", "rb").read()  # Don't do this
   ```

2. **Monitor upload progress:**
   ```python
   import os
   file_size = os.path.getsize("large-file.bin")
   
   with open("large-file.bin", "rb") as f:
       result = await client.put_object(
           bucket_name="my-bucket",
           object_name="large-file.bin",
           data=f,
           length=file_size
       )
   ```

### Special Characters in Object Names

**Problem:** Invalid object names with special characters

**Solutions:**

```python
from urllib.parse import quote

# Properly encode special characters
object_name = quote("my file (2024).txt", safe="")
# Results in: "my%20file%20%282024%29.txt"

await client.put_object(
    bucket_name="my-bucket",
    object_name=object_name,
    data=f
)
```

## Performance Issues

### Slow Uploads/Downloads

**Problem:** Poor upload/download performance

**Solutions:**

1. **Increase request timeout:**
   ```python
   client = OmnixClient(
       endpoint="localhost:9000",
       access_key="admin",
       secret_key="password",
       request_timeout=120  # Increase timeout
   )
   ```

2. **Use batch operations:**
   ```python
   import asyncio
   
   tasks = [
       client.put_object(bucket_name, obj_name, data_file)
       for obj_name, data_file in files.items()
   ]
   results = await asyncio.gather(*tasks)
   ```

3. **Check network:**
   ```bash
   # Check bandwidth
   iperf3 -c <server-address>
   
   # Check latency
   ping -c 10 <server-address>
   ```

4. **Monitor system resources:**
   ```bash
   # CPU and memory usage
   top -b -n 1 | head -20
   
   # Disk I/O
   iostat -x 1 5
   ```

### Memory Leaks

**Problem:** Increasing memory usage over time

**Solutions:**

1. **Always close the client:**
   ```python
   # Good: using context manager
   async with OmnixClient(...) as client:
       # Operations...
   
   # Good: manual cleanup
   client = OmnixClient(...)
   try:
       # Operations...
   finally:
       await client.close()
   ```

2. **Don't keep file handles open:**
   ```python
   # Good: close file immediately
   with open("file.txt", "rb") as f:
       await client.put_object(..., data=f)
   # File is closed here
   
   # Bad: keep file open
   f = open("file.txt", "rb")
   await client.put_object(..., data=f)
   # File is not closed!
   ```

## Async/Await Issues

### RuntimeError: asyncio.run() cannot be called from a running event loop

**Problem:** Calling `asyncio.run()` from within an async context

**Solution:**

```python
# Wrong: nested asyncio.run()
async def outer():
    asyncio.run(inner())  # Error!

async def inner():
    pass

# Correct: direct await
async def outer():
    await inner()

async def inner():
    pass

asyncio.run(outer())
```

### Task Not Awaited

**Problem:** `RuntimeWarning: coroutine was never awaited`

**Solution:**

```python
# Wrong: forgot to await
async def main():
    client.put_object("bucket", "object", f)  # Missing await!

# Correct: include await
async def main():
    await client.put_object("bucket", "object", f)
```

### Gathering Multiple Tasks

**Problem:** Running concurrent operations

**Solution:**

```python
import asyncio

async def main():
    # Wrong: these run sequentially
    await client.put_object("bucket", "obj1", f1)
    await client.put_object("bucket", "obj2", f2)
    
    # Correct: these run concurrently
    await asyncio.gather(
        client.put_object("bucket", "obj1", f1),
        client.put_object("bucket", "obj2", f2)
    )
```

## Network Issues

### SSL/TLS Certificate Errors

**Problem:** SSL certificate verification failures

**Solutions:**

1. **Use proper HTTPS:**
   ```python
   client = OmnixClient(
       endpoint="omnix.example.com:9000",
       access_key="admin",
       secret_key="password",
       use_ssl=True
   )
   ```

2. **For self-signed certificates (development only):**
   ```python
   import httpx
   
   # Create a session with certificate verification disabled
   # Note: This is not secure and should only be used for development
   client = OmnixClient(
       endpoint="omnix.example.com:9000",
       access_key="admin",
       secret_key="password",
       use_ssl=True
   )
   # Configure httpx client if needed
   ```

### DNS Resolution Errors

**Problem:** Cannot resolve hostname

**Solutions:**

1. **Check DNS configuration:**
   ```bash
   nslookup omnix.example.com
   dig omnix.example.com
   ```

2. **Use IP address instead:**
   ```python
   client = OmnixClient(
       endpoint="192.168.1.100:9000",  # Use IP directly
       access_key="admin",
       secret_key="password"
   )
   ```

3. **Check /etc/hosts:**
   ```bash
   # Add entry for testing
   echo "192.168.1.100 omnix.example.com" | sudo tee -a /etc/hosts
   ```

### Proxy Issues

**Problem:** Cannot connect through proxy

**Solution:**

```python
# The SDK uses httpx which respects environment variables
import os

os.environ['HTTP_PROXY'] = 'http://proxy.example.com:8080'
os.environ['HTTPS_PROXY'] = 'https://proxy.example.com:8080'

client = OmnixClient(
    endpoint="omnix.example.com:9000",
    access_key="admin",
    secret_key="password"
)
```

## Getting Help

If you encounter issues not covered here:

1. **Check the logs:**
   - Client logs: Enable debug logging
   - Server logs: Check OmnixStorage server logs
   - System logs: Check OS logs for network issues

2. **Enable debug output:**
   ```python
   import logging
   logging.basicConfig(level=logging.DEBUG)
   
   # Your code here
   ```

3. **Report the issue:**
   - GitHub Issues: https://github.com/kegeo-solutions/omnix-storage-py/issues
   - Email: support@kegeo.com
   - Include:
     - Python version
     - SDK version
     - Server version
     - Full error traceback
     - Minimal reproducible example

4. **Documentation:**
   - [API Reference](./API_REFERENCE.md)
   - [Examples](../examples/)
   - [README](../README.md)

## See Also

- [API Reference](./API_REFERENCE.md)
- [Examples](../examples/)
- [README](../README.md)
