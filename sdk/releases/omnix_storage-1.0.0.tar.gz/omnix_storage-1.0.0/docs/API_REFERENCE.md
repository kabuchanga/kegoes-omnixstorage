# OmnixStorage Python SDK - API Reference

Complete API reference for the OmnixStorage Python SDK.

## Table of Contents

1. [OmnixClient](#omnixclient)
2. [Bucket Operations](#bucket-operations)
3. [Object Operations](#object-operations)
4. [Data Models](#data-models)
5. [Exceptions](#exceptions)
6. [Async Context Manager](#async-context-manager)

## OmnixClient

Main client class for interacting with OmnixStorage.

### Constructor

```python
OmnixClient(
    endpoint: str = "localhost:9000",
    access_key: str = "",
    secret_key: str = "",
    use_ssl: bool = False,
    request_timeout: int = 30,
    max_retries: int = 3,
)
```

**Parameters:**
- `endpoint` (str): Server address and port (e.g., "omnix.example.com:9000")
- `access_key` (str): Access key for authentication
- `secret_key` (str): Secret key for authentication
- `use_ssl` (bool): Use HTTPS instead of HTTP (default: False)
- `request_timeout` (int): Request timeout in seconds (default: 30)
- `max_retries` (int): Maximum number of retries for failed requests (default: 3)

**Example:**
```python
client = OmnixClient(
    endpoint="omnix.production.local:9000",
    access_key="admin",
    secret_key="password",
    use_ssl=True,
    request_timeout=60
)
```

### Methods

#### close()

Closes the client and releases resources.

```python
await client.close()
```

#### health()

Checks if the server is healthy and reachable.

```python
is_healthy: bool = await client.health()
```

**Returns:** `bool` - True if server is healthy, False otherwise

**Example:**
```python
if await client.health():
    print("Server is healthy")
else:
    print("Server is unavailable")
```

## Bucket Operations

### make_bucket()

Creates a new bucket.

```python
await client.make_bucket(bucket_name: str) -> None
```

**Parameters:**
- `bucket_name` (str): Name of the bucket to create

**Raises:** `ServerException` if bucket already exists or creation fails

**Example:**
```python
await client.make_bucket("my-bucket")
```

### bucket_exists()

Checks if a bucket exists.

```python
exists: bool = await client.bucket_exists(bucket_name: str)
```

**Parameters:**
- `bucket_name` (str): Name of the bucket to check

**Returns:** `bool` - True if bucket exists, False otherwise

**Example:**
```python
if await client.bucket_exists("my-bucket"):
    print("Bucket exists")
```

### remove_bucket()

Removes an empty bucket.

```python
await client.remove_bucket(bucket_name: str) -> None
```

**Parameters:**
- `bucket_name` (str): Name of the bucket to remove

**Raises:** `ServerException` if bucket doesn't exist or is not empty

**Example:**
```python
await client.remove_bucket("my-bucket")
```

### list_buckets()

Lists all buckets.

```python
buckets: List[Bucket] = await client.list_buckets()
```

**Returns:** `List[Bucket]` - List of all buckets

**Example:**
```python
buckets = await client.list_buckets()
for bucket in buckets:
    print(f"Bucket: {bucket.name} (created: {bucket.creation_date})")
```

## Object Operations

### put_object()

Uploads an object to a bucket.

```python
result: PutObjectResult = await client.put_object(
    bucket_name: str,
    object_name: str,
    data: BinaryIO,
    length: Optional[int] = None,
    content_type: str = "application/octet-stream",
    metadata: Optional[Dict[str, str]] = None,
) -> PutObjectResult
```

**Parameters:**
- `bucket_name` (str): Name of the bucket
- `object_name` (str): Name of the object (supports paths like "folder/file.txt")
- `data` (BinaryIO): File-like object to upload
- `length` (int, optional): Size of the data in bytes
- `content_type` (str): MIME type of the object (default: "application/octet-stream")
- `metadata` (Dict[str, str], optional): Custom metadata key-value pairs

**Returns:** `PutObjectResult` - Upload result with ETag

**Example:**
```python
with open("image.jpg", "rb") as f:
    result = await client.put_object(
        bucket_name="photos",
        object_name="archive/image.jpg",
        data=f,
        content_type="image/jpeg",
        metadata={"camera": "canon", "date": "2024-01-01"}
    )
    print(f"Uploaded with ETag: {result.etag}")
```

### get_object()

Downloads an object from a bucket.

```python
metadata: ObjectMetadata = await client.get_object(
    bucket_name: str,
    object_name: str,
    output: BinaryIO,
) -> ObjectMetadata
```

**Parameters:**
- `bucket_name` (str): Name of the bucket
- `object_name` (str): Name of the object
- `output` (BinaryIO): File-like object to write downloaded data to

**Returns:** `ObjectMetadata` - Object metadata

**Raises:** `ObjectNotFoundException` if object doesn't exist

**Example:**
```python
with open("downloaded.jpg", "wb") as f:
    metadata = await client.get_object(
        bucket_name="photos",
        object_name="archive/image.jpg",
        output=f
    )
    print(f"Downloaded: {metadata.name} ({metadata.size} bytes)")
```

### stat_object()

Gets object metadata without downloading.

```python
metadata: ObjectMetadata = await client.stat_object(
    bucket_name: str,
    object_name: str,
) -> ObjectMetadata
```

**Parameters:**
- `bucket_name` (str): Name of the bucket
- `object_name` (str): Name of the object

**Returns:** `ObjectMetadata` - Object metadata

**Raises:** `ObjectNotFoundException` if object doesn't exist

**Example:**
```python
metadata = await client.stat_object("photos", "archive/image.jpg")
print(f"Size: {metadata.size} bytes")
print(f"Type: {metadata.content_type}")
print(f"ETag: {metadata.etag}")
```

### remove_object()

Deletes an object from a bucket.

```python
await client.remove_object(
    bucket_name: str,
    object_name: str,
) -> None
```

**Parameters:**
- `bucket_name` (str): Name of the bucket
- `object_name` (str): Name of the object

**Example:**
```python
await client.remove_object("photos", "archive/image.jpg")
```

### list_objects()

Lists objects in a bucket with pagination support.

```python
result: ListObjectsResult = await client.list_objects(
    bucket_name: str,
    prefix: str = "",
    delimiter: str = "",
    max_keys: int = 1000,
    continuation_token: Optional[str] = None,
) -> ListObjectsResult
```

**Parameters:**
- `bucket_name` (str): Name of the bucket
- `prefix` (str): Filter objects by prefix
- `delimiter` (str): Group objects by delimiter (typically "/" for hierarchy)
- `max_keys` (int): Maximum number of objects to return (default: 1000)
- `continuation_token` (str, optional): Token for pagination

**Returns:** `ListObjectsResult` - List result with objects and pagination info

**Example:**
```python
# Simple listing
result = await client.list_objects("photos")
for obj in result.objects:
    print(f"- {obj.name} ({obj.size} bytes)")

# With prefix and pagination
result = await client.list_objects(
    bucket_name="photos",
    prefix="archive/",
    delimiter="/",
    max_keys=100
)

if result.is_truncated:
    next_page = await client.list_objects(
        bucket_name="photos",
        continuation_token=result.continuation_token
    )
```

### presigned_get_object()

Generates a presigned URL for downloading an object.

```python
presigned: PresignedUrlResult = await client.presigned_get_object(
    bucket_name: str,
    object_name: str,
    expires_in_seconds: int = 3600,
) -> PresignedUrlResult
```

**Parameters:**
- `bucket_name` (str): Name of the bucket
- `object_name` (str): Name of the object
- `expires_in_seconds` (int): URL validity duration in seconds (default: 3600)

**Returns:** `PresignedUrlResult` - Presigned URL and expiration time

**Example:**
```python
presigned = await client.presigned_get_object(
    bucket_name="photos",
    object_name="archive/image.jpg",
    expires_in_seconds=7200  # 2 hours
)
print(f"Share this URL: {presigned.url}")
print(f"Expires at: {presigned.expires_at}")
```

## Data Models

### Bucket

Represents a bucket in OmnixStorage.

```python
@dataclass
class Bucket:
    name: str
    creation_date: datetime
```

**Attributes:**
- `name` (str): Bucket name
- `creation_date` (datetime): When the bucket was created

### ObjectMetadata

Represents object metadata.

```python
@dataclass
class ObjectMetadata:
    name: str
    bucket_name: str
    size: int = 0
    etag: Optional[str] = None
    last_modified: Optional[datetime] = None
    content_type: Optional[str] = None
    metadata: Dict[str, str] = field(default_factory=dict)
```

**Attributes:**
- `name` (str): Object name
- `bucket_name` (str): Bucket containing the object
- `size` (int): Object size in bytes
- `etag` (str): Entity tag for version control
- `last_modified` (datetime): Last modification time
- `content_type` (str): MIME type
- `metadata` (Dict): Custom metadata

### ListObjectsResult

Result of a list objects operation.

```python
@dataclass
class ListObjectsResult:
    objects: List[ObjectMetadata] = field(default_factory=list)
    is_truncated: bool = False
    continuation_token: Optional[str] = None
    common_prefixes: List[str] = field(default_factory=list)
```

**Attributes:**
- `objects` (List): List of object metadata
- `is_truncated` (bool): Whether there are more results
- `continuation_token` (str): Token for getting next page
- `common_prefixes` (List): Common prefixes when using delimiter

### PutObjectResult

Result of a put object operation.

```python
@dataclass
class PutObjectResult:
    bucket_name: str
    object_name: str
    etag: str
    version_id: Optional[str] = None
```

**Attributes:**
- `bucket_name` (str): Target bucket
- `object_name` (str): Uploaded object name
- `etag` (str): Entity tag of uploaded object
- `version_id` (str): Version ID if versioning is enabled

### PresignedUrlResult

Presigned URL generation result.

```python
@dataclass
class PresignedUrlResult:
    url: str
    expires_at: datetime
```

**Attributes:**
- `url` (str): Presigned URL
- `expires_at` (datetime): When the URL expires

## Exceptions

All exceptions inherit from `OmnixStorageException`.

### OmnixStorageException

Base exception for all SDK errors.

```python
class OmnixStorageException(Exception):
    def __init__(
        self,
        message: str,
        status_code: int = None,
        error_code: str = None
    )
```

### BucketNotFoundException

Raised when a bucket is not found.

```python
except BucketNotFoundException:
    print("Bucket does not exist")
```

### ObjectNotFoundException

Raised when an object is not found.

```python
except ObjectNotFoundException:
    print("Object does not exist")
```

### BucketAlreadyExistsException

Raised when trying to create a bucket that already exists.

```python
except BucketAlreadyExistsException:
    print("Bucket already exists")
```

### AuthenticationException

Raised when authentication fails.

```python
except AuthenticationException:
    print("Invalid credentials")
```

### ServerException

Raised for server errors.

```python
except ServerException as e:
    print(f"Server error (status {e.status_code}): {e}")
```

### AccessDeniedException

Raised when access is denied.

```python
except AccessDeniedException:
    print("Access denied")
```

## Async Context Manager

The client can be used as an async context manager for automatic cleanup.

```python
async with OmnixClient(
    endpoint="localhost:9000",
    access_key="admin",
    secret_key="password"
) as client:
    buckets = await client.list_buckets()
    # Client is automatically closed here
```

## Complete Example

```python
import asyncio
from omnixstorage import OmnixClient
from omnixstorage.error import OmnixStorageException

async def main():
    async with OmnixClient(
        endpoint="omnix.example.com:9000",
        access_key="your-key",
        secret_key="your-secret"
    ) as client:
        try:
            # Create bucket
            await client.make_bucket("my-bucket")
            
            # Upload file
            with open("file.txt", "rb") as f:
                result = await client.put_object(
                    bucket_name="my-bucket",
                    object_name="uploads/file.txt",
                    data=f,
                    content_type="text/plain"
                )
            
            # List objects
            list_result = await client.list_objects("my-bucket")
            for obj in list_result.objects:
                print(f"Object: {obj.name}")
            
        except OmnixStorageException as e:
            print(f"Error: {e}")

asyncio.run(main())
```

## See Also

- [README](../README.md) - General documentation
- [Examples](../examples/) - Usage examples
- [Troubleshooting](./troubleshooting.md) - Common issues
