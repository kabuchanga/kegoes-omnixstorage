# PyPI Publishing Guide - OmnixStorage Python SDK

Complete guide for publishing the `omnix-storage` package to PyPI and alternative repositories.

## Quick Start (PyPI.org - Public)

**Most common option for public packages:**

```bash
# 1. Install publishing tools
pip install build twine

# 2. Build distribution packages
cd sdk/omnix-storage-py
python -m build

# 3. Publish to PyPI (requires API token)
python -m twine upload dist/*

# 4. Verify installation
pip install omnix-storage
python -c "from omnixstorage import OmnixClient; print('Success!')"
```

---

## Publishing Options

### Option 1: PyPI.org (Public Registry) ⭐ **RECOMMENDED**

**Best for:** Public open-source packages

**Prerequisites:**
1. Create account at https://pypi.org/account/register/
2. Configure 2FA (required for new uploads)
3. Generate API token at https://pypi.org/manage/account/token/

**Steps:**

```bash
# 1. Install build and twine
pip install --upgrade build twine

# 2. Build the package
cd sdk/omnix-storage-py
python -m build

# This creates:
# - dist/omnix_storage-1.0.0-py3-none-any.whl
# - dist/omnix-storage-1.0.0.tar.gz

# 3. Upload to PyPI (testpypi first for testing)
python -m twine upload --repository testpypi dist/*
# Username: __token__
# Password: pypi-xxx... (your API token)

# 4. Test installation from TestPyPI
pip install --index-url https://test.pypi.org/simple/ omnix-storage

# 5. If test successful, upload to production PyPI
python -m twine upload dist/*

# 6. Verify
pip install omnix-storage
python -c "from omnixstorage import OmnixClient; print('Installed successfully!')"
```

**Configure ~/.pypirc for convenience:**

```ini
[distutils]
index-servers =
    pypi
    testpypi

[pypi]
username = __token__
password = pypi-AgEIcHlwaS5vcmcCJGZh... # Your PyPI API token

[testpypi]
username = __token__
password = pypi-AgENdGVzdC5weXBpLm9y... # Your TestPyPI API token
```

---

### Option 2: GitHub Packages

**Best for:** Private packages, CI/CD integration

**Steps:**

```bash
# 1. Configure pip for GitHub Packages
# Add to ~/.pypirc:
[distutils]
index-servers =
    github

[github]
repository = https://upload.pypi.org/legacy/
username = YOUR_GITHUB_USERNAME
password = ghp_yourPersonalAccessToken

# 2. Update pyproject.toml with GitHub repository:
# Add:
# [project.urls]
# Source = "https://github.com/kegeos-io/omnix-storage-py"

# 3. Build and upload
python -m build
python -m twine upload --repository github dist/*

# 4. Install from GitHub Packages
pip install omnix-storage --extra-index-url \
  https://YOUR_USERNAME:ghp_TOKEN@github.com/YOUR_ORG/omnix-storage-py
```

---

### Option 3: Azure Artifacts

**Best for:** Enterprise deployments, Azure DevOps integration

**Prerequisites:**
- Azure DevOps organization
- Create a feed: Project Settings → Artifacts → Create Feed

**Steps:**

```bash
# 1. Install Azure Artifacts credential provider
pip install keyring artifacts-keyring

# 2. Configure pip for Azure Artifacts
# Add to pip.ini (Windows) or pip.conf (Linux/Mac):
[global]
extra-index-url = https://pkgs.dev.azure.com/YOUR_ORG/_packaging/YOUR_FEED/pypi/simple/

# 3. Authenticate
# Option A: Using PAT token
export AZURE_DEVOPS_EXT_PAT=your_pat_token

# Option B: Using Azure CLI
az login
az artifacts universal publish --organization YOUR_ORG --feed YOUR_FEED \
  --name omnix-storage --version 1.0.0 --path dist/ --description "SDK release"

# 4. Publish using twine
python -m build
python -m twine upload --repository-url \
  https://pkgs.dev.azure.com/YOUR_ORG/_packaging/YOUR_FEED/pypi/upload/ \
  dist/*
```

---

### Option 4: Private PyPI Server (e.g., PyPIServer, Artifactory)

**Best for:** Self-hosted, air-gapped environments

**Using pypiserver:**

```bash
# 1. Install and run pypiserver
pip install pypiserver
pypiserver run -p 8080 ~/packages

# 2. Configure pip to use private server
# Add to ~/.pypirc:
[distutils]
index-servers = local

[local]
repository = http://localhost:8080
username = admin
password = password

# 3. Upload package
python -m build
python -m twine upload --repository local dist/*

# 4. Install from private server
pip install --index-url http://localhost:8080/simple/ omnix-storage
```

---

## Pre-Publishing Checklist

### ✅ Code Quality
- [ ] All tests passing (`pytest tests/`)
- [ ] Linting clean (`ruff check src/`)
- [ ] Type checking clean (`mypy src/`)
- [ ] Documentation complete (README, API docs)

### ✅ Package Metadata
- [ ] Version bumped in `pyproject.toml`
- [ ] CHANGELOG.md updated
- [ ] LICENSE file present
- [ ] README.md includes installation instructions
- [ ] GitHub repository URL in `project.urls`

### ✅ Security
- [ ] No hardcoded credentials in code
- [ ] `.gitignore` configured (dist/, build/, *.egg-info/)
- [ ] Dependencies have no known vulnerabilities
- [ ] API tokens stored securely (environment variables)

### ✅ Testing
- [ ] Tested in clean virtual environment
- [ ] Tested with minimum Python version (3.8+)
- [ ] Import test successful: `python -c "import omnixstorage"`
- [ ] Example code runs without errors

---

## Package Verification

### Check package contents:

```bash
# Extract and inspect
cd dist/
tar -tzf omnix-storage-1.0.0.tar.gz

# Check metadata
python -m twine check dist/*

# Verify wheel structure
unzip -l dist/omnix_storage-1.0.0-py3-none-any.whl
```

### Post-publish verification:

```bash
# Wait 1-2 minutes for PyPI indexing
sleep 120

# Search for package
pip search omnix-storage  # (deprecated, use pypi.org web search)

# Install and test
pip install omnix-storage==1.0.0
python -c "from omnixstorage import OmnixClient; c = OmnixClient(); print('OK')"

# Check package page
open https://pypi.org/project/omnix-storage/
```

---

## Version Management

### Semantic Versioning

```python
# pyproject.toml
version = "1.0.0"  # Major.Minor.Patch

# Increment rules:
# Major (1.0.0 → 2.0.0): Breaking changes
# Minor (1.0.0 → 1.1.0): New features, backward compatible
# Patch (1.0.0 → 1.0.1): Bug fixes, backward compatible
```

### Updating for new release:

```bash
# 1. Update version in pyproject.toml
sed -i 's/version = "1.0.0"/version = "1.0.1"/' pyproject.toml

# 2. Update CHANGELOG.md
cat >> CHANGELOG.md <<EOF
## [1.0.1] - $(date +%Y-%m-%d)
### Fixed
- Bug fix description here
EOF

# 3. Commit and tag
git add pyproject.toml CHANGELOG.md
git commit -m "Release v1.0.1"
git tag -a v1.0.1 -m "Version 1.0.1"
git push origin main --tags

# 4. Build and publish
python -m build
python -m twine upload dist/*
```

---

## Security Best Practices

### Store API tokens securely:

```bash
# Option 1: Environment variables
export TWINE_USERNAME=__token__
export TWINE_PASSWORD=pypi-AgEIcHlwaS5vcmcC...
python -m twine upload dist/*

# Option 2: keyring (most secure)
pip install keyring
keyring set https://upload.pypi.org/legacy/ __token__
# Enter password: pypi-AgEIcHlwaS5vcmcC...
python -m twine upload -u __token__ dist/*

#Option 3: .pypirc (less secure, don't commit!)
chmod 600 ~/.pypirc  # Restrict permissions
```

### Never:
- ❌ Commit API tokens to version control
- ❌ Share tokens in documentation or screenshots
- ❌ Use production tokens for testing
- ❌ Store passwords in plain text

---

## CI/CD Automation

### GitHub Actions Example:

```yaml
# .github/workflows/publish.yml
name: Publish to PyPI

on:
  release:
    types: [published]

jobs:
  publish:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Set up Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.11'
      
      - name: Install dependencies
        run: |
          python -m pip install --upgrade pip
          pip install build twine
      
      - name: Build package
        run: python -m build
      
      - name: Publish to PyPI
        env:
          TWINE_USERNAME: __token__
          TWINE_PASSWORD: ${{ secrets.PYPI_API_TOKEN }}
        run: python -m twine upload dist/*
```

**Setup:**
1. Add secret in GitHub: Settings → Secrets → New repository secret
2. Name: `PYPI_API_TOKEN`
3. Value: Your PyPI API token

---

## Troubleshooting

### Error: "403 Forbidden - Invalid or non-existent authentication"
**Cause:** Wrong or expired API token  
**Fix:** Regenerate token at https://pypi.org/manage/account/token/

### Error: "400 Bad Request - File already exists"
**Cause:** Version already published (PyPI doesn't allow overwriting)  
**Fix:** Increment version number in `pyproject.toml`

### Error: "Invalid distribution file"
**Cause:** Build artifacts corrupted or incorrect format  
**Fix:** 
```bash
rm -rf dist/ build/ *.egg-info/
python -m build
python -m twine check dist/*
```

### Error: "Package name already taken"
**Cause:** Another project uses that name  
**Fix:** Choose a different name in `pyproject.toml`

### Import fails after installation
**Cause:** Package name vs import name mismatch  
**Fix:** Install with `-e .` for development mode and test

---

## Rollback / Delisting

### You CANNOT delete packages from PyPI, but you can:

```bash
# Option 1: Yank the release (hide from pip install)
# Login to PyPI web interface
# Project → Manage → Releases → [version] → Options → Yank

# Option 2: Upload a fixed version
# Increment version and republish
version = "1.0.1"  # Fix in pyproject.toml
python -m build
python -m twine upload dist/*

# Option 3: Mark as deprecated in README
echo "**WARNING: This package is deprecated. Use omnix-storage-v2 instead.**" > README.md
# Then publish a new version with the warning
```

---

## Publishing Summary

| Target | Command | Requirements |
|--------|---------|--------------|
| **TestPyPI** | `twine upload --repository testpypi dist/*` | TestPyPI account + API token |
| **PyPI** | `twine upload dist/*` | PyPI account + API token |
| **GitHub** | `twine upload --repository github dist/*` | GitHub PAT with `write:packages` |
| **Azure Artifacts** | `twine upload --repository-url [URL] dist/*` | Azure DevOps PAT + feed |
| **Private Server** | `twine upload --repository local dist/*` | pypiserver or similar running |

---

## Quick Reference

```bash
# Build
python -m build

# Check
python -m twine check dist/*

# Test upload
python -m twine upload --repository testpypi dist/*

# Production upload
python -m twine upload dist/*

# Install
pip install omnix-storage

# Upgrade
pip install --upgrade omnix-storage

# Verify
python -c "from omnixstorage import OmnixClient"
```

---

## Next Steps

1. **Choose publishing target** (PyPI.org recommended for public packages)
2. **Create account and generate API token**
3. **Run pre-publishing checklist**
4. **Build and upload package**
5. **Verify installation**
6. **Update documentation with install instructions**

**Which would you prefer?** To proceed, provide:
1. Target platform (PyPI, GitHub, Azure, or private server)?
2. Do you have the necessary credentials/API token?
