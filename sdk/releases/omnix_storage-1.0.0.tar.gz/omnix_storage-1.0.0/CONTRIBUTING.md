# Contributing to OmnixStorage Python SDK

Thank you for your interest in contributing to the OmnixStorage Python SDK! This document provides guidelines and instructions for contributing.

## Table of Contents

1. [Getting Started](#getting-started)
2. [Development Setup](#development-setup)
3. [Code Standards](#code-standards)
4. [Testing](#testing)
5. [Submitting Changes](#submitting-changes)
6. [Reporting Issues](#reporting-issues)

## Getting Started

### Prerequisites

- Python 3.8 or higher
- Git
- Basic understanding of async/await in Python
- Familiarity with S3 API concepts

### Fork and Clone

```bash
# Fork the repository on GitHub
# Clone your fork
git clone https://github.com/your-username/omnix-storage-py.git
cd omnix-storage-py

# Add upstream remote
git remote add upstream https://github.com/kegeo-solutions/omnix-storage-py.git
```

## Development Setup

### Install Development Dependencies

```bash
# Create a virtual environment
python -m venv venv

# Activate it
# On Linux/macOS:
source venv/bin/activate
# On Windows:
venv\Scripts\activate

# Install the package in development mode
pip install -e ".[dev]"
```

### Pre-commit Hooks (Optional but Recommended)

```bash
pip install pre-commit
pre-commit install
```

## Code Standards

### Python Style Guide

We follow [PEP 8](https://pep8.org/) with these tools:

#### Code Formatting

```bash
# Format code with black
black src/ tests/

# Sort imports with isort
isort src/ tests/

# Check formatting
black --check src/ tests/
```

#### Linting

```bash
# Check code quality
flake8 src/ tests/

# Type checking
mypy src/
```

### Naming Conventions

- **Classes**: `CapitalCase` (e.g., `OmnixClient`)
- **Functions/Methods**: `snake_case` (e.g., `put_object`)
- **Constants**: `UPPER_SNAKE_CASE` (e.g., `MAX_RETRIES`)
- **Private**: Prefix with `_` (e.g., `_http`)
- **Protected**: Prefix with `_` (e.g., `_make_request`)

### Type Hints

All functions should have type hints:

```python
async def put_object(
    self,
    bucket_name: str,
    object_name: str,
    data: BinaryIO,
    content_type: str = "application/octet-stream",
) -> PutObjectResult:
    """Upload an object to the bucket."""
    # Implementation
```

### Documentation

#### Docstrings

Use Google-style docstrings:

```python
def put_object(
    self,
    bucket_name: str,
    object_name: str,
    data: BinaryIO,
) -> PutObjectResult:
    """
    Upload an object to the bucket.
    
    Args:
        bucket_name: Name of the bucket
        object_name: Name of the object
        data: File-like object to upload
    
    Returns:
        PutObjectResult with upload details
    
    Raises:
        ServerException: If upload fails
    
    Example:
        with open("file.txt", "rb") as f:
            result = await client.put_object(
                bucket_name="my-bucket",
                object_name="file.txt",
                data=f
            )
    """
```

#### Comments

Keep comments concise and meaningful:

```python
# Good
# Check if token is expired before using cached value
if self._jwt_token and self._token_expires_at:
    if datetime.utcnow() < self._token_expires_at:
        return self._jwt_token

# Bad
# Token check
if self._jwt_token:
    # Expiry check
    if self._token_expires_at:
        # Compare dates
        if datetime.utcnow() < self._token_expires_at:
```

## Testing

### Running Tests

```bash
# Run all tests
pytest

# Run specific test file
pytest tests/test_client.py

# Run with verbose output
pytest -v

# Run with coverage report
pytest --cov=src/omnixstorage --cov-report=html
```

### Writing Tests

#### Test Structure

```python
import pytest
from unittest.mock import AsyncMock, patch

class TestFeatureName:
    """Test suite for a feature."""
    
    @pytest.mark.asyncio
    async def test_success_scenario(self):
        """Test successful operation."""
        # Arrange
        client = OmnixClient()
        
        # Act
        result = await client.some_operation()
        
        # Assert
        assert result is not None
    
    @pytest.mark.asyncio
    async def test_error_scenario(self):
        """Test error handling."""
        # Arrange
        client = OmnixClient()
        
        # Act & Assert
        with pytest.raises(ExpectedException):
            await client.failing_operation()
```

#### Mock Examples

```python
# Mock async function
with patch.object(client._http, 'get', new_callable=AsyncMock) as mock_get:
    mock_get.return_value = AsyncMock(status_code=200)
    result = await client.bucket_exists("bucket")
    assert result is True

# Mock response
mock_response = AsyncMock()
mock_response.status_code = 200
mock_response.json.return_value = {"token": "test-token"}
```

#### Test Coverage

- Aim for 80%+ code coverage
- Test both success and error paths
- Test edge cases
- Test concurrent operations

## Submitting Changes

### Creating a Branch

```bash
# Create a feature branch
git checkout -b feature/your-feature-name

# Or for bug fixes
git checkout -b fix/bug-description
```

### Commit Guidelines

Use clear, concise commit messages:

```bash
# Good
git commit -m "Add batch upload support for improved performance"
git commit -m "Fix token caching issue in authentication"
git commit -m "Update documentation for presigned URLs"

# Bad
git commit -m "fixed stuff"
git commit -m "various changes"
git commit -m "WIP"
```

### Formatting Commits

```bash
# Before committing, run these checks
black src/ tests/
isort src/ tests/
flake8 src/ tests/
mypy src/
pytest

# Add files
git add .

# Commit
git commit -m "Descriptive message"
```

### Pushing Changes

```bash
# Push to your fork
git push origin feature/your-feature-name

# Sync with upstream if needed
git fetch upstream
git rebase upstream/main
git push origin feature/your-feature-name
```

### Pull Request Process

1. **Create PR**: Go to GitHub and create a pull request from your fork
2. **Fill Template**: Complete the PR description template
3. **Reference Issues**: Link related issues (e.g., "Closes #123")
4. **Describe Changes**: Clearly explain what changed and why
5. **Add Tests**: Include tests for new functionality
6. **Update Docs**: Update documentation if behavior changes

#### PR Template

```markdown
## Description
Brief description of changes

## Related Issues
Closes #123

## Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Documentation update
- [ ] Performance improvement

## Testing
- [ ] Unit tests added/updated
- [ ] Integration tests passed
- [ ] Manual testing completed

## Documentation
- [ ] README updated
- [ ] API docs updated
- [ ] Examples added/updated
- [ ] Docstrings updated

## Checklist
- [ ] Code follows style guide
- [ ] Tests pass
- [ ] No breaking changes
- [ ] Documentation is complete
```

## Reporting Issues

### Bug Reports

Include:
- Python version
- SDK version
- Operating system
- Detailed error message
- Minimal reproducible example
- Steps to reproduce

**Example:**
```
## Bug Description
Connection fails when uploading large files

## Environment
- Python: 3.11.0
- SDK: 1.0.0
- OS: Linux (Ubuntu 22.04)

## Reproducible Example
```python
# Code that triggers the bug
```

## Steps to Reproduce
1. Create a 500MB file
2. Attempt to upload using put_object
3. Observe timeout after 30 seconds

## Expected vs Actual
Expected: File uploads successfully
Actual: Request times out

## Error Output
```
asyncio.TimeoutError: Request timeout after 30 seconds
```
```

### Feature Requests

Include:
- Clear description of the feature
- Use cases or examples
- Proposed API
- Potential implementation approach

**Example:**
```
## Feature: Multipart Upload Support

### Description
Support multipart uploads for large files to improve reliability

### Use Case
Users want to upload files >100MB with automatic retry on failure

### Proposed API
```python
result = await client.multipart_put_object(
    bucket_name="bucket",
    object_name="large-file.bin",
    data=f,
    part_size=5*1024*1024  # 5MB parts
)
```
```

## Development Workflow Example

```bash
# 1. Create branch
git checkout -b feature/multipart-upload

# 2. Make changes
# - Edit src/omnixstorage/client.py
# - Add tests in tests/test_client.py
# - Update docs in docs/API_REFERENCE.md

# 3. Format code
black src/ tests/
isort src/ tests/

# 4. Check code quality
flake8 src/ tests/
mypy src/

# 5. Run tests
pytest

# 6. Commit changes
git add .
git commit -m "Add multipart upload support"

# 7. Push to fork
git push origin feature/multipart-upload

# 8. Create pull request on GitHub
```

## Code Review

### What to Expect

- Constructive feedback on code
- Suggestions for improvements
- Questions about approach
- Tests will be run automatically
- Coverage must not decrease

### Addressing Feedback

- Make requested changes
- Re-request review when done
- Don't force-push if PR is in review (create new commit instead)
- Can squash commits before merge

## Recognition

Contributors will be:
- Listed in CONTRIBUTORS file
- Thanked in release notes
- Acknowledged in documentation

## License

By contributing, you agree that your contributions will be licensed under the Apache License 2.0.

## Questions?

- Email: contribute@kegeo.com
- GitHub Issues: For questions about specific issues
- Discussions: For general questions and ideas

Thank you for contributing! 🎉
