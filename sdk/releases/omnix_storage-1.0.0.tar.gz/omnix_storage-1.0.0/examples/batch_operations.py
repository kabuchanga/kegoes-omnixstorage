"""
Advanced example demonstrating batch operations and concurrent uploads/downloads
"""

import asyncio
import sys
from pathlib import Path
from typing import List

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from omnixstorage import OmnixClient, ObjectMetadata


async def batch_upload_files(
    client: OmnixClient,
    bucket_name: str,
    file_paths: List[str],
    prefix: str = ""
) -> List:
    """Upload multiple files concurrently"""
    print(f"Uploading {len(file_paths)} files concurrently...")
    
    async def upload_file(file_path: str):
        try:
            object_name = f"{prefix}{Path(file_path).name}"
            with open(file_path, "rb") as f:
                result = await client.put_object(
                    bucket_name=bucket_name,
                    object_name=object_name,
                    data=f,
                    content_type="application/octet-stream"
                )
            print(f"  ✓ Uploaded: {object_name} (ETag: {result.etag[:8]}...)")
            return result
        except Exception as e:
            print(f"  ✗ Failed to upload {file_path}: {e}")
            raise
    
    # Upload all files concurrently
    tasks = [upload_file(path) for path in file_paths]
    results = await asyncio.gather(*tasks, return_exceptions=True)
    
    return results


async def batch_download_files(
    client: OmnixClient,
    bucket_name: str,
    object_names: List[str],
    output_dir: str = "."
) -> List:
    """Download multiple files concurrently"""
    print(f"Downloading {len(object_names)} files concurrently...")
    
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    
    async def download_file(object_name: str):
        try:
            local_file = Path(output_dir) / Path(object_name).name
            with open(local_file, "wb") as f:
                metadata = await client.get_object(
                    bucket_name=bucket_name,
                    object_name=object_name,
                    output=f
                )
            print(f"  ✓ Downloaded: {object_name} to {local_file}")
            return metadata
        except Exception as e:
            print(f"  ✗ Failed to download {object_name}: {e}")
            raise
    
    # Download all files concurrently
    tasks = [download_file(name) for name in object_names]
    results = await asyncio.gather(*tasks, return_exceptions=True)
    
    return results


async def batch_list_all_objects(
    client: OmnixClient,
    bucket_name: str,
    prefix: str = ""
) -> List[ObjectMetadata]:
    """List all objects with pagination"""
    print(f"Listing all objects in bucket '{bucket_name}'...")
    
    all_objects = []
    continuation_token = None
    page = 1
    
    while True:
        print(f"  Fetching page {page}...")
        
        result = await client.list_objects(
            bucket_name=bucket_name,
            prefix=prefix,
            max_keys=1000,
            continuation_token=continuation_token
        )
        
        all_objects.extend(result.objects)
        print(f"    Found {len(result.objects)} objects on this page")
        
        if not result.is_truncated:
            break
        
        continuation_token = result.continuation_token
        page += 1
    
    return all_objects


async def main():
    # Initialize the client
    client = OmnixClient(
        endpoint="localhost:9000",
        access_key="minioadmin",
        secret_key="minioadmin",
        use_ssl=False
    )
    
    try:
        bucket_name = "batch-demo-bucket"
        
        # Create bucket
        exists = await client.bucket_exists(bucket_name)
        if not exists:
            await client.make_bucket(bucket_name)
            print(f"Created bucket: {bucket_name}\n")
        
        # Create test files
        test_files = []
        print("--- Creating Test Files ---")
        for i in range(5):
            file_path = f"test_file_{i}.txt"
            with open(file_path, "w") as f:
                f.write(f"This is test file {i}\n")
                f.write(f"Content repeated for file {i}\n" * 100)
            test_files.append(file_path)
            print(f"Created: {file_path}")
        
        # Batch upload
        print("\n--- Batch Upload ---")
        upload_results = await batch_upload_files(
            client,
            bucket_name,
            test_files,
            prefix="batch_files/"
        )
        
        # List all objects
        print("\n--- List All Objects ---")
        all_objects = await batch_list_all_objects(
            client,
            bucket_name,
            prefix="batch_files/"
        )
        print(f"Total objects found: {len(all_objects)}")
        for obj in all_objects:
            print(f"  - {obj.name} ({obj.size} bytes)")
        
        # Get statistics
        print("\n--- Object Statistics ---")
        total_size = sum(obj.size for obj in all_objects)
        avg_size = total_size / len(all_objects) if all_objects else 0
        print(f"Total objects: {len(all_objects)}")
        print(f"Total size: {total_size:,} bytes")
        print(f"Average size: {avg_size:,.0f} bytes")
        
        # Batch download
        print("\n--- Batch Download ---")
        object_names = [obj.name for obj in all_objects]
        download_dir = "downloaded_files"
        await batch_download_files(
            client,
            bucket_name,
            object_names,
            output_dir=download_dir
        )
        
        # Verify downloaded files
        print("\n--- Verify Downloaded Files ---")
        downloaded_files = list(Path(download_dir).glob("*.txt"))
        print(f"Downloaded {len(downloaded_files)} files to '{download_dir}'")
        
        # Cleanup
        print("\n--- Cleanup ---")
        for obj in all_objects:
            await client.remove_object(bucket_name, obj.name)
            print(f"Deleted: {obj.name}")
        
        await client.remove_bucket(bucket_name)
        print(f"Removed bucket: {bucket_name}")
        
        # Remove test files
        for file_path in test_files:
            Path(file_path).unlink()
        
        # Remove downloaded files
        import shutil
        if Path(download_dir).exists():
            shutil.rmtree(download_dir)
        
        print("\nCleanup completed")
        
    except Exception as e:
        print(f"Error: {type(e).__name__}: {e}")
        raise
    
    finally:
        await client.close()


if __name__ == "__main__":
    asyncio.run(main())
