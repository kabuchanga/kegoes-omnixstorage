"""
Example demonstrating error handling with OmnixClient
"""

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from omnixstorage import OmnixClient
from omnixstorage.error import (
    OmnixStorageException,
    BucketNotFoundException,
    ObjectNotFoundException,
    AuthenticationException,
    ServerException,
    AccessDeniedException,
)


async def example_bucket_not_found():
    """Example: Handling bucket not found error"""
    print("--- Example: Bucket Not Found ---")
    
    client = OmnixClient(
        endpoint="localhost:9000",
        access_key="minioadmin",
        secret_key="minioadmin"
    )
    
    try:
        # Try to access a non-existent bucket
        await client.stat_object(
            bucket_name="non-existent-bucket",
            object_name="any-file.txt"
        )
    except BucketNotFoundException as e:
        print(f"Expected error caught: {e}")
    except Exception as e:
        print(f"Unexpected error: {type(e).__name__}: {e}")
    finally:
        await client.close()


async def example_object_not_found():
    """Example: Handling object not found error"""
    print("\n--- Example: Object Not Found ---")
    
    client = OmnixClient(
        endpoint="localhost:9000",
        access_key="minioadmin",
        secret_key="minioadmin"
    )
    
    try:
        # Create a test bucket
        bucket_name = "error-handling-demo"
        exists = await client.bucket_exists(bucket_name)
        if not exists:
            await client.make_bucket(bucket_name)
        
        # Try to access a non-existent object
        try:
            with open("temp.bin", "wb") as f:
                await client.get_object(
                    bucket_name=bucket_name,
                    object_name="non-existent-file.txt",
                    output=f
                )
        except ObjectNotFoundException as e:
            print(f"Expected error caught: {e}")
        
        # Cleanup
        await client.remove_bucket(bucket_name)
        
    except Exception as e:
        print(f"Unexpected error: {type(e).__name__}: {e}")
    finally:
        await client.close()


async def example_authentication_error():
    """Example: Handling authentication error"""
    print("\n--- Example: Authentication Error ---")
    
    client = OmnixClient(
        endpoint="localhost:9000",
        access_key="invalid-key",
        secret_key="invalid-secret"
    )
    
    try:
        # Try to authenticate with invalid credentials
        await client.health()
    except AuthenticationException as e:
        print(f"Expected error caught: {e}")
    except ServerException as e:
        # Some servers might return 401 as ServerException
        if e.status_code == 401:
            print(f"Authentication failed (status {e.status_code}): {e}")
        else:
            print(f"Server error: {e}")
    except Exception as e:
        print(f"Unexpected error: {type(e).__name__}: {e}")
    finally:
        await client.close()


async def example_generic_server_error():
    """Example: Handling generic server errors"""
    print("\n--- Example: Server Error ---")
    
    client = OmnixClient(
        endpoint="localhost:9000",
        access_key="minioadmin",
        secret_key="minioadmin"
    )
    
    try:
        # Try to access server with invalid port
        bad_client = OmnixClient(
            endpoint="localhost:9999",  # Non-existent port
            access_key="minioadmin",
            secret_key="minioadmin"
        )
        await bad_client.health()
    except ServerException as e:
        print(f"Server error (status {e.status_code}): {e}")
    except Exception as e:
        print(f"Network/Connection error: {type(e).__name__}: {e}")
    finally:
        await client.close()


async def example_retry_logic():
    """Example: How to implement custom retry logic"""
    print("\n--- Example: Retry Logic ---")
    
    client = OmnixClient(
        endpoint="localhost:9000",
        access_key="minioadmin",
        secret_key="minioadmin"
    )
    
    async def get_object_with_retry(
        bucket_name: str,
        object_name: str,
        output,
        max_retries: int = 3
    ):
        """Get object with custom retry logic"""
        for attempt in range(max_retries):
            try:
                print(f"Attempt {attempt + 1}/{max_retries}")
                metadata = await client.get_object(
                    bucket_name=bucket_name,
                    object_name=object_name,
                    output=output
                )
                print(f"Success on attempt {attempt + 1}")
                return metadata
            except ObjectNotFoundException:
                # Don't retry for not found
                raise
            except ServerException as e:
                if e.status_code >= 500 and attempt < max_retries - 1:
                    print(f"Server error, retrying... ({e.status_code})")
                    await asyncio.sleep(2 ** attempt)  # Exponential backoff
                else:
                    raise
            except Exception as e:
                if attempt < max_retries - 1:
                    print(f"Error: {e}, retrying...")
                    await asyncio.sleep(2 ** attempt)
                else:
                    raise
    
    try:
        bucket_name = "retry-demo"
        
        # Create bucket and upload file
        exists = await client.bucket_exists(bucket_name)
        if not exists:
            await client.make_bucket(bucket_name)
        
        # Upload a test file
        with open("test.txt", "w") as f:
            f.write("Test content")
        
        with open("test.txt", "rb") as f:
            await client.put_object(
                bucket_name=bucket_name,
                object_name="test.txt",
                data=f
            )
        
        # Download with retry logic
        with open("output.txt", "wb") as f:
            metadata = await get_object_with_retry(
                bucket_name=bucket_name,
                object_name="test.txt",
                output=f,
                max_retries=3
            )
            print(f"Downloaded: {metadata.name} ({metadata.size} bytes)")
        
        # Cleanup
        await client.remove_object(bucket_name, "test.txt")
        await client.remove_bucket(bucket_name)
        
        # Remove test files
        Path("test.txt").unlink()
        Path("output.txt").unlink()
        
    except Exception as e:
        print(f"Error: {type(e).__name__}: {e}")
    finally:
        await client.close()


async def example_error_details():
    """Example: Accessing error details"""
    print("\n--- Example: Error Details ---")
    
    client = OmnixClient(
        endpoint="localhost:9000",
        access_key="minioadmin",
        secret_key="minioadmin"
    )
    
    try:
        bucket_name = "error-details-demo"
        
        exists = await client.bucket_exists(bucket_name)
        if not exists:
            await client.make_bucket(bucket_name)
        
        try:
            with open("temp.bin", "wb") as f:
                await client.get_object(
                    bucket_name=bucket_name,
                    object_name="missing.txt",
                    output=f
                )
        except OmnixStorageException as e:
            print(f"Exception type: {type(e).__name__}")
            print(f"Error message: {e}")
            if hasattr(e, 'status_code'):
                print(f"Status code: {e.status_code}")
            if hasattr(e, 'error_code'):
                print(f"Error code: {e.error_code}")
        
        await client.remove_bucket(bucket_name)
        
    except Exception as e:
        print(f"Error: {type(e).__name__}: {e}")
    finally:
        await client.close()


async def main():
    """Run all examples"""
    examples = [
        example_bucket_not_found,
        example_object_not_found,
        example_authentication_error,
        example_generic_server_error,
        example_retry_logic,
        example_error_details,
    ]
    
    for example in examples:
        try:
            await example()
        except Exception as e:
            print(f"Example failed: {e}")
        
        # Small delay between examples
        await asyncio.sleep(0.5)


if __name__ == "__main__":
    asyncio.run(main())
