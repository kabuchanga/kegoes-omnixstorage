"""
Basic example demonstrating OmnixClient usage
"""

import asyncio
import sys
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from omnixstorage import OmnixClient


async def main():
    # Initialize the client
    client = OmnixClient(
        endpoint="localhost:9000",
        access_key="minioadmin",
        secret_key="minioadmin",
        use_ssl=False
    )
    
    try:
        # Check server health
        is_healthy = await client.health()
        print(f"Server health: {'Healthy' if is_healthy else 'Unhealthy'}")
        
        # List existing buckets
        print("\n--- Listing Buckets ---")
        buckets = await client.list_buckets()
        print(f"Found {len(buckets)} buckets:")
        for bucket in buckets:
            print(f"  - {bucket.name} (created: {bucket.creation_date})")
        
        # Create a new bucket
        bucket_name = "demo-bucket"
        print(f"\n--- Creating Bucket: {bucket_name} ---")
        
        # Check if bucket exists
        exists = await client.bucket_exists(bucket_name)
        if not exists:
            await client.make_bucket(bucket_name)
            print(f"Bucket '{bucket_name}' created successfully")
        else:
            print(f"Bucket '{bucket_name}' already exists")
        
        # Upload a file
        print(f"\n--- Uploading File ---")
        test_file = "test_upload.txt"
        
        # Create a test file
        with open(test_file, "w") as f:
            f.write("This is a test file for OmnixStorage Python SDK\n")
            f.write("It demonstrates basic upload functionality\n")
        
        # Upload the file
        with open(test_file, "rb") as f:
            result = await client.put_object(
                bucket_name=bucket_name,
                object_name="test_files/demo.txt",
                data=f,
                content_type="text/plain",
                metadata={"uploaded_by": "python_sdk_example"}
            )
            print(f"File uploaded successfully")
            print(f"  ETag: {result.etag}")
        
        # Get object metadata
        print(f"\n--- Getting Object Metadata ---")
        metadata = await client.stat_object(
            bucket_name=bucket_name,
            object_name="test_files/demo.txt"
        )
        print(f"Object: {metadata.name}")
        print(f"  Size: {metadata.size} bytes")
        print(f"  Content-Type: {metadata.content_type}")
        print(f"  ETag: {metadata.etag}")
        
        # List objects in bucket
        print(f"\n--- Listing Objects in Bucket ---")
        result = await client.list_objects(bucket_name=bucket_name)
        print(f"Found {len(result.objects)} objects:")
        for obj in result.objects:
            print(f"  - {obj.name} ({obj.size} bytes)")
        
        # List objects with prefix
        print(f"\n--- Listing Objects with Prefix ---")
        result = await client.list_objects(
            bucket_name=bucket_name,
            prefix="test_files/"
        )
        print(f"Found {len(result.objects)} objects with prefix 'test_files/':")
        for obj in result.objects:
            print(f"  - {obj.name}")
        
        # Download the file
        print(f"\n--- Downloading File ---")
        download_file = "test_download.txt"
        with open(download_file, "wb") as f:
            metadata = await client.get_object(
                bucket_name=bucket_name,
                object_name="test_files/demo.txt",
                output=f
            )
            print(f"File downloaded successfully")
            print(f"  Name: {metadata.name}")
            print(f"  Size: {metadata.size} bytes")
        
        # Verify downloaded content
        with open(download_file, "r") as f:
            content = f.read()
            print(f"  Content preview: {content[:50]}...")
        
        # Generate presigned URL
        print(f"\n--- Generating Presigned URL ---")
        presigned = await client.presigned_get_object(
            bucket_name=bucket_name,
            object_name="test_files/demo.txt",
            expires_in_seconds=3600
        )
        print(f"Presigned URL (valid for 1 hour):")
        print(f"  {presigned.url}")
        print(f"  Expires at: {presigned.expires_at}")
        
        # Delete the object
        print(f"\n--- Deleting Object ---")
        await client.remove_object(
            bucket_name=bucket_name,
            object_name="test_files/demo.txt"
        )
        print(f"Object deleted successfully")
        
        # Remove the bucket
        print(f"\n--- Removing Bucket ---")
        await client.remove_bucket(bucket_name)
        print(f"Bucket '{bucket_name}' removed successfully")
        
        # Cleanup local files
        Path(test_file).unlink()
        Path(download_file).unlink()
        print("\nLocal test files cleaned up")
        
    except Exception as e:
        print(f"Error: {type(e).__name__}: {e}")
        raise
    
    finally:
        # Close the client
        await client.close()
        print("\nClient closed")


if __name__ == "__main__":
    asyncio.run(main())
