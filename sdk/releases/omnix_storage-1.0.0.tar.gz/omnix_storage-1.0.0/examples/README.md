# OmnixStorage Python SDK Examples

This directory contains examples demonstrating various features of the OmnixStorage Python SDK.

## Examples

### 1. Basic Example (`basic_example.py`)

Demonstrates fundamental operations:
- Server health check
- Listing buckets
- Creating buckets
- Uploading files
- Getting object metadata
- Listing objects
- Downloading files
- Generating presigned URLs
- Deleting objects
- Removing buckets

**Run:**
```bash
python basic_example.py
```

### 2. Batch Operations (`batch_operations.py`)

Shows how to perform concurrent operations for better performance:
- Batch uploading multiple files
- Batch downloading multiple files
- Listing all objects with pagination
- Gathering statistics

**Run:**
```bash
python batch_operations.py
```

### 3. Error Handling (`error_handling.py`)

Demonstrates proper error handling patterns:
- Handling bucket not found errors
- Handling object not found errors
- Handling authentication errors
- Handling server errors
- Implementing retry logic with exponential backoff
- Accessing error details

**Run:**
```bash
python error_handling.py
```

## Prerequisites

1. **Python 3.8+** - SDK requires Python 3.8 or later

2. **OmnixStorage Server** - Examples assume a running OmnixStorage server

3. **Install Dependencies:**
   ```bash
   pip install omnix-storage
   # Or with development dependencies
   pip install omnix-storage[dev]
   ```

## Configuration

By default, examples use:
- **Endpoint**: `localhost:9000`
- **Access Key**: `minioadmin`
- **Secret Key**: `minioadmin`
- **Protocol**: HTTP (no SSL)

To use different credentials, modify the `OmnixClient` initialization in the examples:

```python
client = OmnixClient(
    endpoint="your-server:9000",
    access_key="your-access-key",
    secret_key="your-secret-key",
    use_ssl=True  # Use HTTPS
)
```

## Running Examples

### Option 1: Run Individual Examples
```bash
python basic_example.py
python batch_operations.py
python error_handling.py
```

### Option 2: Run All Examples (requires shell)
```bash
# On Linux/macOS
for example in *.py; do python "$example"; done

# On Windows PowerShell
Get-ChildItem *.py | ForEach-Object { python $_.FullName }
```

## Example Output

Each example produces console output showing:
- Operations performed
- Success/failure messages
- Timing information
- Statistics and results

Example output:
```
--- Creating Bucket: demo-bucket ---
Bucket 'demo-bucket' created successfully

--- Uploading File ---
File uploaded successfully
  ETag: 2c26b46911185131

--- Listing Objects in Bucket ---
Found 1 objects:
  - test_files/demo.txt (48 bytes)

--- Getting Object Metadata ---
Object: test_files/demo.txt
  Size: 48 bytes
  Content-Type: text/plain
  ETag: 2c26b46911185131
```

## Performance Tips

1. **Concurrent Operations**: Use `asyncio.gather()` for multiple concurrent operations
2. **Connection Pooling**: The SDK automatically manages connection pooling
3. **Batch Operations**: See `batch_operations.py` for optimal patterns
4. **Large Files**: Stream files instead of loading into memory

## Troubleshooting

### Connection Refused
- Ensure OmnixStorage server is running
- Check endpoint URL and port
- Verify network connectivity

### Authentication Failed
- Check access key and secret key
- Ensure credentials are correct for the server
- Check server logs for authentication issues

### Timeout Errors
- Increase `request_timeout` parameter (default: 30 seconds)
- Check network latency to server
- Check if server is overloaded

Example with custom timeout:
```python
client = OmnixClient(
    endpoint="localhost:9000",
    access_key="admin",
    secret_key="password",
    request_timeout=60  # 60 seconds
)
```

## Advanced Usage

### Custom Retry Logic
See `error_handling.py` for example implementation of retry logic with exponential backoff.

### Batch Processing
See `batch_operations.py` for concurrent uploads/downloads using `asyncio.gather()`.

### Error Handling
See `error_handling.py` for comprehensive error handling patterns.

## Contributing

To add new examples:

1. Create a new Python file in this directory
2. Include docstring explaining the example
3. Add comments for clarity
4. Include error handling
5. Clean up resources properly
6. Add entry to this README

## API Reference

For complete API documentation, see:
- [API Reference](../docs/api-reference.md)
- [Package Documentation](../README.md)

## Support

For issues or questions:
1. Check the [Troubleshooting Guide](../docs/troubleshooting.md)
2. Review example code comments
3. Check OmnixStorage server logs
4. Contact support: support@kegeo.com

## License

All examples are provided under Apache License 2.0
