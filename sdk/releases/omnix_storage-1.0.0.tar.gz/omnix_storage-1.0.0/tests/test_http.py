"""
Tests for HTTP client functionality
"""

import httpx
import pytest
from unittest.mock import AsyncMock

from omnixstorage._http import HttpClient


class TestHttpClient:
    """Tests for HttpClient"""

    def test_http_client_initialization(self):
        """Test HTTP client initialization"""
        client = HttpClient(timeout=60, max_retries=5)

        assert client.timeout == 60
        assert client.max_retries == 5

    @pytest.mark.asyncio
    async def test_get_request(self, monkeypatch: pytest.MonkeyPatch):
        """Test GET request"""
        client = HttpClient()

        response = httpx.Response(200, content=b'{"test": "data"}', headers={"Content-Type": "application/json"})
        mock_request = AsyncMock(return_value=response)
        monkeypatch.setattr(client._client, "request", mock_request)

        result = await client.get("http://example.com/test")

        assert result.status_code == 200
        assert result.content == b'{"test": "data"}'

    @pytest.mark.asyncio
    async def test_head_request(self, monkeypatch: pytest.MonkeyPatch):
        """Test HEAD request"""
        client = HttpClient()

        response = httpx.Response(200, content=b"", headers={})
        mock_request = AsyncMock(return_value=response)
        monkeypatch.setattr(client._client, "request", mock_request)

        result = await client.head("http://example.com/test")

        assert result.status_code == 200

    @pytest.mark.asyncio
    async def test_put_request_with_content(self, monkeypatch: pytest.MonkeyPatch):
        """Test PUT request with binary content"""
        client = HttpClient()

        response = httpx.Response(200, content=b"", headers={"ETag": "abc123"})
        mock_request = AsyncMock(return_value=response)
        monkeypatch.setattr(client._client, "request", mock_request)

        result = await client.put(
            "http://example.com/test",
            content=b"test content"
        )

        assert result.status_code == 200
        assert result.headers["ETag"] == "abc123"

    @pytest.mark.asyncio
    async def test_put_request_with_json(self, monkeypatch: pytest.MonkeyPatch):
        """Test PUT request with JSON data"""
        client = HttpClient()

        response = httpx.Response(200, content=b"", headers={})
        mock_request = AsyncMock(return_value=response)
        monkeypatch.setattr(client._client, "request", mock_request)

        result = await client.put(
            "http://example.com/test",
            json={"key": "value"}
        )

        assert result.status_code == 200

    @pytest.mark.asyncio
    async def test_post_request(self, monkeypatch: pytest.MonkeyPatch):
        """Test POST request"""
        client = HttpClient()

        response = httpx.Response(201, content=b'{"id": 1}', headers={})
        mock_request = AsyncMock(return_value=response)
        monkeypatch.setattr(client._client, "request", mock_request)

        result = await client.post(
            "http://example.com/test",
            json={"data": "test"}
        )

        assert result.status_code == 201

    @pytest.mark.asyncio
    async def test_delete_request(self, monkeypatch: pytest.MonkeyPatch):
        """Test DELETE request"""
        client = HttpClient()

        response = httpx.Response(204, content=b"", headers={})
        mock_request = AsyncMock(return_value=response)
        monkeypatch.setattr(client._client, "request", mock_request)

        result = await client.delete("http://example.com/test")

        assert result.status_code == 204

    @pytest.mark.asyncio
    async def test_close_connection(self, monkeypatch: pytest.MonkeyPatch):
        """Test closing HTTP client"""
        client = HttpClient()

        mock_close = AsyncMock()
        monkeypatch.setattr(client._client, "aclose", mock_close)

        await client.close()

        mock_close.assert_called_once()


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
