"""
Tests for AWS Signature V4 signer
"""

import pytest
from datetime import datetime

from omnixstorage._signer import AwsSignatureV4Signer


class TestAwsSignatureV4Signer:
    """Tests for AWS Signature V4 signer"""
    
    def test_signer_initialization(self):
        """Test signer initialization"""
        signer = AwsSignatureV4Signer(
            access_key="AKIAIOSFODNN7EXAMPLE",
            secret_key="wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
        )
        
        assert signer.access_key == "AKIAIOSFODNN7EXAMPLE"
        assert signer.secret_key == "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
    
    def test_canonical_headers_building(self):
        """Test building canonical headers"""
        signer = AwsSignatureV4Signer("test-key", "test-secret")
        
        headers = {
            "Host": "s3.amazonaws.com",
            "Date": "20240101T000000Z",
            "Content-Type": "text/plain"
        }
        
        canonical_headers = signer._build_canonical_headers(headers)
        
        assert "host" in canonical_headers
        assert "date" in canonical_headers
        assert "content-type" in canonical_headers
    
    def test_canonical_querystring_building(self):
        """Test building canonical query string"""
        signer = AwsSignatureV4Signer("test-key", "test-secret")
        
        query_params = {
            "prefix": "logs/",
            "delimiter": "/",
            "max-keys": "100"
        }
        
        canonical_querystring = signer._build_canonical_querystring(query_params)
        
        assert "delimiter" in canonical_querystring
        assert "max-keys" in canonical_querystring
        assert "prefix" in canonical_querystring
    
    def test_payload_hashing(self):
        """Test payload hashing"""
        signer = AwsSignatureV4Signer("test-key", "test-secret")
        
        payload = b"test payload"
        hash_value = signer._hash_payload(payload)
        
        # Should return a SHA-256 hash in hex
        assert isinstance(hash_value, str)
        assert len(hash_value) == 64  # SHA-256 produces 64 hex characters
    
    def test_empty_payload_hashing(self):
        """Test hashing empty payload"""
        signer = AwsSignatureV4Signer("test-key", "test-secret")
        
        hash_value = signer._hash_payload(None)
        
        # Should return UNSIGNED-PAYLOAD for empty bodies
        assert hash_value == "UNSIGNED-PAYLOAD"
    
    def test_signature_generation(self):
        """Test signature generation"""
        signer = AwsSignatureV4Signer(
            access_key="AKIAIOSFODNN7EXAMPLE",
            secret_key="wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
        )
        
        timestamp = datetime(2024, 1, 1, 0, 0, 0)
        
        headers = signer.sign_request(
            method="GET",
            host="s3.amazonaws.com",
            path="/my-bucket/my-object",
            headers={"Host": "s3.amazonaws.com"},
            timestamp=timestamp
        )
        
        assert "Authorization" in headers
        assert "X-Amz-Date" in headers
        assert headers["X-Amz-Date"] == "20240101T000000Z"
    
    def test_presigned_url_generation(self):
        """Test presigned URL generation"""
        signer = AwsSignatureV4Signer(
            access_key="AKIAIOSFODNN7EXAMPLE",
            secret_key="wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
        )
        
        timestamp = datetime(2024, 1, 1, 0, 0, 0)
        
        presigned_url = signer.generate_presigned_url(
            method="GET",
            host="s3.amazonaws.com",
            path="/my-bucket/my-object",
            expires_in=3600,
            timestamp=timestamp
        )
        
        assert isinstance(presigned_url, str)
        assert "X-Amz-Algorithm=AWS4-HMAC-SHA256" in presigned_url
        assert "X-Amz-Credential=" in presigned_url
        assert "X-Amz-Signature=" in presigned_url
    
    def test_signing_with_multiple_query_params(self):
        """Test signing request with multiple query parameters"""
        signer = AwsSignatureV4Signer("test-key", "test-secret")
        
        timestamp = datetime(2024, 1, 1, 0, 0, 0)
        
        query_params = {
            "prefix": "photos/",
            "delimiter": "/",
            "max-keys": "100",
            "continuation-token": "token123"
        }
        
        headers = signer.sign_request(
            method="GET",
            host="s3.amazonaws.com",
            path="/my-bucket",
            query_params=query_params,
            headers={"Host": "s3.amazonaws.com"},
            timestamp=timestamp
        )
        
        assert "Authorization" in headers
    
    def test_signing_with_custom_headers(self):
        """Test signing request with custom headers"""
        signer = AwsSignatureV4Signer("test-key", "test-secret")
        
        timestamp = datetime(2024, 1, 1, 0, 0, 0)
        
        custom_headers = {
            "Host": "s3.amazonaws.com",
            "Content-Type": "text/plain",
            "x-amz-meta-custom": "value"
        }
        
        headers = signer.sign_request(
            method="PUT",
            host="s3.amazonaws.com",
            path="/my-bucket/my-object",
            headers=custom_headers,
            body=b"test data",
            timestamp=timestamp
        )
        
        # sign_request returns only the signing-related headers
        assert "Authorization" in headers
        assert "X-Amz-Date" in headers
    
    def test_different_timestamps_produce_different_signatures(self):
        """Test that different timestamps produce different signatures"""
        signer = AwsSignatureV4Signer("test-key", "test-secret")
        
        timestamp1 = datetime(2024, 1, 1, 0, 0, 0)
        timestamp2 = datetime(2024, 1, 1, 1, 0, 0)
        
        headers1 = signer.sign_request(
            method="GET",
            host="s3.amazonaws.com",
            path="/my-bucket/my-object",
            headers={"Host": "s3.amazonaws.com"},
            timestamp=timestamp1
        )
        
        headers2 = signer.sign_request(
            method="GET",
            host="s3.amazonaws.com",
            path="/my-bucket/my-object",
            headers={"Host": "s3.amazonaws.com"},
            timestamp=timestamp2
        )
        
        assert headers1["Authorization"] != headers2["Authorization"]


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
