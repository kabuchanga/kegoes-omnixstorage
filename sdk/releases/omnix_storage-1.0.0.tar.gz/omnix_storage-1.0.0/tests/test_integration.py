"""
Integration tests for OmnixClient with mock server
"""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from io import BytesIO

from omnixstorage import OmnixClient, ObjectMetadata


class TestIntegration:
    """Integration tests for OmnixClient"""
    
    @pytest.mark.asyncio
    async def test_full_upload_workflow(self):
        """Test complete upload workflow"""
        client = OmnixClient(
            endpoint="localhost:9000",
            access_key="admin",
            secret_key="password"
        )
        
        mock_put_response = MagicMock()
        mock_put_response.status_code = 200
        mock_put_response.headers = {"ETag": "upload-etag"}
        
        with patch.object(client, '_make_request', new_callable=AsyncMock) as mock_req:
            mock_req.return_value = mock_put_response
            
            file_content = BytesIO(b"test file content")
            result = await client.put_object(
                bucket_name="uploads",
                object_name="test-file.txt",
                data=file_content,
                content_type="text/plain"
            )
            
            assert result.bucket_name == "uploads"
            assert result.object_name == "test-file.txt"
            assert result.etag == "upload-etag"
    
    @pytest.mark.asyncio
    async def test_full_download_workflow(self):
        """Test complete download workflow"""
        client = OmnixClient(
            endpoint="localhost:9000",
            access_key="admin",
            secret_key="password"
        )
        
        mock_get_response = MagicMock()
        mock_get_response.status_code = 200
        content_bytes = b"downloaded file content"
        mock_get_response.content = content_bytes
        mock_get_response.headers = {
            "Content-Type": "text/plain",
            "Content-Length": str(len(content_bytes)),
            "ETag": "download-etag"
        }
        
        with patch.object(client, '_make_request', new_callable=AsyncMock) as mock_req:
            mock_req.return_value = mock_get_response
            
            output = BytesIO()
            result = await client.get_object(
                bucket_name="downloads",
                object_name="test-file.txt",
                output=output
            )
            
            assert result.bucket_name == "downloads"
            assert result.object_name == "test-file.txt"
            assert result.size == len(content_bytes)
            assert output.getvalue() == content_bytes
    
    @pytest.mark.asyncio
    async def test_bucket_listing_workflow(self):
        """Test bucket listing workflow"""
        client = OmnixClient(
            endpoint="localhost:9000",
            access_key="admin",
            secret_key="password"
        )
        
        mock_list_response = MagicMock()
        mock_list_response.status_code = 200
        mock_list_response.json.return_value = {
            "buckets": [
                {"name": "backup", "createdAt": "2024-01-01T00:00:00Z"},
                {"name": "archive", "createdAt": "2024-01-02T00:00:00Z"},
                {"name": "temp", "createdAt": "2024-01-03T00:00:00Z"}
            ]
        }
        
        with patch.object(client, '_make_request', new_callable=AsyncMock) as mock_req:
            mock_req.return_value = mock_list_response
            
            buckets = await client.list_buckets()
            
            assert len(buckets) == 3
            assert buckets[0].name == "backup"
            assert buckets[1].name == "archive"
            assert buckets[2].name == "temp"
    
    @pytest.mark.asyncio
    async def test_object_listing_with_pagination(self):
        """Test paginated object listing"""
        client = OmnixClient(
            endpoint="localhost:9000",
            access_key="admin",
            secret_key="password"
        )
        
        # First page
        mock_list_response_1 = MagicMock()
        mock_list_response_1.status_code = 200
        mock_list_response_1.json.return_value = {
            "contents": [
                {
                    "key": "file1.txt",
                    "size": 100,
                    "etag": "etag1",
                    "lastModified": "2024-01-01T00:00:00Z"
                },
                {
                    "key": "file2.txt",
                    "size": 200,
                    "etag": "etag2",
                    "lastModified": "2024-01-02T00:00:00Z"
                }
            ],
            "isTruncated": True,
            "continuationToken": "token-page-2",
            "commonPrefixes": []
        }
        
        with patch.object(client, '_make_request', new_callable=AsyncMock) as mock_req:
            mock_req.return_value = mock_list_response_1
            
            result_page_1 = await client.list_objects(
                bucket_name="archive",
                max_keys=2
            )
            
            assert len(result_page_1.objects) == 2
            assert result_page_1.is_truncated is True
            assert result_page_1.continuation_token == "token-page-2"
            assert result_page_1.objects[0].object_name == "file1.txt"
            assert result_page_1.objects[1].object_name == "file2.txt"
    
    @pytest.mark.asyncio
    async def test_multiple_client_instances(self):
        """Test multiple concurrent client instances"""
        client1 = OmnixClient(
            endpoint="localhost:9000",
            access_key="admin1",
            secret_key="password1"
        )
        
        client2 = OmnixClient(
            endpoint="localhost:9001",
            access_key="admin2",
            secret_key="password2"
        )
        
        assert client1.access_key == "admin1"
        assert client2.access_key == "admin2"
        assert client1.base_url != client2.base_url
    
    @pytest.mark.asyncio
    async def test_error_handling_chain(self):
        """Test error handling across multiple operations"""
        client = OmnixClient(
            endpoint="localhost:9000",
            access_key="admin",
            secret_key="password"
        )
        
        from omnixstorage.error import AuthenticationError

        with patch.object(client._http, 'get', new_callable=AsyncMock) as mock_get:
            mock_response = MagicMock()
            mock_response.status_code = 401
            mock_get.return_value = mock_response

            with pytest.raises(AuthenticationError):
                await client._make_request("GET", "/unauthorized")


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
