import asyncio
from datetime import datetime, timedelta, timezone

import pytest

from omnixstorage.client import OmnixClient
from omnixstorage.error import ValidationError


class DummyStreamResponse:
    def __init__(self, data: bytes):
        self.status_code = 200
        self._data = data
        self.closed = False

    async def aiter_bytes(self, chunk_size):
        for index in range(0, len(self._data), chunk_size):
            yield self._data[index:index + chunk_size]

    async def aclose(self):
        self.closed = True


class DummyResponse:
    def __init__(self, status_code=200, headers=None):
        self.status_code = status_code
        self.headers = headers or {}

    def json(self):
        return {"url": "http://example.com/presigned"}


@pytest.mark.asyncio
async def test_presigned_url_expiration_validation(monkeypatch: pytest.MonkeyPatch) -> None:
    client = OmnixClient()

    with pytest.raises(ValidationError):
        await client.presigned_get_object("bucket", "obj", expires_in_seconds=0)

    with pytest.raises(ValidationError):
        await client.presigned_get_object("bucket", "obj", expires_in_seconds=8 * 24 * 3600)

    async def fake_request(*args, **kwargs):
        return DummyResponse()

    monkeypatch.setattr(client, "_make_request", fake_request)

    before = datetime.now(timezone.utc)
    result = await client.presigned_get_object("bucket", "obj", expires_in_seconds=120)
    after = datetime.now(timezone.utc)

    assert result.expires_at >= before + timedelta(seconds=120)
    assert result.expires_at <= after + timedelta(seconds=120)


@pytest.mark.asyncio
async def test_get_object_stream_yields_chunks(monkeypatch: pytest.MonkeyPatch) -> None:
    client = OmnixClient()
    data = b"abcdef"

    async def fake_request(*args, **kwargs):
        return DummyStreamResponse(data)

    monkeypatch.setattr(client, "_make_request", fake_request)

    received = []
    async for part in client.get_object_stream("bucket", "obj", chunk_size=2):
        received.append(part)

    assert received == [b"ab", b"cd", b"ef"]


@pytest.mark.asyncio
async def test_get_object_stream_progress_callback(monkeypatch: pytest.MonkeyPatch) -> None:
    client = OmnixClient()
    data = b"abcdef"
    progress = []

    async def fake_request(*args, **kwargs):
        return DummyStreamResponse(data)

    def on_progress(size):
        progress.append(size)

    monkeypatch.setattr(client, "_make_request", fake_request)

    async for _ in client.get_object_stream("bucket", "obj", chunk_size=3, progress_callback=on_progress):
        pass

    assert progress == [3, 3]


@pytest.mark.asyncio
async def test_put_object_stream_uploads_chunks(monkeypatch: pytest.MonkeyPatch) -> None:
    client = OmnixClient()
    sent = []

    async def fake_put(url, content=None, headers=None, **kwargs):
        async for part in content:
            sent.append(part)
        return DummyResponse(status_code=200, headers={"ETag": "etag"})

    monkeypatch.setattr(client._http, "put", fake_put)

    async def data():
        yield b"one"
        yield b"two"

    result = await client.put_object_stream("bucket", "obj", data())

    assert sent == [b"one", b"two"]
    assert result.etag == "etag"


@pytest.mark.asyncio
async def test_put_object_stream_progress_callback(monkeypatch: pytest.MonkeyPatch) -> None:
    client = OmnixClient()
    progress = []

    async def fake_put(url, content=None, headers=None, **kwargs):
        async for part in content:
            progress.append(len(part))
        return DummyResponse(status_code=200, headers={"ETag": "etag"})

    monkeypatch.setattr(client._http, "put", fake_put)

    async def data():
        yield b"abc"
        yield b"de"

    await client.put_object_stream("bucket", "obj", data(), progress_callback=lambda size: progress.append(size))

    assert progress == [3, 3, 2, 2]
