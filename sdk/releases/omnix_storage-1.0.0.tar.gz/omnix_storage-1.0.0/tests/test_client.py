"""
Tests for OmnixClient
"""

import pytest
import asyncio
from datetime import datetime
from io import BytesIO
from unittest.mock import Mock, AsyncMock, patch, MagicMock

from omnixstorage import (
    OmnixClient,
    Bucket,
    ObjectMetadata,
    ListObjectsResult,
    PutObjectResult,
)
from omnixstorage.error import (
    ObjectNotFoundException,
    BucketNotFoundException,
    ServerException,
)


class TestBucketOperations:
    """Tests for bucket operations"""
    
    @pytest.mark.asyncio
    async def test_bucket_exists_true(self):
        """Test checking if bucket exists (exists)"""
        client = OmnixClient()
        
        mock_response = MagicMock()
        mock_response.status_code = 200

        with patch.object(client, '_make_request', new_callable=AsyncMock) as mock_req:
            mock_req.return_value = mock_response

            exists = await client.bucket_exists("my-bucket")

            assert exists is True
    
    @pytest.mark.asyncio
    async def test_bucket_exists_false(self):
        """Test checking if bucket exists (not exists)"""
        client = OmnixClient()
        
        with patch.object(client, '_make_request', new_callable=AsyncMock) as mock_req:
            mock_req.side_effect = ServerException("Not found", 404)
            
            exists = await client.bucket_exists("missing-bucket")
            
            assert exists is False
    
    @pytest.mark.asyncio
    async def test_make_bucket(self):
        """Test creating a bucket"""
        client = OmnixClient()
        
        with patch.object(client, '_make_request', new_callable=AsyncMock) as mock_req:
            mock_req.return_value = AsyncMock()
            
            await client.make_bucket("new-bucket")
            
            mock_req.assert_called_once()
            call_args = mock_req.call_args
            assert "new-bucket" in str(call_args)
    
    @pytest.mark.asyncio
    async def test_list_buckets(self):
        """Test listing buckets"""
        client = OmnixClient()
        
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "buckets": [
                {
                    "name": "bucket1",
                    "createdAt": "2024-01-01T00:00:00Z"
                },
                {
                    "name": "bucket2",
                    "createdAt": "2024-01-02T00:00:00Z"
                }
            ]
        }
        
        with patch.object(client, '_make_request', new_callable=AsyncMock) as mock_req:
            mock_req.return_value = mock_response
            
            buckets = await client.list_buckets()
            
            assert len(buckets) == 2
            assert buckets[0].name == "bucket1"
            assert buckets[1].name == "bucket2"


class TestObjectOperations:
    """Tests for object operations"""
    
    @pytest.mark.asyncio
    async def test_put_object(self):
        """Test uploading an object"""
        client = OmnixClient()
        
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.headers = {"ETag": "abc123"}
        
        with patch.object(client, '_make_request', new_callable=AsyncMock) as mock_req:
            mock_req.return_value = mock_response
            
            # Use a sync file-like object since the client reads synchronously
            mock_file = BytesIO(b"test data")
            
            result = await client.put_object(
                bucket_name="test-bucket",
                object_name="test.txt",
                data=mock_file,
                content_type="text/plain"
            )
            
            assert result.bucket_name == "test-bucket"
            assert result.object_name == "test.txt"
            assert result.etag == "abc123"
    
    @pytest.mark.asyncio
    async def test_get_object(self):
        """Test downloading an object"""
        client = OmnixClient()
        
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.content = b"file content"
        mock_response.headers = {
            "Content-Type": "text/plain",
            "Content-Length": "12",
            "ETag": "def456"
        }
        
        with patch.object(client, '_make_request', new_callable=AsyncMock) as mock_req:
            mock_req.return_value = mock_response
            
            mock_output = BytesIO()
            
            result = await client.get_object(
                bucket_name="test-bucket",
                object_name="test.txt",
                output=mock_output
            )
            
            assert result.bucket_name == "test-bucket"
            assert result.object_name == "test.txt"
            assert result.size == 12
            assert mock_output.getvalue() == b"file content"
    
    @pytest.mark.asyncio
    async def test_get_object_not_found(self):
        """Test downloading a non-existent object"""
        client = OmnixClient()
        
        with patch.object(client, '_make_request', new_callable=AsyncMock) as mock_req:
            mock_req.side_effect = ServerException("Not found", 404)
            
            mock_output = AsyncMock()
            
            with pytest.raises(ObjectNotFoundException):
                await client.get_object(
                    bucket_name="test-bucket",
                    object_name="missing.txt",
                    output=mock_output
                )
    
    @pytest.mark.asyncio
    async def test_stat_object(self):
        """Test getting object metadata"""
        client = OmnixClient()
        
        mock_response = AsyncMock()
        mock_response.status_code = 200
        mock_response.headers = {
            "Content-Type": "text/plain",
            "Content-Length": "1024",
            "ETag": "ghi789"
        }
        
        with patch.object(client, '_make_request', new_callable=AsyncMock) as mock_req:
            mock_req.return_value = mock_response
            
            result = await client.stat_object(
                bucket_name="test-bucket",
                object_name="test.txt"
            )
            
            assert result.object_name == "test.txt"
            assert result.size == 1024
            assert result.content_type == "text/plain"
    
    @pytest.mark.asyncio
    async def test_remove_object(self):
        """Test deleting an object"""
        client = OmnixClient()
        
        with patch.object(client, '_make_request', new_callable=AsyncMock) as mock_req:
            mock_req.return_value = AsyncMock()
            
            await client.remove_object(
                bucket_name="test-bucket",
                object_name="test.txt"
            )
            
            mock_req.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_list_objects(self):
        """Test listing objects in a bucket"""
        client = OmnixClient()
        
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "contents": [
                {
                    "key": "file1.txt",
                    "size": 100,
                    "etag": "abc123",
                    "lastModified": "2024-01-01T00:00:00Z"
                },
                {
                    "key": "file2.txt",
                    "size": 200,
                    "etag": "def456",
                    "lastModified": "2024-01-02T00:00:00Z"
                }
            ],
            "isTruncated": False,
            "commonPrefixes": []
        }
        
        with patch.object(client, '_make_request', new_callable=AsyncMock) as mock_req:
            mock_req.return_value = mock_response
            
            result = await client.list_objects(bucket_name="test-bucket")
            
            assert len(result.objects) == 2
            assert result.objects[0].object_name == "file1.txt"
            assert result.objects[0].size == 100
            assert result.is_truncated is False


class TestHealthAndCleanup:
    """Tests for health check and cleanup"""
    
    @pytest.mark.asyncio
    async def test_health_check_success(self):
        """Test successful health check"""
        client = OmnixClient()
        
        with patch.object(client, '_make_request', new_callable=AsyncMock) as mock_req:
            mock_req.return_value = AsyncMock()
            
            is_healthy = await client.health()
            
            assert is_healthy is True
    
    @pytest.mark.asyncio
    async def test_health_check_failure(self):
        """Test failed health check"""
        client = OmnixClient()
        
        with patch.object(client, '_make_request', new_callable=AsyncMock) as mock_req:
            mock_req.side_effect = Exception("Connection failed")
            
            is_healthy = await client.health()
            
            assert is_healthy is False
    
    @pytest.mark.asyncio
    async def test_context_manager(self):
        """Test using client as context manager"""
        client = OmnixClient()
        
        with patch.object(client, 'close', new_callable=AsyncMock) as mock_close:
            async with client:
                pass
            
            mock_close.assert_called_once()


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
