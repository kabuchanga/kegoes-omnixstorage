"""Unit tests for Phase 4.3 MD5 integrity verification."""

import hashlib
import pytest

from omnixstorage.multipart import (
    MultipartUploadSession,
    UploadPartResult,
)


class TestMD5IntegrityBasics:
    """Tests for MD5 integrity verification basics."""

    def test_compute_md5_simple_data(self):
        """Test MD5 computation for simple data."""
        data = b"Hello, World!"
        expected_md5 = hashlib.md5(data).hexdigest()
        
        actual_md5 = hashlib.md5(data).hexdigest()
        
        assert actual_md5 == expected_md5

    def test_compute_md5_large_data(self):
        """Test MD5 computation for large data chunks."""
        # 5MB chunk as would be in a part
        data = b"X" * (5 * 1024 * 1024)
        expected_md5 = hashlib.md5(data).hexdigest()
        
        actual_md5 = hashlib.md5(data).hexdigest()
        
        assert actual_md5 == expected_md5
        assert len(actual_md5) == 32  # MD5 hex is 32 chars

    def test_compute_md5_empty_data(self):
        """Test MD5 computation for empty data."""
        data = b""
        expected_md5 = "d41d8cd98f00b204e9800998ecf8427e"  # MD5 of empty string
        
        actual_md5 = hashlib.md5(data).hexdigest()
        
        assert actual_md5 == expected_md5

    def test_hash_consistency_across_calls(self):
        """Test that hashing the same data produces same result."""
        data = b"Consistent test data"
        
        hash1 = hashlib.md5(data).hexdigest()
        hash2 = hashlib.md5(data).hexdigest()
        hash3 = hashlib.md5(data).hexdigest()
        
        assert hash1 == hash2 == hash3

    def test_hash_differs_for_different_data(self):
        """Test that different data produces different hashes."""
        data1 = b"First data"
        data2 = b"Second data"
        
        hash1 = hashlib.md5(data1).hexdigest()
        hash2 = hashlib.md5(data2).hexdigest()
        
        assert hash1 != hash2

    def test_hash_differs_for_partial_modification(self):
        """Test that partial data modification changes hash."""
        data1 = b"A" * 1000
        data2 = b"A" * 999 + b"B"  # Last byte different
        
        hash1 = hashlib.md5(data1).hexdigest()
        hash2 = hashlib.md5(data2).hexdigest()
        
        assert hash1 != hash2


class TestPartIntegrity:
    """Tests for part integrity with MD5 verification."""

    def test_part_result_with_md5(self):
        """Test UploadPartResult with MD5 hash."""
        part = UploadPartResult(
            part_number=1,
            etag="abc123",
            size=1000,
            md5_hash="xyz789",
            verified=True
        )
        
        assert part.part_number == 1
        assert part.md5_hash == "xyz789"
        assert part.verified is True

    def test_part_result_verification_flag(self):
        """Test verification flag in part result."""
        unverified = UploadPartResult(
            part_number=1,
            etag="abc123",
            size=1000,
            verified=False
        )
        
        verified = UploadPartResult(
            part_number=1,
            etag="abc123",
            size=1000,
            verified=True
        )
        
        assert unverified.verified is False
        assert verified.verified is True

    def test_multiple_parts_integrity(self):
        """Test integrity tracking for multiple parts."""
        parts = [
            UploadPartResult(
                part_number=i,
                etag=f"etag-{i}",
                size=500,
                md5_hash=f"md5-{i}",
                verified=(i % 2 == 0)
            )
            for i in range(1, 6)
        ]
        
        verified_count = sum(1 for p in parts if p.verified)
        assert verified_count == 2  # parts 2, 4
        assert len(parts) == 5


class TestCompositeETag:
    """Tests for composite ETag calculation (AWS S3 standard)."""

    def test_composite_etag_format(self):
        """Test composite ETag format."""
        # AWS S3 composite ETag format: md5(concat(md5(parts...))) + "-partcount"
        
        # Simulate 2 parts
        part1_data = b"A" * 100
        part2_data = b"B" * 100
        
        part1_md5 = hashlib.md5(part1_data).digest()
        part2_md5 = hashlib.md5(part2_data).digest()
        
        concatenated = part1_md5 + part2_md5
        composite_md5 = hashlib.md5(concatenated).hexdigest()
        composite_etag = f"{composite_md5}-2"
        
        # Should have format: hexstring-2
        assert composite_etag.endswith("-2")
        assert len(composite_etag.split("-")[0]) == 32

    def test_composite_etag_parts_order_matters(self):
        """Test that part order affects composite ETag."""
        part1_data = b"A" * 1000
        part2_data = b"B" * 1000
        
        # ETag in correct order
        pm1 = hashlib.md5(part1_data).digest()
        pm2 = hashlib.md5(part2_data).digest()
        etag1 = hashlib.md5(pm1 + pm2).hexdigest()
        
        # ETag in reversed order
        etag2 = hashlib.md5(pm2 + pm1).hexdigest()
        
        # Should be different
        assert etag1 != etag2

    def test_composite_etag_consistency(self):
        """Test ETag is consistent when recalculated."""
        parts = [
            hashlib.md5(f"part-{i}".encode()).digest()
            for i in range(1, 5)
        ]
        
        concatenated = b"".join(parts)
        
        etag1 = hashlib.md5(concatenated).hexdigest()
        etag2 = hashlib.md5(concatenated).hexdigest()
        
        assert etag1 == etag2

    def test_composite_etag_many_parts(self):
        """Test composite ETag with many parts."""
        # Simulate 100 parts
        part_hashes = [
            hashlib.md5(f"part-{i}".encode()).digest()
            for i in range(1, 101)
        ]
        
        concatenated = b"".join(part_hashes)
        composite_md5 = hashlib.md5(concatenated).hexdigest()
        composite_etag = f"{composite_md5}-100"
        
        assert composite_etag.endswith("-100")
        assert len(composite_md5) == 32


class TestSessionIntegrity:
    """Tests for integrity data in session."""

    def test_session_with_integrity_data(self):
        """Test session can store integrity information."""
        session = MultipartUploadSession("integrity-test", "bucket", "file", part_size=500)
        
        for i in range(1, 4):
            part = UploadPartResult(
                part_number=i,
                etag=f"etag-{i}",
                size=500,
                md5_hash=f"md5-{i}",
                verified=(i % 2 == 1)  # 1, 3 are verified
            )
            session.uploaded_parts.append(part)
        
        # Count verified parts
        verified_count = sum(1 for p in session.uploaded_parts if p.verified)
        assert verified_count == 2

    def test_session_serialization_preserves_integrity(self):
        """Test that integrity data is preserved in serialization."""
        session = MultipartUploadSession("serialize-test", "bucket", "file", part_size=500)
        
        part = UploadPartResult(
            part_number=1,
            etag="test-etag",
            size=500,
            md5_hash="test-md5",
            verified=True
        )
        session.uploaded_parts.append(part)
        
        # Serialize and deserialize
        data = session.to_dict()
        restored = MultipartUploadSession.from_dict(data)
        
        # Check integrity data preserved
        assert len(restored.uploaded_parts) == 1
        restored_part = restored.uploaded_parts[0]
        assert restored_part.md5_hash == "test-md5"
        assert restored_part.verified is True

    def test_compute_aggregate_integrity(self):
        """Test computing aggregate integrity for all parts."""
        session = MultipartUploadSession("aggregate-test", "bucket", "file", part_size=500)
        
        # Add parts with varying verification status
        for i in range(1, 6):
            part = UploadPartResult(
                part_number=i,
                etag=f"etag-{i}",
                size=500,
                md5_hash=f"md5-{i}",
                verified=(i <= 3)  # First 3 verified
            )
            session.uploaded_parts.append(part)
        
        # Compute stats
        total_parts = len(session.uploaded_parts)
        verified_parts = sum(1 for p in session.uploaded_parts if p.verified)
        
        assert total_parts == 5
        assert verified_parts == 3
        
        # Integrity percentage
        integrity_pct = (verified_parts / total_parts) * 100
        assert integrity_pct == 60.0


class TestIntegrityFailureRecovery:
    """Tests for detecting and recovering from integrity failures."""

    def test_detect_integrity_mismatch(self):
        """Test detection of integrity mismatch."""
        # Part with mismatched hash
        part = UploadPartResult(
            part_number=1,
            etag="etag-abc123",
            size=500,
            md5_hash="md5-different-xyz789",
            verified=False  # Not verified = potential mismatch
        )
        
        # Flag for retry
        is_valid = (part.etag == part.md5_hash)
        assert is_valid is False

    def test_flag_unverified_parts(self):
        """Test flagging unverified parts for retry."""
        session = MultipartUploadSession("unverified-test", "bucket", "file", part_size=500)
        
        # Add mix of verified and unverified
        for i in range(1, 4):
            part = UploadPartResult(
                part_number=i,
                etag=f"etag-{i}",
                size=500,
                md5_hash=f"md5-{i}",
                verified=False
            )
            session.uploaded_parts.append(part)
        
        # Count unverified
        unverified = [p for p in session.uploaded_parts if not p.verified]
        assert len(unverified) == 3

    def test_integrity_recovery_list(self):
        """Test creating list of parts needing verification."""
        session = MultipartUploadSession("recovery-test", "bucket", "file", part_size=500)
        
        for i in range(1, 6):
            part = UploadPartResult(
                part_number=i,
                etag=f"etag-{i}",
                size=500,
                md5_hash=f"md5-{i}",
                verified=(i <= 2)  # First 2 verified
            )
            session.uploaded_parts.append(part)
        
        # Get parts needing verification
        needs_verification = [p for p in session.uploaded_parts if not p.verified]
        assert len(needs_verification) == 3
        assert needs_verification[0].part_number == 3
