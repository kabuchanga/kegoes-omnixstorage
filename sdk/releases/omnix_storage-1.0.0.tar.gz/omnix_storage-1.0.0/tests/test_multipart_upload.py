"""
Unit tests for multipart upload functionality.

Tests cover:
- Session initialization and lifecycle
- Part upload with retry logic
- File and stream uploads
- Error handling and edge cases
- Progress tracking and callbacks
"""

import pytest
import asyncio
import hashlib
from pathlib import Path
from io import BytesIO
from unittest.mock import Mock, AsyncMock, patch, MagicMock
from datetime import datetime, timezone

from omnixstorage.multipart import (
    MultipartUploadManager,
    MultipartUploadSession,
    UploadPartResult,
)


class TestMultipartUploadSessionDataclass:
    """Tests for MultipartUploadSession dataclass."""
    
    def test_session_creation(self):
        """Test session initialization."""
        session = MultipartUploadSession(
            upload_id="test-upload-123",
            bucket_name="test-bucket",
            object_key="test-object.zip"
        )
        
        assert session.upload_id == "test-upload-123"
        assert session.bucket_name == "test-bucket"
        assert session.object_key == "test-object.zip"
        assert isinstance(session.initiated_at, datetime)
    
    def test_session_not_expired(self):
        """Test session expiration check (not expired)."""
        session = MultipartUploadSession(
            upload_id="test-upload-123",
            bucket_name="test-bucket",
            object_key="test-object.zip",
            initiated_at=datetime.now(timezone.utc)
        )
        
        assert session.is_expired is False
    
    def test_session_expired(self):
        """Test session expiration check (expired)."""
        from datetime import timedelta
        
        old_time = datetime.now(timezone.utc) - timedelta(hours=25)
        session = MultipartUploadSession(
            upload_id="test-upload-123",
            bucket_name="test-bucket",
            object_key="test-object.zip",
            initiated_at=old_time
        )
        
        assert session.is_expired is True


class TestUploadPartResultDataclass:
    """Tests for UploadPartResult dataclass."""
    
    def test_part_result_creation(self):
        """Test part result initialization."""
        result = UploadPartResult(
            part_number=1,
            etag="test-etag",
            size=1024
        )
        
        assert result.part_number == 1
        assert result.etag == "test-etag"
        assert result.size == 1024
        assert isinstance(result.uploaded_at, datetime)


class TestMultipartUploadManagerInitialization:
    """Tests for MultipartUploadManager initialization."""
    
    def test_initialization_with_defaults(self):
        """Test initialization with default parameters."""
        client = AsyncMock()
        manager = MultipartUploadManager(
            client=client,
            bucket_name="test-bucket",
            object_key="test-object.zip"
        )
        
        assert manager.bucket_name == "test-bucket"
        assert manager.object_key == "test-object.zip"
        assert manager.part_size == 5 * 1024 * 1024  # 5MB default
        assert manager.max_retries == 3
        assert manager.session is None
        assert manager.parts == []
    
    def test_initialization_with_custom_part_size(self):
        """Test initialization with custom part size."""
        client = AsyncMock()
        custom_size = 10 * 1024 * 1024  # 10MB
        
        manager = MultipartUploadManager(
            client=client,
            bucket_name="test-bucket",
            object_key="test-object.zip",
            part_size=custom_size
        )
        
        assert manager.part_size == custom_size
    
    def test_initialization_with_metadata(self):
        """Test initialization with metadata."""
        client = AsyncMock()
        metadata = {"custom-key": "custom-value"}
        
        manager = MultipartUploadManager(
            client=client,
            bucket_name="test-bucket",
            object_key="test-object.zip",
            metadata=metadata
        )
        
        assert manager.metadata == metadata
    
    def test_part_size_validation_too_small(self):
        """Test part size validation (too small)."""
        client = AsyncMock()
        
        with pytest.raises(ValueError, match="must be at least 5MB"):
            MultipartUploadManager(
                client=client,
                bucket_name="test-bucket",
                object_key="test-object.zip",
                part_size=1 * 1024 * 1024  # 1MB - too small
            )
    
    def test_part_size_validation_too_large(self):
        """Test part size validation (too large)."""
        client = AsyncMock()
        
        with pytest.raises(ValueError, match="cannot exceed 5GB"):
            MultipartUploadManager(
                client=client,
                bucket_name="test-bucket",
                object_key="test-object.zip",
                part_size=6 * 1024 * 1024 * 1024  # 6GB - too large
            )


class TestMultipartUploadInitiate:
    """Tests for multipart upload initiation."""
    
    @pytest.mark.asyncio
    async def test_initiate_success(self):
        """Test successful upload initiation."""
        client = AsyncMock()
        client._make_request = AsyncMock(return_value={"uploadId": "upload-123"})
        
        manager = MultipartUploadManager(
            client=client,
            bucket_name="test-bucket",
            object_key="test-object.zip"
        )
        
        upload_id = await manager.initiate()
        
        assert upload_id == "upload-123"
        assert manager.session is not None
        assert manager.session.upload_id == "upload-123"
        assert manager.session.bucket_name == "test-bucket"
        assert manager.session.object_key == "test-object.zip"
    
    @pytest.mark.asyncio
    async def test_initiate_includes_metadata(self):
        """Test that metadata is included in initiate request."""
        client = AsyncMock()
        client._make_request = AsyncMock(return_value={"uploadId": "upload-123"})
        
        metadata = {"custom": "metadata"}
        manager = MultipartUploadManager(
            client=client,
            bucket_name="test-bucket",
            object_key="test-object.zip",
            metadata=metadata
        )
        
        await manager.initiate()
        
        # Verify metadata was included in request
        call_args = client._make_request.call_args
        assert call_args.kwargs.get("json", {}).get("metadata") == metadata
    
    @pytest.mark.asyncio
    async def test_initiate_failure(self):
        """Test initiate failure handling."""
        client = AsyncMock()
        client._make_request = AsyncMock(side_effect=Exception("Network error"))
        
        manager = MultipartUploadManager(
            client=client,
            bucket_name="test-bucket",
            object_key="test-object.zip"
        )
        
        with pytest.raises(Exception, match="Failed to initiate"):
            await manager.initiate()


class TestMultipartUploadPart:
    """Tests for uploading individual parts."""
    
    @pytest.mark.asyncio
    async def test_upload_part_success(self):
        """Test successful part upload."""
        client = AsyncMock()
        client._make_request = AsyncMock()
        
        manager = MultipartUploadManager(
            client=client,
            bucket_name="test-bucket",
            object_key="test-object.zip"
        )
        
        # Setup session
        manager.session = MultipartUploadSession(
            upload_id="upload-123",
            bucket_name="test-bucket",
            object_key="test-object.zip"
        )
        
        part_data = b"test part data"
        result = await manager.upload_part(1, part_data)
        
        assert result.part_number == 1
        assert result.size == len(part_data)
        assert result.etag is not None
        assert len(manager.parts) == 1
        assert manager.parts[0].part_number == 1
    
    @pytest.mark.asyncio
    async def test_upload_part_without_session(self):
        """Test part upload fails without session."""
        client = AsyncMock()
        manager = MultipartUploadManager(
            client=client,
            bucket_name="test-bucket",
            object_key="test-object.zip"
        )
        
        with pytest.raises(RuntimeError, match="Upload not initiated"):
            await manager.upload_part(1, b"data")
    
    @pytest.mark.asyncio
    async def test_upload_part_invalid_number(self):
        """Test part upload with invalid part number."""
        client = AsyncMock()
        manager = MultipartUploadManager(
            client=client,
            bucket_name="test-bucket",
            object_key="test-object.zip"
        )
        
        manager.session = MultipartUploadSession(
            upload_id="upload-123",
            bucket_name="test-bucket",
            object_key="test-object.zip"
        )
        
        # Part number too low
        with pytest.raises(ValueError, match="Part number must be"):
            await manager.upload_part(0, b"data")
        
        # Part number too high
        with pytest.raises(ValueError, match="Part number must be"):
            await manager.upload_part(10001, b"data")
    
    @pytest.mark.asyncio
    async def test_upload_part_oversized(self):
        """Test part upload with oversized data."""
        client = AsyncMock()
        manager = MultipartUploadManager(
            client=client,
            bucket_name="test-bucket",
            object_key="test-object.zip"
        )
        
        manager.session = MultipartUploadSession(
            upload_id="upload-123",
            bucket_name="test-bucket",
            object_key="test-object.zip"
        )
        
        # Create data exceeding 5GB
        oversized_data = b"x" * (6 * 1024 * 1024 * 1024)
        
        with pytest.raises(ValueError, match="exceeds 5GB"):
            await manager.upload_part(1, oversized_data)
    
    @pytest.mark.asyncio
    async def test_upload_part_with_retry(self):
        """Test part upload with retry logic."""
        client = AsyncMock()
        
        # Simulate failure first, then success
        responses = [Exception("Network error"), None]
        client._make_request = AsyncMock(side_effect=responses)
        
        manager = MultipartUploadManager(
            client=client,
            bucket_name="test-bucket",
            object_key="test-object.zip",
            retry_delay_ms=10  # Short delay for testing
        )
        
        manager.session = MultipartUploadSession(
            upload_id="upload-123",
            bucket_name="test-bucket",
            object_key="test-object.zip"
        )
        
        part_data = b"test part data"
        result = await manager.upload_part(1, part_data)
        
        # Should succeed after retry
        assert result.part_number == 1
        assert client._make_request.call_count == 2
    
    @pytest.mark.asyncio
    async def test_upload_part_max_retries_exceeded(self):
        """Test part upload fails after max retries."""
        client = AsyncMock()
        client._make_request = AsyncMock(side_effect=Exception("Network error"))
        
        manager = MultipartUploadManager(
            client=client,
            bucket_name="test-bucket",
            object_key="test-object.zip",
            max_retries=2,
            retry_delay_ms=10
        )
        
        manager.session = MultipartUploadSession(
            upload_id="upload-123",
            bucket_name="test-bucket",
            object_key="test-object.zip"
        )
        
        with pytest.raises(Exception, match="Failed to upload part"):
            await manager.upload_part(1, b"data")
        
        # Should attempt initial + max_retries calls
        assert client._make_request.call_count == manager.max_retries + 1
    
    @pytest.mark.asyncio
    async def test_upload_part_cancelled(self):
        """Test part upload handles cancellation."""
        client = AsyncMock()
        manager = MultipartUploadManager(
            client=client,
            bucket_name="test-bucket",
            object_key="test-object.zip"
        )
        
        manager.session = MultipartUploadSession(
            upload_id="upload-123",
            bucket_name="test-bucket",
            object_key="test-object.zip"
        )
        
        manager.cancel()
        
        with pytest.raises(asyncio.CancelledError):
            await manager.upload_part(1, b"data")


class TestMultipartUploadFile:
    """Tests for uploading complete files."""
    
    @pytest.mark.asyncio
    async def test_upload_file_success(self, tmp_path):
        """Test successful file upload."""
        client = AsyncMock()
        client._make_request = AsyncMock()
        
        # Create test file
        test_file = tmp_path / "test.bin"
        test_content = b"x" * (12 * 1024 * 1024)  # 12MB > 5MB default part size
        test_file.write_bytes(test_content)
        
        manager = MultipartUploadManager(
            client=client,
            bucket_name="test-bucket",
            object_key="test-object.zip",
            part_size=5 * 1024 * 1024
        )
        
        manager.session = MultipartUploadSession(
            upload_id="upload-123",
            bucket_name="test-bucket",
            object_key="test-object.zip"
        )
        
        # Mock complete method
        manager.complete = AsyncMock(return_value="final-etag")
        
        etag = await manager.upload_file(str(test_file))
        
        # Should upload in 3 parts (5MB + 5MB + 2MB)
        assert len(manager.parts) == 3
        assert etag == "final-etag"
    
    @pytest.mark.asyncio
    async def test_upload_file_not_found(self):
        """Test file upload with missing file."""
        client = AsyncMock()
        manager = MultipartUploadManager(
            client=client,
            bucket_name="test-bucket",
            object_key="test-object.zip"
        )
        
        with pytest.raises(FileNotFoundError):
            await manager.upload_file("/nonexistent/file.zip")
    
    @pytest.mark.asyncio
    async def test_upload_file_without_session(self, tmp_path):
        """Test file upload initiates session if needed."""
        client = AsyncMock()
        client._make_request = AsyncMock(return_value={"uploadId": "upload-123"})
        
        # Create small test file
        test_file = tmp_path / "test.bin"
        test_file.write_bytes(b"small")
        
        manager = MultipartUploadManager(
            client=client,
            bucket_name="test-bucket",
            object_key="test-object.zip"
        )
        
        # Mock complete
        manager.complete = AsyncMock(return_value="final-etag")
        
        etag = await manager.upload_file(str(test_file))
        
        # Should have initiated session
        assert manager.session is not None
        assert etag == "final-etag"


class TestMultipartUploadStream:
    """Tests for uploading from streams."""
    
    @pytest.mark.asyncio
    async def test_upload_stream_success(self):
        """Test successful stream upload."""
        client = AsyncMock()
        client._make_request = AsyncMock()
        
        manager = MultipartUploadManager(
            client=client,
            bucket_name="test-bucket",
            object_key="test-object.zip",
            part_size=5 * 1024 * 1024
        )
        
        manager.session = MultipartUploadSession(
            upload_id="upload-123",
            bucket_name="test-bucket",
            object_key="test-object.zip"
        )
        
        # Create test stream chunks
        async def test_stream():
            for _ in range(3):
                yield b"x" * (4 * 1024 * 1024)  # 4MB chunks
        
        manager.complete = AsyncMock(return_value="final-etag")
        
        etag = await manager.upload_stream(test_stream())
        
        assert len(manager.parts) == 3
        assert etag == "final-etag"
    
    @pytest.mark.asyncio
    async def test_upload_stream_without_session(self):
        """Test stream upload initiates session if needed."""
        client = AsyncMock()
        client._make_request = AsyncMock(return_value={"uploadId": "upload-123"})
        
        manager = MultipartUploadManager(
            client=client,
            bucket_name="test-bucket",
            object_key="test-object.zip"
        )
        
        async def test_stream():
            yield b"small data"
        
        manager.complete = AsyncMock(return_value="final-etag")
        
        etag = await manager.upload_stream(test_stream())
        
        assert manager.session is not None
        assert etag == "final-etag"


class TestMultipartUploadComplete:
    """Tests for completing multipart uploads."""
    
    @pytest.mark.asyncio
    async def test_complete_success(self):
        """Test successful multipart completion."""
        client = AsyncMock()
        client._make_request = AsyncMock(return_value={"etag": "final-etag"})
        
        manager = MultipartUploadManager(
            client=client,
            bucket_name="test-bucket",
            object_key="test-object.zip"
        )
        
        manager.session = MultipartUploadSession(
            upload_id="upload-123",
            bucket_name="test-bucket",
            object_key="test-object.zip"
        )
        
        # Add some parts
        manager.parts = [
            UploadPartResult(1, "etag1", 1024),
            UploadPartResult(2, "etag2", 2048),
        ]
        
        etag = await manager.complete()
        
        assert etag == "final-etag"
        # Verify parts were sent sorted by part number
        call_args = client._make_request.call_args
        parts_list = call_args.kwargs.get("json", {}).get("parts", [])
        assert parts_list[0]["partNumber"] == 1
        assert parts_list[1]["partNumber"] == 2
    
    @pytest.mark.asyncio
    async def test_complete_without_session(self):
        """Test complete fails without session."""
        client = AsyncMock()
        manager = MultipartUploadManager(
            client=client,
            bucket_name="test-bucket",
            object_key="test-object.zip"
        )
        
        with pytest.raises(RuntimeError, match="Upload not initiated"):
            await manager.complete()
    
    @pytest.mark.asyncio
    async def test_complete_without_parts(self):
        """Test complete fails without parts."""
        client = AsyncMock()
        manager = MultipartUploadManager(
            client=client,
            bucket_name="test-bucket",
            object_key="test-object.zip"
        )
        
        manager.session = MultipartUploadSession(
            upload_id="upload-123",
            bucket_name="test-bucket",
            object_key="test-object.zip"
        )
        
        with pytest.raises(ValueError, match="No parts uploaded"):
            await manager.complete()
    
    @pytest.mark.asyncio
    async def test_complete_with_retry(self):
        """Test complete with retry on failure."""
        client = AsyncMock()
        
        # Setup mock to fail once, then succeed
        call_count = 0
        async def mock_request(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise Exception("Network error")
            return {"etag": "final-etag"}
        
        client._make_request = AsyncMock(side_effect=mock_request)
        
        manager = MultipartUploadManager(
            client=client,
            bucket_name="test-bucket",
            object_key="test-object.zip",
            retry_delay_ms=10
        )
        
        manager.session = MultipartUploadSession(
            upload_id="upload-123",
            bucket_name="test-bucket",
            object_key="test-object.zip"
        )
        
        manager.parts = [UploadPartResult(1, "etag1", 1024)]
        
        etag = await manager.complete()
        
        assert etag == "final-etag"
        assert call_count == 2


class TestMultipartUploadAbort:
    """Tests for aborting multipart uploads."""
    
    @pytest.mark.asyncio
    async def test_abort_success(self):
        """Test successful upload abort."""
        client = AsyncMock()
        client._make_request = AsyncMock()
        
        manager = MultipartUploadManager(
            client=client,
            bucket_name="test-bucket",
            object_key="test-object.zip"
        )
        
        manager.session = MultipartUploadSession(
            upload_id="upload-123",
            bucket_name="test-bucket",
            object_key="test-object.zip"
        )
        
        await manager.abort()
        
        # Verify request was made
        client._make_request.assert_called_once()
        call_args = client._make_request.call_args
        assert call_args.kwargs.get("params", {}).get("uploadId") == "upload-123"
    
    @pytest.mark.asyncio
    async def test_abort_without_session(self):
        """Test abort without active session."""
        client = AsyncMock()
        manager = MultipartUploadManager(
            client=client,
            bucket_name="test-bucket",
            object_key="test-object.zip"
        )
        
        # Should not raise error
        await manager.abort()
        client._make_request.assert_not_called()
    
    @pytest.mark.asyncio
    async def test_abort_handles_errors(self):
        """Test abort handles errors gracefully."""
        client = AsyncMock()
        client._make_request = AsyncMock(side_effect=Exception("Network error"))
        
        manager = MultipartUploadManager(
            client=client,
            bucket_name="test-bucket",
            object_key="test-object.zip"
        )
        
        manager.session = MultipartUploadSession(
            upload_id="upload-123",
            bucket_name="test-bucket",
            object_key="test-object.zip"
        )
        
        # Should not raise - logs warning instead
        await manager.abort()


class TestMultipartUploadCancel:
    """Tests for cancelling uploads."""
    
    def test_cancel_flag(self):
        """Test cancel sets the flag."""
        client = AsyncMock()
        manager = MultipartUploadManager(
            client=client,
            bucket_name="test-bucket",
            object_key="test-object.zip"
        )
        
        assert manager._cancel_requested is False
        
        manager.cancel()
        
        assert manager._cancel_requested is True


class TestMultipartUploadContextManager:
    """Tests for context manager support."""
    
    @pytest.mark.asyncio
    async def test_context_manager_success(self):
        """Test context manager with successful upload."""
        client = AsyncMock()
        manager = MultipartUploadManager(
            client=client,
            bucket_name="test-bucket",
            object_key="test-object.zip"
        )
        
        async with manager as m:
            assert m is manager
    
    @pytest.mark.asyncio
    async def test_context_manager_exception_triggers_abort(self):
        """Test context manager aborts on exception."""
        client = AsyncMock()
        client._make_request = AsyncMock()
        
        manager = MultipartUploadManager(
            client=client,
            bucket_name="test-bucket",
            object_key="test-object.zip"
        )
        
        manager.session = MultipartUploadSession(
            upload_id="upload-123",
            bucket_name="test-bucket",
            object_key="test-object.zip"
        )
        
        try:
            async with manager as m:
                raise ValueError("Test error")
        except ValueError:
            pass
        
        # Should have called abort
        client._make_request.assert_called()


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
