"""Unit tests for Phase 4.3 resume capability."""

import asyncio
import json
import os
import tempfile
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import MagicMock, AsyncMock, patch, call
import pytest

from omnixstorage.multipart import (
    MultipartUploadManager,
    MultipartUploadSession,
    SessionManager,
    UploadPartResult,
)


class TestSessionManager:
    """Tests for SessionManager persistence layer."""

    @pytest.fixture
    def session_manager(self):
        """Create SessionManager instance."""
        return SessionManager()

    @pytest.fixture
    def sample_session(self):
        """Create a sample session for testing."""
        return MultipartUploadSession(
            upload_id="test-upload-001",
            bucket_name="test-bucket",
            object_key="test-object.bin",
            part_size=5242880,    # 5MB
        )

    @pytest.mark.asyncio
    async def test_save_and_load_session(self, session_manager, sample_session):
        """Test saving and loading a session."""
        try:
            await session_manager.save_session(sample_session)
            
            loaded = await session_manager.load_session(sample_session.upload_id)
            assert loaded is not None
            assert loaded.upload_id == sample_session.upload_id
            assert loaded.bucket_name == sample_session.bucket_name
            assert loaded.object_key == sample_session.object_key
        finally:
            # Cleanup
            await session_manager.delete_session(sample_session.upload_id)

    @pytest.mark.asyncio
    async def test_load_nonexistent_session(self, session_manager):
        """Test loading a session that doesn't exist."""
        result = await session_manager.load_session("nonexistent-upload-id-12345")
        assert result is None

    @pytest.mark.asyncio
    async def test_load_all_sessions(self, session_manager):
        """Test loading all active sessions."""
        # Create multiple sessions
        sessions = [
            MultipartUploadSession("upload-001-test", "bucket-1", "file1.bin", part_size=500),
            MultipartUploadSession("upload-002-test", "bucket-1", "file2.bin", part_size=500),
            MultipartUploadSession("upload-003-test", "bucket-2", "file3.bin", part_size=500),
        ]
        
        try:
            for session in sessions:
                await session_manager.save_session(session)
            
            all_sessions = await session_manager.load_all_sessions()
            assert len(all_sessions) >= 3
            upload_ids = [s.upload_id for s in all_sessions]
            assert "upload-001-test" in upload_ids
            assert "upload-002-test" in upload_ids
            assert "upload-003-test" in upload_ids
        finally:
            for session in sessions:
                await session_manager.delete_session(session.upload_id)

    @pytest.mark.asyncio
    async def test_delete_session(self, session_manager, sample_session):
        """Test deleting a session."""
        await session_manager.save_session(sample_session)
        
        loaded_before = await session_manager.load_session(sample_session.upload_id)
        assert loaded_before is not None
        
        await session_manager.delete_session(sample_session.upload_id)
        
        loaded_after = await session_manager.load_session(sample_session.upload_id)
        assert loaded_after is None

    @pytest.mark.asyncio
    async def test_delete_nonexistent_session(self, session_manager):
        """Test deleting a session that doesn't exist (should not raise)."""
        # Should not raise an exception
        await session_manager.delete_session("nonexistent-id-xyz")

    @pytest.mark.asyncio
    async def test_session_serialization_with_parts(self, session_manager):
        """Test session serialization with uploaded parts."""
        session = MultipartUploadSession("upload-004-test", "bucket", "file", part_size=500)
        
        # Simulate part uploads
        part_result = UploadPartResult(
            part_number=1,
            etag="abc123",
            size=500,
            md5_hash="xyz789",
            verified=True
        )
        session.uploaded_parts.append(part_result)
        
        try:
            await session_manager.save_session(session)
            loaded = await session_manager.load_session("upload-004-test")
            
            assert len(loaded.uploaded_parts) == 1
            assert loaded.uploaded_parts[0].part_number == 1
            assert loaded.uploaded_parts[0].verified is True
        finally:
            await session_manager.delete_session(session.upload_id)


class TestMultipartUploadSessionEnhancements:
    """Tests for enhanced MultipartUploadSession functionality."""

    @pytest.fixture
    def session(self):
        """Create a test session."""
        return MultipartUploadSession(
            upload_id="test-upload",
            bucket_name="test-bucket",
            object_key="test-file.bin",
            part_size=5242880,    # 5MB
        )

    def test_next_part_number(self, session):
        """Test next_part_number calculation."""
        assert session.next_part_number() == 1
        
        # Add some parts
        part1 = UploadPartResult(part_number=1, etag="e1", size=100)
        session.uploaded_parts.append(part1)
        assert session.next_part_number() == 2
        
        part2 = UploadPartResult(part_number=2, etag="e2", size=100)
        session.uploaded_parts.append(part2)
        assert session.next_part_number() == 3

    def test_next_part_number_with_gaps(self, session):
        """Test next_part_number with gaps in uploaded parts."""
        part1 = UploadPartResult(part_number=1, etag="e1", size=100)
        part3 = UploadPartResult(part_number=3, etag="e3", size=100)
        session.uploaded_parts = [part1, part3]
        # Should return next sequential
        assert session.next_part_number() == 4

    def test_to_dict_serialization(self, session):
        """Test session serialization to dict."""
        part1 = UploadPartResult(part_number=1, etag="abc123", size=100)
        session.uploaded_parts = [part1]
        session.metadata = {"custom": "value"}
        
        data = session.to_dict()
        assert data["uploadId"] == session.upload_id
        assert data["bucketName"] == session.bucket_name
        assert len(data["uploadedParts"]) == 1
        assert data["metadata"]["custom"] == "value"

    def test_from_dict_deserialization(self, session):
        """Test session deserialization from dict."""
        data = session.to_dict()
        
        restored = MultipartUploadSession.from_dict(data)
        assert restored.upload_id == session.upload_id
        assert restored.bucket_name == session.bucket_name

    def test_expiration_check(self):
        """Test session expiration detection."""
        # Active session (just created)
        active = MultipartUploadSession(
            "upload-2", "bucket", "file", part_size=500
        )
        assert not active.is_expired



class TestResumeCapability:
    """Tests for resume functionality in MultipartUploadManager."""

    @pytest.fixture
    def mock_client(self):
        """Create mock OmnixStorage client."""
        client = AsyncMock()
        return client

    @pytest.mark.asyncio
    async def test_resume_from_upload_id(self, mock_client):
        """Test resuming an upload from upload ID."""
        session = MultipartUploadSession(
            "test-upload-123", "bucket", "file", 5000
        )
        part1 = UploadPartResult(part_number=1, etag="etag1", size=5000, verified=True)
        session.uploaded_parts = [part1]
        
        session_mgr = SessionManager()
        
        try:
            await session_mgr.save_session(session)
            
            loaded = await session_mgr.load_session("test-upload-123")
            assert loaded is not None
            assert loaded.upload_id == "test-upload-123"
            assert loaded.bucket_name == "bucket"
            assert len(loaded.uploaded_parts) == 1
        finally:
            await session_mgr.delete_session("test-upload-123")

    @pytest.mark.asyncio
    async def test_resume_from_missing_upload(self, mock_client):
        """Test resuming from nonexistent upload ID."""
        session_mgr = SessionManager()
        
        loaded = await session_mgr.load_session("missing-upload-xyz")
        assert loaded is None

    @pytest.mark.asyncio
    async def test_list_active_uploads(self):
        """Test listing active uploads."""
        sessions_to_create = [
            MultipartUploadSession("upload-a-test", "bucket-1", "file1", part_size=500),
            MultipartUploadSession("upload-b-test", "bucket-1", "file2", part_size=500),
        ]
        
        session_mgr = SessionManager()
        
        try:
            for session in sessions_to_create:
                await session_mgr.save_session(session)
            
            all_sessions = await session_mgr.load_all_sessions()
            assert len(all_sessions) >= 2
            
            bucket1_sessions = [s for s in all_sessions if s.bucket_name == "bucket-1"]
            assert len(bucket1_sessions) >= 2
        finally:
            for session in sessions_to_create:
                await session_mgr.delete_session(session.upload_id)

    @pytest.mark.asyncio
    async def test_save_checkpoint(self):
        """Test saving a checkpoint during upload."""
        session = MultipartUploadSession("checkpoint-test", "bucket", "file", part_size=500)
        part1 = UploadPartResult(part_number=1, etag="etag1", size=500)
        session.uploaded_parts = [part1]
        
        session_mgr = SessionManager()
        
        try:
            await session_mgr.save_session(session)
            
            loaded = await session_mgr.load_session("checkpoint-test")
            assert len(loaded.uploaded_parts) == 1
        finally:
            await session_mgr.delete_session("checkpoint-test")

    @pytest.mark.asyncio
    async def test_resume_partial_upload(self):
        """Test resuming a partially uploaded file."""
        # Scenario: 10 parts total, 6 already uploaded
        session = MultipartUploadSession("partial-upload-test", "bucket", "file", part_size=500)
        for i in range(1, 7):
            part = UploadPartResult(
                part_number=i,
                etag=f"etag-{i}",
                size=500,
                verified=True
            )
            session.uploaded_parts.append(part)
        
        session_mgr = SessionManager()
        
        try:
            await session_mgr.save_session(session)
            
            loaded = await session_mgr.load_session("partial-upload-test")
            # Should have 6 parts
            assert len(loaded.uploaded_parts) == 6
            # Should start from part 7
            assert loaded.next_part_number() == 7
        finally:
            await session_mgr.delete_session("partial-upload-test")

    @pytest.mark.asyncio
    async def test_cleanup_expired_sessions(self):
        """Test cleanup of expired sessions."""
        session_mgr = SessionManager()
        
        # Create an active session (will be ~24 hours from now)
        active = MultipartUploadSession("active-cleanup-test", "bucket", "file", part_size=500)
        
        try:
            await session_mgr.save_session(active)
            
            # Cleanup should not delete this session (it's active)
            deleted_count = await session_mgr.cleanup_expired_sessions()
            
            # Verify active still exists (might not have been deleted)
            still_exists = await session_mgr.load_session("active-cleanup-test")
            assert still_exists is not None
        finally:
            await session_mgr.delete_session("active-cleanup-test")

    @pytest.mark.asyncio
    async def test_multiple_concurrent_resumes(self):
        """Test resuming multiple uploads concurrently."""
        sessions = [
            MultipartUploadSession("concurrent-1-test", "bucket", "file1", part_size=500),
            MultipartUploadSession("concurrent-2-test", "bucket", "file2", part_size=500),
            MultipartUploadSession("concurrent-3-test", "bucket", "file3", part_size=500),
        ]
        
        session_mgr = SessionManager()
        
        try:
            for session in sessions:
                await session_mgr.save_session(session)
            
            # Load all concurrently
            loaders = [
                session_mgr.load_session("concurrent-1-test"),
                session_mgr.load_session("concurrent-2-test"),
                session_mgr.load_session("concurrent-3-test"),
            ]
            managers = await asyncio.gather(*loaders)
            
            assert len([m for m in managers if m is not None]) == 3
            assert managers[0].bucket_name == "bucket"
            assert managers[1].object_key == "file2"
        finally:
            for session in sessions:
                await session_mgr.delete_session(session.upload_id)
