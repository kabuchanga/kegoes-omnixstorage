"""
pytest configuration and fixtures
"""

import pytest
import asyncio


@pytest.fixture
def event_loop():
    """Create an event loop for async tests"""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()


@pytest.fixture
def mock_omnix_endpoint():
    """Mock OmnixStorage endpoint URL"""
    return "http://localhost:9000"


@pytest.fixture
def mock_credentials():
    """Mock credentials for testing"""
    return {
        "access_key": "test-access-key",
        "secret_key": "test-secret-key"
    }


@pytest.fixture
def mock_bucket_name():
    """Mock bucket name"""
    return "test-bucket"


@pytest.fixture
def mock_object_name():
    """Mock object name"""
    return "test-object.txt"


@pytest.fixture
def mock_file_content():
    """Mock file content for testing"""
    return b"This is test file content"
