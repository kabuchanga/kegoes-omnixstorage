import httpx
import pytest

from omnixstorage.client import OmnixClient
from omnixstorage.error import AuthenticationError, NetworkError, ValidationError


class DummyResponse:
    def __init__(self, status_code: int) -> None:
        self.status_code = status_code


@pytest.mark.asyncio
async def test_validation_error_for_invalid_object_name() -> None:
    client = OmnixClient()

    with pytest.raises(ValidationError):
        client._validate_object_name("")

    with pytest.raises(ValidationError):
        client._validate_object_name("invalid name")


@pytest.mark.asyncio
async def test_network_error_after_retry_exhaustion(monkeypatch: pytest.MonkeyPatch) -> None:
    client = OmnixClient()

    async def raise_request_error(*args, **kwargs):
        request = httpx.Request("GET", "http://example.com")
        raise httpx.RequestError("connection failed", request=request)

    monkeypatch.setattr(client._http._client, "request", raise_request_error)

    with pytest.raises(NetworkError):
        await client._http.get("http://example.com")


@pytest.mark.asyncio
async def test_authentication_error_mapping(monkeypatch: pytest.MonkeyPatch) -> None:
    client = OmnixClient()

    async def fake_get(*args, **kwargs):
        return DummyResponse(status_code=401)

    monkeypatch.setattr(client._http, "get", fake_get)

    with pytest.raises(AuthenticationError):
        await client._make_request("GET", "/unauthorized")
