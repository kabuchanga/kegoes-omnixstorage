"""Unit tests for Phase 4.3 concurrent uploads capability."""

import asyncio
import io
import hashlib
from unittest.mock import AsyncMock
import pytest

from omnixstorage.multipart import (
    MultipartUploadSession,
    UploadPartResult,
    SessionManager,
)


class TestConcurrentUploadsBasics:
    """Basic tests for concurrent upload functionality."""

    @pytest.fixture
    def mock_client(self):
        """Create mock OmnixStorage client."""
        client = AsyncMock()
        return client

    def test_session_with_multiple_parts(self):
        """Test session can handle multiple parts."""
        session = MultipartUploadSession("upload-multi", "bucket", "file", part_size=500)
        
        for i in range(1, 6):
            part = UploadPartResult(
                part_number=i,
                etag=f"etag-{i}",
                size=500,
            )
            session.uploaded_parts.append(part)
        
        assert len(session.uploaded_parts) == 5
        assert session.next_part_number() == 6

    def test_concurrent_part_numbering(self):
        """Test that part numbers remain correct with concurrent uploads."""
        session = MultipartUploadSession("concurrent-num-test", "bucket", "file", part_size=500)
        
        # Simulate parts uploaded in non-sequential order
        parts_to_add = [3, 1, 4, 2, 5]
        for part_num in parts_to_add:
            part = UploadPartResult(
                part_number=part_num,
                etag=f"etag-{part_num}",
                size=500,
            )
            session.uploaded_parts.append(part)
        
        # All parts should be present
        part_numbers = [p.part_number for p in session.uploaded_parts]
        assert sorted(part_numbers) == [1, 2, 3, 4, 5]

    def test_part_size_validation(self):
        """Test that part sizes are reasonable."""
        session = MultipartUploadSession("size-test", "bucket", "file", part_size=5*1024*1024)
        
        # Minimum part size should be 5MB
        assert session.part_size >= 5 * 1024 * 1024

    @pytest.mark.asyncio
    async def test_concurrent_session_persistence(self):
        """Test that concurrent uploads persist session checkpoints."""
        session = MultipartUploadSession("concurrent-persist-test", "bucket", "file", part_size=500)
        
        # Add parts as if uploaded concurrently
        for i in range(1, 4):
            part = UploadPartResult(
                part_number=i,
                etag=f"etag-{i}",
                size=500,
            )
            session.uploaded_parts.append(part)
        
        session_mgr = SessionManager()
        
        try:
            await session_mgr.save_session(session)
            
            loaded = await session_mgr.load_session("concurrent-persist-test")
            assert len(loaded.uploaded_parts) == 3
            
            # Verify part numbers are preserved
            part_numbers = [p.part_number for p in loaded.uploaded_parts]
            assert 1 in part_numbers
            assert 2 in part_numbers
            assert 3 in part_numbers
        finally:
            await session_mgr.delete_session("concurrent-persist-test")

    @pytest.mark.asyncio
    async def test_concurrent_multiple_uploads(self):
        """Test handling multiple concurrent uploads."""
        session_mgr = SessionManager()
        
        sessions = [
            MultipartUploadSession("concurrent-1-multi", "bucket", "file1", part_size=500),
            MultipartUploadSession("concurrent-2-multi", "bucket", "file2", part_size=500),
            MultipartUploadSession("concurrent-3-multi", "bucket", "file3", part_size=500),
        ]
        
        try:
            # Save all concurrently
            save_tasks = [
                session_mgr.save_session(session)
                for session in sessions
            ]
            await asyncio.gather(*save_tasks)
            
            # Load all concurrently
            load_tasks = [
                session_mgr.load_session(session.upload_id)
                for session in sessions
            ]
            loaded = await asyncio.gather(*load_tasks)
            
            # All should be loaded
            assert all(s is not None for s in loaded)
            assert len(loaded) == 3
        finally:
            for session in sessions:
                await session_mgr.delete_session(session.upload_id)

    def test_parts_ordered_after_concurrent_upload(self):
        """Test that part ordering is consistent."""
        session = MultipartUploadSession("order-test", "bucket", "file", part_size=500)
        
        # Add parts in concurrent-like order (non-sequential)
        part_order = [2, 1, 4, 3, 5]
        for part_num in part_order:
            part = UploadPartResult(
                part_number=part_num,
                etag=f"etag-{part_num}",
                size=500,
            )
            session.uploaded_parts.append(part)
        
        # Serialize and deserialize
        data = session.to_dict()
        restored = MultipartUploadSession.from_dict(data)
        
        # All parts should still be present
        restored_numbers = [p.part_number for p in restored.uploaded_parts]
        assert sorted(restored_numbers) == [1, 2, 3, 4, 5]


class TestConcurrentWorkerPool:
    """Tests for concurrent worker pool behavior."""

    def test_worker_distribution(self):
        """Test that work can be distributed across workers."""
        # Simulate 4 parts with 2 workers
        parts_to_process = [1, 2, 3, 4]
        num_workers = 2
        
        # Each worker should process ~2 parts
        parts_per_worker = len(parts_to_process) // num_workers
        assert parts_per_worker == 2

    def test_worker_load_balancing(self):
        """Test load balancing with different part counts."""
        test_cases = [
            (10, 1),  # 10 parts, 1 worker
            (10, 2),  # 10 parts, 2 workers (5 each)
            (10, 4),  # 10 parts, 4 workers (2-3 each)
            (10, 8),  # 10 parts, 8 workers (1-2 each)
        ]
        
        for num_parts, num_workers in test_cases:
            # Each worker should get approximately equal work
            base_parts = num_parts // num_workers
            assert base_parts >= 0 if num_parts == 0 else base_parts >= 1

    @pytest.mark.asyncio
    async def test_concurrent_completion_order(self):
        """Test that all parts complete regardless of order."""
        completion_order = []
        
        async def simulate_upload(part_num):
            await asyncio.sleep(0.01 * (5 - part_num))  # Variable delay
            completion_order.append(part_num)
            return UploadPartResult(
                part_number=part_num,
                etag=f"etag-{part_num}",
                size=500,
            )
        
        # Launch concurrent uploads
        tasks = [simulate_upload(i) for i in range(1, 6)]
        results = await asyncio.gather(*tasks)
        
        # All should complete
        assert len(results) == 5
        assert all(r is not None for r in results)
        assert all(isinstance(r, UploadPartResult) for r in results)


class TestConcurrentUploadProgress:
    """Tests for progress tracking with concurrent uploads."""

    def test_progress_calculation(self):
        """Test progress calculation with multiple parts."""
        session = MultipartUploadSession("progress-test", "bucket", "file", part_size=500)
        
        # Add 3 out of 5 parts
        for i in range(1, 4):
            part = UploadPartResult(
                part_number=i,
                etag=f"etag-{i}",
                size=500,
            )
            session.uploaded_parts.append(part)
        
        # Progress should be 3/5
        uploaded_size = sum(p.size for p in session.uploaded_parts)
        assert uploaded_size == 1500

    def test_progress_aggregation(self):
        """Test that progress from multiple sources aggregates correctly."""
        session = MultipartUploadSession("agg-test", "bucket", "file", part_size=1000)
        
        # Simulate progress from 3 workers
        worker_progress = [500, 500, 1000]  # bytes uploaded per worker
        total_progress = sum(worker_progress)
        
        assert total_progress == 2000

    @pytest.mark.asyncio
    async def test_concurrent_progress_tracking(self):
        """Test progress tracking during concurrent uploads."""
        progress_updates = []
        
        session = MultipartUploadSession("concurrent-progress", "bucket", "file", part_size=500)
        
        async def upload_with_progress(part_num):
            part = UploadPartResult(
                part_number=part_num,
                etag=f"etag-{part_num}",
                size=500,
            )
            session.uploaded_parts.append(part)
            progress_updates.append(len(session.uploaded_parts) * 500)
            await asyncio.sleep(0.01)
            return part
        
        # Upload 4 parts concurrently
        await asyncio.gather(*[upload_with_progress(i) for i in range(1, 5)])
        
        # Should have recorded progress
        assert len(progress_updates) > 0

