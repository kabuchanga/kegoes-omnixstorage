"""
Phase 1 Tests: Type Hints, Logging, and Error Handling

Tests for:
- Type hints validation (mypy-like checks)
- Structured logging output
- Enhanced error messages with context
- Async context managers
"""

import pytest
import logging
import asyncio
import inspect
from io import BytesIO
from typing import get_type_hints

from omnixstorage.client import OmnixClient
from omnixstorage.error import (
    OmnixStorageException,
    BucketNotFoundException,
    ObjectNotFoundException,
    ServerException,
    AuthenticationException,
    AccessDeniedException,
    ValidationError,
)
from omnixstorage.models import Bucket, ObjectMetadata, ListObjectsResult, PutObjectResult


class TestTypeHints:
    """Tests for comprehensive type hints on public API."""
    
    def test_client_init_has_type_hints(self):
        """Verify OmnixClient.__init__ has type hints on all parameters."""
        hints = get_type_hints(OmnixClient.__init__)
        
        # Check that type hints include expected parameters
        expected_params = {
            'endpoint', 'username', 'password', 'access_key', 
            'secret_key', 'use_ssl', 'request_timeout', 'max_retries'
        }
        
        # Get hints (excluding 'self' and 'return')
        hint_keys = {k for k in hints.keys() if k not in ('self', 'return')}
        
        assert expected_params.issubset(hint_keys), \
            f"Missing type hints for: {expected_params - hint_keys}"
    
    def test_public_methods_have_return_types(self):
        """Verify all public async methods have return type hints."""
        public_methods = [
            'bucket_exists', 'make_bucket', 'remove_bucket', 'list_buckets',
            'put_object', 'get_object', 'stat_object', 'remove_object',
            'list_objects', 'presigned_get_object', 'health', 'close'
        ]
        
        for method_name in public_methods:
            method = getattr(OmnixClient, method_name)
            hints = get_type_hints(method)
            
            assert 'return' in hints, \
                f"Method {method_name} missing return type hint"
            
            # Return type should not be empty/None
            assert hints['return'] is not None, \
                f"Method {method_name} has empty return hint"
    
    def test_models_have_type_hints(self):
        """Verify data models have complete type hints."""
        models = [Bucket, ObjectMetadata, ListObjectsResult, PutObjectResult]
        
        for model in models:
            # Check that dataclass has fields with type hints
            assert hasattr(model, '__dataclass_fields__'), \
                f"{model.__name__} is not a dataclass"
            
            # All fields should have type annotations
            for field_name, field in model.__dataclass_fields__.items():
                assert field.type is not None, \
                    f"Field {model.__name__}.{field_name} missing type annotation"


class TestStructuredLogging:
    """Tests for structured logging in SDK operations."""
    
    @pytest.fixture
    def log_capture(self):
        """Fixture to capture log records."""
        log_records = []
        
        class ListHandler(logging.Handler):
            def emit(self, record):
                log_records.append(record)
        
        handler = ListHandler()
        logger = logging.getLogger('omnixstorage.client')
        logger.addHandler(handler)
        logger.setLevel(logging.DEBUG)
        
        yield log_records
        
        logger.removeHandler(handler)
    
    def test_client_init_logs_initialization(self, log_capture):
        """Verify OmnixClient logs initialization."""
        client = OmnixClient(endpoint="test:9000")
        
        # Should have debug and info logs about initialization
        debug_logs = [r for r in log_capture if r.levelno == logging.DEBUG]
        info_logs = [r for r in log_capture if r.levelno == logging.INFO]
        
        assert len(debug_logs) > 0, "No debug logs during initialization"
        assert len(info_logs) > 0, "No info logs during initialization"
        
        # Check log messages contain relevant context
        init_logs = [r.getMessage() for r in debug_logs + info_logs]
        assert any('endpoint' in msg.lower() for msg in init_logs), \
            "Logs should mention endpoint"
    
    @pytest.mark.asyncio
    async def test_logging_includes_operation_context(self, log_capture):
        """Verify logs include operation context (bucket, object names)."""
        client = OmnixClient(endpoint="localhost:9000")
        
        # Clear logs from initialization
        log_capture.clear()
        
        # Try validation (doesn't require actual server)
        try:
            client._validate_object_name("valid_object_name.txt")
        except Exception:
            pass
        
        # Should have logged the validation attempt
        # This is logged at debug level in actual usage
        
        # Clean up
        await client.close()
    
    def test_exception_handler_logs_errors(self, log_capture):
        """Verify exceptions are logged with context."""
        exc = ObjectNotFoundException("my-bucket", "my-object.txt")
        
        # The exception should contain contextual information
        assert "my-bucket" in str(exc)
        assert "my-object.txt" in str(exc)
        assert exc.status_code == 404


class TestEnhancedErrors:
    """Tests for enhanced error messages with operation context."""
    
    def test_bucket_not_found_includes_bucket_name(self):
        """Verify BucketNotFoundException includes bucket name."""
        exc = BucketNotFoundException("my-bucket")
        
        assert "my-bucket" in str(exc)
        assert exc.status_code == 404
        assert exc.error_code == "NoSuchBucket"
    
    def test_object_not_found_includes_context(self):
        """Verify ObjectNotFoundException includes bucket and object name."""
        exc = ObjectNotFoundException("my-bucket", "my-object.txt")
        
        message = str(exc)
        assert "my-bucket" in message
        assert "my-object.txt" in message
        assert exc.status_code == 404
        assert exc.error_code == "NoSuchKey"
    
    def test_server_exception_preserves_status_code(self):
        """Verify ServerException preserves HTTP status code."""
        exc = ServerException("Request failed", status_code=500, error_code="InternalError")
        
        assert exc.status_code == 500
        assert exc.error_code == "InternalError"
        assert "Request failed" in str(exc)
    
    def test_authentication_exception_with_context(self):
        """Verify AuthenticationException includes operation context."""
        exc = AuthenticationException("Invalid AWS signature for PUT /bucket/object")
        
        assert "Invalid AWS signature" in str(exc)
        assert exc.status_code == 401
        assert exc.error_code == "InvalidCredentials"
    
    def test_access_denied_exception(self):
        """Verify AccessDeniedException is properly constructed."""
        exc = AccessDeniedException("User 'admin' cannot delete bucket 'protected-bucket'")
        
        assert "admin" in str(exc)
        assert "protected-bucket" in str(exc)
        assert exc.status_code == 403
        assert exc.error_code == "AccessDenied"
    
    def test_exception_base_class(self):
        """Verify OmnixStorageException base class functionality."""
        exc = OmnixStorageException(
            "Custom error message",
            status_code=400,
            error_code="CustomError"
        )
        
        assert str(exc) == "Custom error message"
        assert exc.status_code == 400
        assert exc.error_code == "CustomError"


class TestAsyncContextManager:
    """Tests for async context manager support."""
    
    @pytest.mark.asyncio
    async def test_client_async_context_manager(self):
        """Verify OmnixClient supports async context manager."""
        async with OmnixClient(endpoint="localhost:9000") as client:
            assert client is not None
            assert hasattr(client, '_http')
    
    @pytest.mark.asyncio
    async def test_client_auto_closes_resources(self):
        """Verify async context manager properly closes resources."""
        client = OmnixClient(endpoint="localhost:9000")
        
        # Enter and exit context manager
        async with client:
            http_client = client._http
            assert http_client is not None
        
        # After exiting, client should be able to cleanup
        # (actual HTTP client closure is tested in integration tests)


class TestValidationWithContext:
    """Tests for validation that includes operation context in errors."""
    
    def test_validate_object_name_with_spaces(self):
        """Verify validation rejects spaces with helpful error."""
        client = OmnixClient()
        
        with pytest.raises(ValidationError) as exc_info:
            client._validate_object_name("my object.txt")
        
        error_msg = str(exc_info.value)
        assert "spaces" in error_msg.lower() or "space" in error_msg.lower()
        assert "underscore" in error_msg or "hyphen" in error_msg or "hyphens" in error_msg
    
    def test_validate_object_name_with_empty_string(self):
        """Verify validation rejects empty object names."""
        client = OmnixClient()
        
        with pytest.raises(ValidationError) as exc_info:
            client._validate_object_name("")
        
        error_msg = str(exc_info.value)
        assert "empty" in error_msg.lower()
    
    def test_validate_object_name_with_none(self):
        """Verify validation rejects None."""
        client = OmnixClient()
        
        with pytest.raises(ValidationError) as exc_info:
            client._validate_object_name(None)
        
        error_msg = str(exc_info.value)
        assert "empty" in error_msg.lower() or "null" in error_msg.lower()
    
    def test_validate_valid_object_names(self):
        """Verify validation accepts valid object names."""
        client = OmnixClient()
        
        valid_names = [
            "simple.txt",
            "with-dashes.pdf",
            "with_underscores.csv",
            "path/to/object.txt",
            "deep/nested/path/to/file.zip",
        ]
        
        for name in valid_names:
            # Should not raise any exception
            client._validate_object_name(name)


class TestEmptyFileRejection:
    """Tests for empty file rejection."""
    
    @pytest.mark.asyncio
    async def test_empty_bytes_rejected(self):
        """Verify empty byte strings are rejected."""
        client = OmnixClient()
        
        # In actual implementation, empty files should be rejected at put_object
        # This test documents the expected behavior
        empty_data = b""
        
        # When put_object is called with empty data, it should raise ValueError
        # (This would fail in actual server call but validation happens first)
        assert len(empty_data) == 0
        
        await client.close()


class TestTypeConsistency:
    """Tests for type consistency across type hints."""
    
    def test_return_types_are_consistent(self):
        """Verify async method return types are properly typed."""
        client = OmnixClient()
        
        methods_and_expected_types = {
            'bucket_exists': bool,
            'list_buckets': list,
            'health': bool,
        }
        
        for method_name, expected_type in methods_and_expected_types.items():
            method = getattr(client, method_name)
            hints = get_type_hints(method)
            
            # Verify return type annotation exists
            assert 'return' in hints, f"{method_name} missing return type"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
