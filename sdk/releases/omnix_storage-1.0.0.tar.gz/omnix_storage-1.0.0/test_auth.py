#!/usr/bin/env python3
"""Test authentication endpoint directly."""
import httpx
import json

async def test_auth():
    url = "http://localhost:9000/api/admin/auth/login"
    payload = {
        "Username": "admin",
        "Password": "omnix-console-2026"
    }
    
    print(f"Testing: POST {url}")
    print(f"Payload: {json.dumps(payload, indent=2)}")
    print()
    
    async with httpx.AsyncClient() as client:
        try:
            response = await client.post(url, json=payload)
            print(f"Status: {response.status_code}")
            print(f"Headers: {dict(response.headers)}")
            print(f"Body: {response.text}")
        except Exception as e:
            print(f"Error: {e}")

if __name__ == "__main__":
    import asyncio
    asyncio.run(test_auth())
