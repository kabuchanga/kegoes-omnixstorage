"""
Adaptive optimization for OmnixStorage SDK

Automatically tunes client parameters based on network conditions and performance measurements.
"""

import asyncio
import time
import logging
from dataclasses import dataclass
from typing import Optional, Dict, Any, Tuple
from enum import Enum

logger = logging.getLogger(__name__)


class ConnectionType(Enum):
    """Network connection classification."""
    VERY_FAST = "very_fast"  # >100 MB/s
    FAST = "fast"            # 50-100 MB/s
    MEDIUM = "medium"        # 10-50 MB/s
    SLOW = "slow"            # 1-10 MB/s
    VERY_SLOW = "very_slow"  # <1 MB/s


@dataclass
class ConnectionProfile:
    """Network connection profile."""
    
    bandwidth_mbps: float  # MB/s
    latency_ms: float      # milliseconds
    connection_type: ConnectionType
    measured_at: float     # timestamp
    
    def __str__(self) -> str:
        return (
            f"{self.connection_type.value}: "
            f"{self.bandwidth_mbps:.1f} MB/s, "
            f"{self.latency_ms:.1f}ms latency"
        )


@dataclass
class OptimizationResult:
    """Results of client optimization."""
    
    recommended_chunk_size: int
    recommended_workers: int
    recommended_buffer_size: int
    connection_profile: ConnectionProfile
    expected_improvement: float  # percentage
    applied: bool
    
    def __str__(self) -> str:
        return (
            f"Optimization: chunk={self.recommended_chunk_size//1024}KB, "
            f"workers={self.recommended_workers}, "
            f"buffer={self.recommended_buffer_size//1024}KB, "
            f"expected_improvement={self.expected_improvement:.1f}%"
        )


class NetworkProfiler:
    """
    Profile network performance characteristics.
    
    Measures bandwidth and latency to determine optimal client configuration.
    """
    
    def __init__(self, test_size_kb: int = 100):
        """
        Initialize network profiler.
        
        Args:
            test_size_kb: Size of test transfer in KB
        """
        self.test_size_kb = test_size_kb
        self._cached_profile: Optional[ConnectionProfile] = None
        self._cache_duration = 300  # 5 minutes
    
    async def measure_bandwidth(self, client: 'OmnixClient') -> float:
        """
        Measure current bandwidth by downloading a test object.
        
        Args:
            client: OmnixClient instance
            
        Returns:
            Bandwidth in MB/s
        """
        try:
            # Create test bucket if needed
            test_bucket = "profiler-test-bucket"
            try:
                await client.create_bucket(test_bucket)
            except Exception:
                pass  # Bucket may exist
            
            # Upload test object
            test_key = "bandwidth-test.bin"
            test_data = b"X" * (self.test_size_kb * 1024)
            
            try:
                await client.put_object(test_bucket, test_key, test_data)
            except Exception:
                pass  # May already exist
            
            # Measure download speed
            start = time.time()
            data = await client.get_object(test_bucket, test_key)
            elapsed = time.time() - start
            
            # Calculate bandwidth
            if elapsed > 0:
                bandwidth_mbps = (len(data) / elapsed) / (1024 * 1024)
                return bandwidth_mbps
            
            return 0.0
            
        except Exception as e:
            logger.warning(f"Failed to measure bandwidth: {e}")
            return 10.0  # Default assumption: 10 MB/s
    
    async def measure_latency(self, client: 'OmnixClient') -> float:
        """
        Measure round-trip latency with a HEAD request.
        
        Args:
            client: OmnixClient instance
            
        Returns:
            Latency in milliseconds
        """
        try:
            # Use health check for latency
            samples = []
            for _ in range(3):  # Average of 3 samples
                start = time.time()
                await client.health()
                elapsed = (time.time() - start) * 1000  # ms
                samples.append(elapsed)
                await asyncio.sleep(0.1)
            
            return sum(samples) / len(samples)
            
        except Exception as e:
            logger.warning(f"Failed to measure latency: {e}")
            return 50.0  # Default assumption: 50ms
    
    async def get_connection_profile(
        self,
        client: 'OmnixClient',
        use_cache: bool = True
    ) -> ConnectionProfile:
        """
        Get comprehensive connection profile.
        
        Args:
            client: OmnixClient instance
            use_cache: Whether to use cached profile if available
            
        Returns:
            ConnectionProfile with measurements
        """
        # Check cache
        if use_cache and self._cached_profile:
            age = time.time() - self._cached_profile.measured_at
            if age < self._cache_duration:
                logger.debug("Using cached connection profile")
                return self._cached_profile
        
        # Measure performance
        logger.info("Profiling network connection...")
        bandwidth = await self.measure_bandwidth(client)
        latency = await self.measure_latency(client)
        
        # Classify connection
        if bandwidth > 100:
            conn_type = ConnectionType.VERY_FAST
        elif bandwidth > 50:
            conn_type = ConnectionType.FAST
        elif bandwidth > 10:
            conn_type = ConnectionType.MEDIUM
        elif bandwidth > 1:
            conn_type = ConnectionType.SLOW
        else:
            conn_type = ConnectionType.VERY_SLOW
        
        profile = ConnectionProfile(
            bandwidth_mbps=bandwidth,
            latency_ms=latency,
            connection_type=conn_type,
            measured_at=time.time()
        )
        
        # Cache result
        self._cached_profile = profile
        
        logger.info(f"Connection profile: {profile}")
        return profile


class AdaptiveOptimizer:
    """
    Automatically optimize client parameters based on measurements.
    
    Analyzes network conditions and recommends optimal configuration for:
    - Chunk sizes for uploads/downloads
    - Worker counts for parallel operations
    - Buffer sizes for memory efficiency
    """
    
    def __init__(self):
        """Initialize adaptive optimizer."""
        self.profiler = NetworkProfiler()
        self._history: list[Tuple[float, ConnectionProfile]] = []
    
    def recommend_chunk_size(self, bandwidth: float, operation: str = "download") -> int:
        """
        Recommend optimal chunk size based on bandwidth.
        
        Args:
            bandwidth: Bandwidth in MB/s
            operation: "download" or "upload"
            
        Returns:
            Recommended chunk size in bytes
        """
        # Higher bandwidth → larger chunks for efficiency
        # Lower bandwidth → smaller chunks for responsiveness
        
        if bandwidth > 100:  # Very fast
            base_size = 10 * 1024 * 1024  # 10MB
        elif bandwidth > 50:  # Fast
            base_size = 5 * 1024 * 1024   # 5MB
        elif bandwidth > 10:  # Medium
            base_size = 2 * 1024 * 1024   # 2MB
        elif bandwidth > 1:   # Slow
            base_size = 512 * 1024        # 512KB
        else:  # Very slow
            base_size = 256 * 1024        # 256KB
        
        # Uploads can use slightly smaller chunks for progress granularity
        if operation == "upload":
            base_size = max(256 * 1024, base_size // 2)
        
        return base_size
    
    def recommend_workers(
        self,
        bandwidth: float,
        latency: float,
        operation: str = "download"
    ) -> int:
        """
        Recommend optimal worker count for parallel operations.
        
        Args:
            bandwidth: Bandwidth in MB/s
            latency: Latency in milliseconds
            operation: "download", "upload", or "mixed"
            
        Returns:
            Recommended worker count
        """
        # Higher bandwidth and latency benefit from more workers
        # Formula: workers = f(bandwidth) * f(latency)
        
        # Bandwidth factor
        if bandwidth > 100:
            bw_factor = 8
        elif bandwidth > 50:
            bw_factor = 6
        elif bandwidth > 10:
            bw_factor = 4
        else:
            bw_factor = 2
        
        # Latency factor (high latency benefits from more parallelism)
        if latency > 100:
            lat_factor = 2.0
        elif latency > 50:
            lat_factor = 1.5
        else:
            lat_factor = 1.0
        
        workers = int(bw_factor * lat_factor)
        
        # Clamp to reasonable range
        if operation == "upload":
            return max(2, min(workers, 8))   # 2-8 for uploads
        elif operation == "download":
            return max(2, min(workers, 12))  # 2-12 for downloads
        else:  # mixed
            return max(2, min(workers, 6))   # 2-6 for mixed
    
    def recommend_buffer_size(self, bandwidth: float) -> int:
        """
        Recommend optimal buffer pool size.
        
        Args:
            bandwidth: Bandwidth in MB/s
            
        Returns:
            Recommended buffer size in bytes
        """
        # Match chunk size recommendations
        return self.recommend_chunk_size(bandwidth, "download")
    
    def calculate_expected_improvement(
        self,
        current_config: Dict[str, Any],
        recommended_config: Dict[str, Any]
    ) -> float:
        """
        Estimate performance improvement from optimization.
        
        Args:
            current_config: Current configuration
            recommended_config: Recommended configuration
            
        Returns:
            Expected improvement percentage
        """
        # Simple heuristic: improvement based on parameter changes
        
        current_workers = current_config.get("workers", 1)
        rec_workers = recommended_config.get("workers", 1)
        worker_improvement = (rec_workers / current_workers - 1) * 50  # 50% weight
        
        current_chunk = current_config.get("chunk_size", 1024 * 1024)
        rec_chunk = recommended_config.get("chunk_size", 1024 * 1024)
        
        # Larger chunks are better up to a point
        if rec_chunk > current_chunk:
            chunk_improvement = min(30, (rec_chunk / current_chunk - 1) * 20)  # 20% weight
        else:
            chunk_improvement = 0
        
        total_improvement = max(0, worker_improvement + chunk_improvement)
        return min(total_improvement, 100)  # Cap at 100%
    
    async def optimize(
        self,
        client: 'OmnixClient',
        apply: bool = False
    ) -> OptimizationResult:
        """
        Analyze and optimize client configuration.
        
        Args:
            client: OmnixClient instance to optimize
            apply: Whether to automatically apply recommendations
            
        Returns:
            OptimizationResult with recommendations
        """
        logger.info("Starting adaptive optimization...")
        
        # Profile network
        profile = await self.profiler.get_connection_profile(client)
        
        # Record in history
        self._history.append((time.time(), profile))
        
        # Generate recommendations
        rec_chunk = self.recommend_chunk_size(profile.bandwidth_mbps)
        rec_workers = self.recommend_workers(profile.bandwidth_mbps, profile.latency_ms)
        rec_buffer = self.recommend_buffer_size(profile.bandwidth_mbps)
        
        # Get current config (if available)
        current_config = {
            "workers": 4,  # Default assumptions
            "chunk_size": 5 * 1024 * 1024,
            "buffer_size": 5 * 1024 * 1024
        }
        
        recommended_config = {
            "workers": rec_workers,
            "chunk_size": rec_chunk,
            "buffer_size": rec_buffer
        }
        
        # Calculate expected improvement
        expected_improvement = self.calculate_expected_improvement(
            current_config,
            recommended_config
        )
        
        result = OptimizationResult(
            recommended_chunk_size=rec_chunk,
            recommended_workers=rec_workers,
            recommended_buffer_size=rec_buffer,
            connection_profile=profile,
            expected_improvement=expected_improvement,
            applied=apply
        )
        
        # Apply if requested
        if apply:
            logger.info(f"Applying optimization: {result}")
            # Note: Actual application would require client API changes
            # For now, just log the recommendation
        
        logger.info(f"Optimization complete: {result}")
        return result
    
    def get_optimization_history(self) -> list[Tuple[float, ConnectionProfile]]:
        """
        Get history of connection profiles.
        
        Returns:
            List of (timestamp, profile) tuples
        """
        return self._history.copy()


class PerformanceMonitor:
    """
    Monitor ongoing performance and trigger re-optimization.
    
    Tracks metrics over time and detects when performance degrades,
    triggering adaptive re-optimization.
    """
    
    def __init__(self, check_interval: int = 300):
        """
        Initialize performance monitor.
        
        Args:
            check_interval: Seconds between optimization checks
        """
        self.check_interval = check_interval
        self.optimizer = AdaptiveOptimizer()
        self._last_check = 0
        self._baseline_profile: Optional[ConnectionProfile] = None
    
    async def should_reoptimize(
        self,
        client: 'OmnixClient',
        force: bool = False
    ) -> bool:
        """
        Check if re-optimization is needed.
        
        Args:
            client: OmnixClient instance
            force: Force check regardless of interval
            
        Returns:
            True if re-optimization recommended
        """
        now = time.time()
        
        # Check interval
        if not force and (now - self._last_check) < self.check_interval:
            return False
        
        self._last_check = now
        
        # Get current profile
        current = await self.optimizer.profiler.get_connection_profile(client, use_cache=False)
        
        # First check - establish baseline
        if self._baseline_profile is None:
            self._baseline_profile = current
            return True
        
        # Check for significant change (>30%)
        bw_change = abs(current.bandwidth_mbps - self._baseline_profile.bandwidth_mbps) / self._baseline_profile.bandwidth_mbps
        lat_change = abs(current.latency_ms - self._baseline_profile.latency_ms) / self._baseline_profile.latency_ms
        
        if bw_change > 0.3 or lat_change > 0.3:
            logger.info(f"Network conditions changed significantly, re-optimization recommended")
            self._baseline_profile = current
            return True
        
        return False
