"""
Exception classes for OmnixStorage SDK
"""

from typing import Optional


class OmnixStorageException(Exception):
    """
    Base exception for all OmnixStorage SDK errors.
    """
    
    def __init__(self, message: str, status_code: Optional[int] = None, error_code: Optional[str] = None) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.error_code = error_code


class NetworkError(OmnixStorageException):
    """Thrown when a network failure prevents a request from completing."""

    def __init__(self, message: str) -> None:
        super().__init__(message, error_code="NetworkError")


class ValidationError(OmnixStorageException):
    """Thrown when client-side input validation fails."""

    def __init__(self, message: str) -> None:
        super().__init__(message, status_code=400, error_code="InvalidArgument")


class BucketNotFoundException(OmnixStorageException):
    """Thrown when a bucket is not found."""
    
    def __init__(self, bucket_name: str) -> None:
        super().__init__(
            f"Bucket '{bucket_name}' not found.",
            status_code=404,
            error_code="NoSuchBucket"
        )


class BucketAlreadyExistsException(OmnixStorageException):
    """Thrown when trying to create a bucket that already exists."""
    
    def __init__(self, bucket_name: str) -> None:
        super().__init__(
            f"Bucket '{bucket_name}' already exists.",
            status_code=409,
            error_code="BucketAlreadyExists"
        )


class ObjectNotFoundException(OmnixStorageException):
    """Thrown when an object is not found."""
    
    def __init__(self, bucket_name: str, object_name: str) -> None:
        super().__init__(
            f"Object '{object_name}' not found in bucket '{bucket_name}'.",
            status_code=404,
            error_code="NoSuchKey"
        )


class InvalidObjectNameException(OmnixStorageException):
    """Thrown when an object name is invalid."""
    
    def __init__(self, object_name: str) -> None:
        super().__init__(f"Object name '{object_name}' is invalid.")


class AuthenticationException(OmnixStorageException):
    """Thrown when authentication fails."""
    
    def __init__(self, message: str) -> None:
        super().__init__(
            message,
            status_code=401,
            error_code="InvalidCredentials"
        )


class AuthenticationError(AuthenticationException):
    """Thrown when authentication fails (alias for AuthenticationException)."""


class ServerException(OmnixStorageException):
    """Thrown when the server returns an error."""
    
    def __init__(self, message: str, status_code: int, error_code: Optional[str] = None) -> None:
        super().__init__(message, status_code, error_code)


class ServerError(ServerException):
    """Thrown when the server returns an error (alias for ServerException)."""


class AccessDeniedException(OmnixStorageException):
    """Thrown when access is denied."""
    
    def __init__(self, message: str) -> None:
        super().__init__(
            message,
            status_code=403,
            error_code="AccessDenied"
        )
