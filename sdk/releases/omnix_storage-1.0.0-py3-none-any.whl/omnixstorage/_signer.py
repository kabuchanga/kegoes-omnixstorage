"""
AWS Signature V4 signer for OmnixStorage SDK
"""

import hashlib
import hmac
import json
import threading
from datetime import datetime, timezone
from typing import Dict, Optional
from urllib.parse import quote


class AwsSignatureV4Signer:
    """
    Thread-safe signer for AWS Signature Version 4.
    Uses a lock to ensure multiple threads don't create race conditions
    during concurrent signature generation.
    """
    
    def __init__(self, access_key: str, secret_key: str):
        self.access_key = access_key
        self.secret_key = secret_key
        self._lock = threading.Lock()  # Ensure thread-safety during signing
    
    def sign_request(
        self,
        method: str,
        host: str,
        path: str,
        query_params: Optional[Dict[str, str]] = None,
        headers: Optional[Dict[str, str]] = None,
        body: Optional[bytes] = None,
        timestamp: Optional[datetime] = None,
    ) -> Dict[str, str]:
        """
        Sign a request and return headers with authorization.
        Thread-safe: protects timestamp generation and signature calculation.
        """
        # Use lock to ensure thread-safe concurrent access
        with self._lock:
            if timestamp is None:
                timestamp = datetime.now(timezone.utc)
            
            amz_date = timestamp.strftime("%Y%m%dT%H%M%SZ")
            datestamp = timestamp.strftime("%Y%m%d")
            
            # Build headers for canonical request (must include X-Amz-Date and X-Amz-Content-Sha256)
            canonical_headers_dict = self._build_canonical_headers(headers or {})
            canonical_headers_dict["x-amz-date"] = amz_date
            
            canonical_headers_str = "\n".join(
                f"{k}:{v}" for k, v in sorted(canonical_headers_dict.items())
            ) + "\n"
            signed_headers = ";".join(sorted(canonical_headers_dict.keys()))
            
            canonical_querystring = self._build_canonical_querystring(query_params or {})
            payload_hash = self._hash_payload(body)
            
            canonical_request = (
                f"{method}\n"
                f"{path}\n"
                f"{canonical_querystring}\n"
                f"{canonical_headers_str}"
                f"{signed_headers}\n"
                f"{payload_hash}"
            )
            
            # String to sign
            credential_scope = f"{datestamp}/us-east-1/s3/aws4_request"
            canonical_request_hash = hashlib.sha256(
                canonical_request.encode()
            ).hexdigest()
            
            string_to_sign = "\n".join([
                "AWS4-HMAC-SHA256",
                amz_date,
                credential_scope,
                canonical_request_hash,
            ])
            
            # Signature
            signing_key = self._derive_signing_key(datestamp)
            signature = hmac.new(
                signing_key,
                string_to_sign.encode(),
                hashlib.sha256
            ).hexdigest()
            
            # Authorization header
            auth_header = (
                f"AWS4-HMAC-SHA256 Credential={self.access_key}/{credential_scope}, "
                f"SignedHeaders={signed_headers}, Signature={signature}"
            )
            
            return {
                "Authorization": auth_header,
                "X-Amz-Date": amz_date,
            }
    
    def _build_canonical_headers(self, headers: Dict[str, str]) -> Dict[str, str]:
        """Build canonical headers for signing."""
        canonical = {}
        for key, value in headers.items():
            canonical[key.lower()] = value.strip()
        return canonical
    
    def _build_canonical_querystring(self, params: Dict[str, str]) -> str:
        """
        Build canonical query string for AWS SigV4 signing.
        Parameters must be URL-encoded and sorted alphabetically.
        
        Special handling for S3 multipart API: query parameters with empty string values
        (like "uploads" in "?uploads") are signed without the '=' sign.
        """
        if not params:
            return ""
        
        # Sort parameters alphabetically by key
        sorted_params = sorted(params.items())
        
        # Build canonical query string with proper encoding
        # Query parameters in canonical form: key=value pairs joined by &
        # For empty values (used in S3 multipart API), omit the '='
        canonical_parts = []
        for k, v in sorted_params:
            # URL-encode key (safe='' means encode everything except unreserved chars)
            encoded_key = quote(str(k), safe='')
            
            # Handle empty values - these should be signed as just the key for S3 multipart
            if v == "":
                # Empty value: just the key (this handles "?uploads" format)
                canonical_parts.append(encoded_key)
            else:
                # Non-empty value: key=value format
                encoded_value = quote(str(v), safe='')
                canonical_parts.append(f"{encoded_key}={encoded_value}")
        
        return "&".join(canonical_parts)
    
    def _hash_payload(self, body: Optional[bytes]) -> str:
        """Hash the request payload. Uses UNSIGNED-PAYLOAD when body is None."""
        if body is None:
            return "UNSIGNED-PAYLOAD"
        return hashlib.sha256(body).hexdigest()
    
    def _derive_signing_key(self, datestamp: str) -> bytes:
        """Derive the signing key for AWS Signature V4."""
        k_date = hmac.new(
            f"AWS4{self.secret_key}".encode(),
            datestamp.encode(),
            hashlib.sha256
        ).digest()
        
        k_region = hmac.new(k_date, "us-east-1".encode(), hashlib.sha256).digest()
        k_service = hmac.new(k_region, "s3".encode(), hashlib.sha256).digest()
        k_signing = hmac.new(k_service, "aws4_request".encode(), hashlib.sha256).digest()
        
        return k_signing
    
    def generate_presigned_url(
        self,
        method: str,
        host: str,
        path: str,
        query_params: Optional[Dict[str, str]] = None,
        expires_in: int = 3600,
        expires_in_seconds: Optional[int] = None,
        timestamp: Optional[datetime] = None,
    ) -> str:
        """
        Generate a presigned URL with AWS Signature V4.
        """
        # Support both expires_in and expires_in_seconds for backward compatibility
        expiry = expires_in_seconds if expires_in_seconds is not None else expires_in
        
        if timestamp is None:
            timestamp = datetime.now(timezone.utc)
        
        amz_date = timestamp.strftime("%Y%m%dT%H%M%SZ")
        datestamp = timestamp.strftime("%Y%m%d")
        
        # Create credential scope
        credential_scope = f"{datestamp}/us-east-1/s3/aws4_request"
        
        # Prepare query parameters for presigned URL
        presigned_params = {
            "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
            "X-Amz-Credential": f"{self.access_key}/{credential_scope}",
            "X-Amz-Date": amz_date,
            "X-Amz-Expires": str(expiry),
            "X-Amz-SignedHeaders": "host",
        }
        
        if query_params:
            presigned_params.update(query_params)
        
        # Build canonical request
        canonical_querystring = self._build_canonical_querystring(presigned_params)
        payload_hash = self._hash_payload(None)
        
        canonical_request = "\n".join([
            method,
            path,
            canonical_querystring,
            "host:" + host,
            "",
            "host",
            payload_hash,
        ])
        
        # String to sign
        canonical_request_hash = hashlib.sha256(
            canonical_request.encode()
        ).hexdigest()
        
        string_to_sign = "\n".join([
            "AWS4-HMAC-SHA256",
            amz_date,
            credential_scope,
            canonical_request_hash,
        ])
        
        # Signature
        signing_key = self._derive_signing_key(datestamp)
        signature = hmac.new(
            signing_key,
            string_to_sign.encode(),
            hashlib.sha256
        ).hexdigest()
        
        # Build presigned URL
        presigned_params["X-Amz-Signature"] = signature
        
        url = f"http://{host}{path}"
        query_string = self._build_canonical_querystring(presigned_params)
        return f"{url}?{query_string}"
