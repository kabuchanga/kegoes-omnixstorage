"""
Streaming utilities for OmnixStorage SDK

This module provides advanced streaming capabilities including:
- Range request support for partial downloads
- Progressive streaming with constant memory usage
- Resume capability for interrupted downloads
- Stream pipeline optimization with prefetch
"""

import asyncio
import logging
import os
from pathlib import Path
from typing import Optional, AsyncIterator, Callable, Dict, List, Tuple
from dataclasses import dataclass

import aiofiles

logger = logging.getLogger(__name__)


@dataclass
class DownloadProgress:
    """Track download progress information."""
    
    total_bytes: int
    downloaded_bytes: int
    percentage: float
    chunk_size: int
    elapsed_seconds: float
    speed_mbps: float
    
    def __str__(self) -> str:
        return (
            f"{self.percentage:.1f}% "
            f"({self.downloaded_bytes}/{self.total_bytes} bytes) "
            f"@ {self.speed_mbps:.2f} MB/s"
        )


@dataclass
class RangeSpec:
    """Specification for a byte range request."""
    
    start: int
    end: Optional[int] = None
    
    def to_header(self) -> str:
        """Convert to HTTP Range header value."""
        if self.end is None:
            return f"bytes={self.start}-"
        return f"bytes={self.start}-{self.end}"
    
    @property
    def size(self) -> Optional[int]:
        """Calculate range size if end is specified."""
        if self.end is None:
            return None
        return self.end - self.start + 1


class CheckpointManager:
    """
    Manage download checkpoints for resume capability.
    
    Stores progress information to allow resuming interrupted downloads.
    """
    
    def __init__(self, checkpoint_dir: Optional[str] = None):
        """
        Initialize checkpoint manager.
        
        Args:
            checkpoint_dir: Directory to store checkpoint files
        """
        self.checkpoint_dir = checkpoint_dir or Path.home() / ".omnixstorage" / "checkpoints"
        Path(self.checkpoint_dir).mkdir(parents=True, exist_ok=True)
    
    def _get_checkpoint_path(self, bucket: str, key: str) -> Path:
        """Get checkpoint file path for a specific object."""
        safe_name = f"{bucket}_{key}".replace("/", "_").replace("\\", "_")
        return Path(self.checkpoint_dir) / f"{safe_name}.checkpoint"
    
    async def save_checkpoint(
        self,
        bucket: str,
        key: str,
        downloaded_bytes: int,
        total_bytes: int,
        local_path: str
    ) -> None:
        """
        Save download checkpoint.
        
        Args:
            bucket: Bucket name
            key: Object key
            downloaded_bytes: Bytes downloaded so far
            total_bytes: Total object size
            local_path: Local file path
        """
        checkpoint_path = self._get_checkpoint_path(bucket, key)
        checkpoint_data = {
            "bucket": bucket,
            "key": key,
            "downloaded_bytes": downloaded_bytes,
            "total_bytes": total_bytes,
            "local_path": local_path,
        }
        
        async with aiofiles.open(checkpoint_path, "w") as f:
            import json
            await f.write(json.dumps(checkpoint_data))
        
        logger.debug(f"Saved checkpoint: {downloaded_bytes}/{total_bytes} bytes")
    
    async def load_checkpoint(self, bucket: str, key: str) -> Optional[Dict]:
        """
        Load download checkpoint if exists.
        
        Args:
            bucket: Bucket name
            key: Object key
            
        Returns:
            Checkpoint data or None if not found
        """
        checkpoint_path = self._get_checkpoint_path(bucket, key)
        
        if not checkpoint_path.exists():
            return None
        
        try:
            async with aiofiles.open(checkpoint_path, "r") as f:
                import json
                content = await f.read()
                return json.loads(content)
        except Exception as e:
            logger.warning(f"Failed to load checkpoint: {e}")
            return None
    
    async def delete_checkpoint(self, bucket: str, key: str) -> None:
        """
        Delete checkpoint file.
        
        Args:
            bucket: Bucket name
            key: Object key
        """
        checkpoint_path = self._get_checkpoint_path(bucket, key)
        
        if checkpoint_path.exists():
            checkpoint_path.unlink()
            logger.debug(f"Deleted checkpoint for {bucket}/{key}")
    
    def get_downloaded_bytes(self, local_path: str) -> int:
        """
        Get number of bytes already downloaded.
        
        Args:
            local_path: Path to partial file
            
        Returns:
            Number of bytes in file
        """
        try:
            return os.path.getsize(local_path)
        except OSError:
            return 0


class RangeDownloader:
    """
    Coordinate multi-range concurrent downloads.
    
    Downloads multiple byte ranges concurrently and assembles them.
    """
    
    def __init__(
        self,
        max_concurrent_ranges: int = 4,
        range_size: int = 5 * 1024 * 1024  # 5MB per range
    ):
        """
        Initialize range downloader.
        
        Args:
            max_concurrent_ranges: Maximum concurrent range requests
            range_size: Size of each range in bytes
        """
        self.max_concurrent_ranges = max_concurrent_ranges
        self.range_size = range_size
    
    def calculate_ranges(
        self,
        start_byte: int,
        end_byte: int,
        chunk_size: Optional[int] = None
    ) -> List[RangeSpec]:
        """
        Calculate optimal byte ranges for parallel download.
        
        Args:
            start_byte: Starting byte position
            end_byte: Ending byte position
            chunk_size: Optional custom chunk size
            
        Returns:
            List of range specifications
        """
        chunk_size = chunk_size or self.range_size
        ranges = []
        
        current = start_byte
        while current <= end_byte:
            range_end = min(current + chunk_size - 1, end_byte)
            ranges.append(RangeSpec(start=current, end=range_end))
            current = range_end + 1
        
        return ranges
    
    async def download_ranges_parallel(
        self,
        ranges: List[RangeSpec],
        download_func: Callable[[RangeSpec], bytes]
    ) -> List[bytes]:
        """
        Download multiple ranges in parallel.
        
        Args:
            ranges: List of range specifications
            download_func: Async function to download a single range
            
        Returns:
            List of downloaded chunks in order
        """
        semaphore = asyncio.Semaphore(self.max_concurrent_ranges)
        
        async def download_with_semaphore(range_spec: RangeSpec) -> bytes:
            async with semaphore:
                return await download_func(range_spec)
        
        tasks = [download_with_semaphore(r) for r in ranges]
        chunks = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Check for errors
        for i, chunk in enumerate(chunks):
            if isinstance(chunk, Exception):
                raise Exception(f"Range download failed for {ranges[i]}: {chunk}")
        
        return chunks


class StreamPipeline:
    """
    Optimized streaming pipeline with prefetch and adaptive buffering.
    
    Provides:
    - Adaptive buffer sizing based on network speed
    - Prefetch pipeline to minimize latency
    - Backpressure handling
    """
    
    def __init__(
        self,
        min_buffer_size: int = 256 * 1024,  # 256KB
        max_buffer_size: int = 10 * 1024 * 1024,  # 10MB
        prefetch_depth: int = 2
    ):
        """
        Initialize stream pipeline.
        
        Args:
            min_buffer_size: Minimum buffer size
            max_buffer_size: Maximum buffer size
            prefetch_depth: Number of chunks to prefetch
        """
        self.min_buffer_size = min_buffer_size
        self.max_buffer_size = max_buffer_size
        self.prefetch_depth = prefetch_depth
        self.current_buffer_size = min_buffer_size
        
        # Performance tracking
        self._bytes_streamed = 0
        self._start_time = None
        self._chunk_times = []
    
    def calculate_adaptive_buffer_size(self, throughput_mbps: float) -> int:
        """
        Calculate optimal buffer size based on throughput.
        
        Args:
            throughput_mbps: Current throughput in MB/s
            
        Returns:
            Optimal buffer size in bytes
        """
        # Fast connection → larger buffers
        # Slow connection → smaller buffers
        
        if throughput_mbps > 100:  # Very fast
            target = self.max_buffer_size
        elif throughput_mbps > 50:  # Fast
            target = 5 * 1024 * 1024  # 5MB
        elif throughput_mbps > 10:  # Medium
            target = 2 * 1024 * 1024  # 2MB
        else:  # Slow
            target = self.min_buffer_size
        
        # Clamp to min/max
        return max(self.min_buffer_size, min(target, self.max_buffer_size))
    
    async def stream_with_prefetch(
        self,
        source_iterator: AsyncIterator[bytes]
    ) -> AsyncIterator[bytes]:
        """
        Stream data with prefetch pipeline.
        
        Args:
            source_iterator: Source data iterator
            
        Yields:
            Data chunks with prefetch optimization
        """
        import time
        
        buffer_queue = asyncio.Queue(maxsize=self.prefetch_depth)
        producer_done = asyncio.Event()
        producer_error = None
        
        async def producer():
            """Prefetch chunks into buffer queue."""
            nonlocal producer_error
            try:
                async for chunk in source_iterator:
                    await buffer_queue.put(chunk)
            except Exception as e:
                producer_error = e
            finally:
                producer_done.set()
        
        # Start producer task
        producer_task = asyncio.create_task(producer())
        
        try:
            # Start timing
            self._start_time = time.time()
            
            while True:
                # Check for producer errors
                if producer_error:
                    raise producer_error
                
                # Get next chunk with timeout
                try:
                    chunk = await asyncio.wait_for(
                        buffer_queue.get(),
                        timeout=1.0
                    )
                    
                    # Track performance
                    self._bytes_streamed += len(chunk)
                    self._chunk_times.append(time.time())
                    
                    # Adapt buffer size periodically
                    if len(self._chunk_times) >= 10:
                        elapsed = self._chunk_times[-1] - self._chunk_times[0]
                        if elapsed > 0:
                            throughput_mbps = (self._bytes_streamed / elapsed) / (1024 * 1024)
                            self.current_buffer_size = self.calculate_adaptive_buffer_size(throughput_mbps)
                        
                        # Reset tracking
                        self._chunk_times = self._chunk_times[-5:]
                    
                    yield chunk
                    
                except asyncio.TimeoutError:
                    # Check if producer is done
                    if producer_done.is_set() and buffer_queue.empty():
                        break
                    continue
                
        finally:
            # Cleanup
            producer_task.cancel()
            try:
                await producer_task
            except asyncio.CancelledError:
                pass


class ProgressTracker:
    """
    Track and report download/upload progress.
    
    Provides progress callbacks and statistics.
    """
    
    def __init__(
        self,
        total_bytes: int,
        callback: Optional[Callable[[DownloadProgress], None]] = None,
        callback_interval: float = 0.5  # seconds
    ):
        """
        Initialize progress tracker.
        
        Args:
            total_bytes: Total bytes to transfer
            callback: Optional progress callback function
            callback_interval: Minimum interval between callbacks
        """
        self.total_bytes = total_bytes
        self.callback = callback
        self.callback_interval = callback_interval
        
        self.downloaded_bytes = 0
        self.start_time = None
        self.last_callback_time = 0
    
    async def update(self, chunk_size: int) -> None:
        """
        Update progress with new chunk.
        
        Args:
            chunk_size: Size of chunk just downloaded
        """
        import time
        
        if self.start_time is None:
            self.start_time = time.time()
        
        self.downloaded_bytes += chunk_size
        current_time = time.time()
        
        # Invoke callback if interval elapsed
        if self.callback and (current_time - self.last_callback_time) >= self.callback_interval:
            elapsed = current_time - self.start_time
            speed_mbps = (self.downloaded_bytes / elapsed) / (1024 * 1024) if elapsed > 0 else 0
            percentage = (self.downloaded_bytes / self.total_bytes * 100) if self.total_bytes > 0 else 0
            
            progress = DownloadProgress(
                total_bytes=self.total_bytes,
                downloaded_bytes=self.downloaded_bytes,
                percentage=percentage,
                chunk_size=chunk_size,
                elapsed_seconds=elapsed,
                speed_mbps=speed_mbps
            )
            
            if asyncio.iscoroutinefunction(self.callback):
                await self.callback(progress)
            else:
                self.callback(progress)
            
            self.last_callback_time = current_time
    
    def is_complete(self) -> bool:
        """Check if download is complete."""
        return self.downloaded_bytes >= self.total_bytes
