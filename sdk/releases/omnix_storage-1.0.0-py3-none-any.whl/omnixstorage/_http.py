"""
HTTP client utilities for OmnixStorage SDK

Features:
- Connection pooling with configurable limits
- Automatic keep-alive for efficient reuse
- Exponential backoff retry logic
- Performance metrics collection
"""

import asyncio
import logging
import os
import time
from typing import Optional, Dict, Any

import httpx

from .error import NetworkError

logger = logging.getLogger(__name__)


class HttpClientMetrics:
    """Tracks connection pool performance metrics."""
    
    def __init__(self) -> None:
        self.total_requests = 0
        self.total_retries = 0
        self.total_errors = 0
        self.request_times = []  # List of (latency_ms) for recent requests
        self.connection_reuse_count = 0
        self.new_connections = 0
    
    def record_request(self, latency_ms: float, retried: bool = False) -> None:
        """Record request metrics."""
        self.total_requests += 1
        self.request_times.append(latency_ms)
        if len(self.request_times) > 1000:  # Keep recent 1000
            self.request_times.pop(0)
        if retried:
            self.total_retries += 1
    
    def record_error(self) -> None:
        """Record error."""
        self.total_errors += 1
    
    def get_stats(self) -> Dict[str, Any]:
        """Get current statistics."""
        if self.request_times:
            avg_latency = sum(self.request_times) / len(self.request_times)
            p95_latency = sorted(self.request_times)[int(len(self.request_times) * 0.95)]
        else:
            avg_latency = 0
            p95_latency = 0
        
        return {
            'total_requests': self.total_requests,
            'total_retries': self.total_retries,
            'total_errors': self.total_errors,
            'avg_latency_ms': round(avg_latency, 2),
            'p95_latency_ms': round(p95_latency, 2),
            'error_rate': round(self.total_errors / max(1, self.total_requests), 4),
            'retry_rate': round(self.total_retries / max(1, self.total_requests), 4),
        }


class HttpClient:
    """
    HTTP client wrapper with connection pooling and retry logic.
    
    Optimized for high-throughput object storage operations with:
    - Connection pooling (reuses TCP connections)
    - Keep-alive for connection persistence
    - Exponential backoff retry logic
    - Performance metrics tracking
    """
    
    def __init__(self, timeout: int = 30, max_retries: int = 3) -> None:
        self.timeout = timeout
        self.max_retries = max_retries

        # Configuration: Optimized for OmnixStorage uploads
        max_connections = int(os.getenv("OMNIX_HTTP_MAX_CONNECTIONS", "20"))
        max_keepalive = int(os.getenv("OMNIX_HTTP_MAX_KEEPALIVE", "20"))
        keepalive_expiry = float(os.getenv("OMNIX_HTTP_KEEPALIVE_EXPIRY", "30"))

        self._client = httpx.AsyncClient(
            timeout=timeout,
            limits=httpx.Limits(
                max_connections=max_connections,
                max_keepalive_connections=max_keepalive,
                keepalive_expiry=keepalive_expiry,
            ),
        )
        
        # Metrics tracking
        self.metrics = HttpClientMetrics()
        
        logger.debug(
            "HttpClient initialized with timeout=%s, max_retries=%s, max_connections=%s, max_keepalive=%s, keepalive_expiry=%s",
            timeout,
            max_retries,
            max_connections,
            max_keepalive,
            keepalive_expiry,
        )
    
    async def get(
        self,
        url: str,
        headers: Optional[Dict[str, str]] = None,
        **kwargs: Any
    ) -> httpx.Response:
        """Make a GET request with retry logic."""
        return await self._request("GET", url, headers=headers, **kwargs)
    
    async def put(
        self,
        url: str,
        content: Optional[bytes] = None,
        data: Optional[Any] = None,
        headers: Optional[Dict[str, str]] = None,
        **kwargs: Any
    ) -> httpx.Response:
        """Make a PUT request with retry logic."""
        return await self._request(
            "PUT",
            url,
            content=content,
            data=data,
            headers=headers,
            **kwargs
        )
    
    async def delete(
        self,
        url: str,
        headers: Optional[Dict[str, str]] = None,
        **kwargs: Any
    ) -> httpx.Response:
        """Make a DELETE request with retry logic."""
        return await self._request("DELETE", url, headers=headers, **kwargs)
    
    async def post(
        self,
        url: str,
        content: Optional[bytes] = None,
        json: Optional[Dict[str, Any]] = None,
        data: Optional[Any] = None,
        headers: Optional[Dict[str, str]] = None,
        **kwargs: Any
    ) -> httpx.Response:
        """Make a POST request with retry logic."""
        return await self._request(
            "POST",
            url,
            content=content,
            json=json,
            data=data,
            headers=headers,
            **kwargs
        )
    
    async def head(
        self,
        url: str,
        headers: Optional[Dict[str, str]] = None,
        **kwargs: Any
    ) -> httpx.Response:
        """Make a HEAD request with retry logic."""
        return await self._request("HEAD", url, headers=headers, **kwargs)
    
    async def _request(
        self,
        method: str,
        url: str,
        headers: Optional[Dict[str, str]] = None,
        **kwargs: Any
    ) -> httpx.Response:
        """
        Make HTTP request with exponential backoff retry logic.
        
        Automatically adds keep-alive headers to enable connection reuse.
        """
        retried = False
        for attempt in range(self.max_retries):
            try:
                # Merge keep-alive headers with provided headers
                request_headers = {"Connection": "keep-alive"}
                if headers:
                    request_headers.update(headers)
                
                start_time = time.perf_counter()
                logger.debug(f"HTTP request attempt {attempt + 1}/{self.max_retries}: {method} {url}")
                response = await self._client.request(method, url, headers=request_headers, **kwargs)
                elapsed_ms = (time.perf_counter() - start_time) * 1000
                
                logger.debug(f"HTTP response: {response.status_code} ({elapsed_ms:.1f}ms)")
                self.metrics.record_request(elapsed_ms, retried=retried)
                return response
            except httpx.RequestError as e:
                if attempt < self.max_retries - 1:
                    wait_time = min(1000 * (2 ** attempt), 10000) / 1000
                    logger.warning(f"Request failed (attempt {attempt + 1}), retrying in {wait_time}s: {str(e)}")
                    await asyncio.sleep(wait_time)
                    retried = True
                else:
                    logger.error(f"Request failed after {self.max_retries} attempts: {str(e)}", exc_info=True)
                    self.metrics.record_error()
                    raise NetworkError(str(e)) from e
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get connection pool and performance metrics."""
        return self.metrics.get_stats()
    
    async def close(self) -> None:
        """Close the HTTP client."""
        logger.debug("Closing HttpClient")
        await self._client.aclose()
    
    async def __aenter__(self) -> "HttpClient":
        """Async context manager entry."""
        return self
    
    async def __aexit__(self, exc_type: Optional[type], exc_val: Optional[Exception], exc_tb: Optional[Any]) -> None:
        """Async context manager exit."""
        if exc_val is not None:
            logger.warning(f"HttpClient context exiting with exception: {exc_val}")
        await self.close()
