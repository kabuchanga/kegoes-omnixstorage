"""
Intelligent caching and prefetching for OmnixStorage SDK

Provides pattern recognition and predictive prefetching to reduce latency.
"""

import asyncio
import time
import logging
from collections import OrderedDict
from typing import Optional, List, Tuple, Dict
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class CacheStatistics:
    """Cache performance statistics."""
    
    hits: int
    misses: int
    evictions: int
    total_size_bytes: int
    max_size_bytes: int
    
    @property
    def hit_rate(self) -> float:
        """Calculate cache hit rate."""
        total = self.hits + self.misses
        if total == 0:
            return 0.0
        return (self.hits / total) * 100
    
    def __str__(self) -> str:
        return (
            f"Cache: {self.hit_rate:.1f}% hit rate "
            f"({self.hits} hits, {self.misses} misses, {self.evictions} evictions), "
            f"size {self.total_size_bytes//(1024*1024)}MB / {self.max_size_bytes//(1024*1024)}MB"
        )


class PrefetchCache:
    """
    LRU cache for prefetched objects.
    
    Automatically evicts least recently used items when cache is full.
    """
    
    def __init__(self, max_size_mb: int = 100):
        """
        Initialize prefetch cache.
        
        Args:
            max_size_mb: Maximum cache size in MB
        """
        self.max_size_bytes = max_size_mb * 1024 * 1024
        self._cache: OrderedDict[Tuple[str, str], bytes] = OrderedDict()
        self._sizes: Dict[Tuple[str, str], int] = {}
        self._current_size = 0
        
        # Statistics
        self._hits = 0
        self._misses = 0
        self._evictions = 0
        
        logger.info(f"Initialized prefetch cache with {max_size_mb}MB limit")
    
    def _make_key(self, bucket: str, key: str) -> Tuple[str, str]:
        """Create cache key."""
        return (bucket, key)
    
    def get(self, bucket: str, key: str) -> Optional[bytes]:
        """
        Get object from cache.
        
        Args:
            bucket: Bucket name
            key: Object key
            
        Returns:
            Object data if cached, None otherwise
        """
        cache_key = self._make_key(bucket, key)
        
        if cache_key in self._cache:
            # Move to end (most recently used)
            self._cache.move_to_end(cache_key)
            self._hits += 1
            logger.debug(f"Cache HIT: {bucket}/{key}")
            return self._cache[cache_key]
        
        self._misses += 1
        logger.debug(f"Cache MISS: {bucket}/{key}")
        return None
    
    def put(self, bucket: str, key: str, data: bytes) -> bool:
        """
        Put object into cache.
        
        Args:
            bucket: Bucket name
            key: Object key
            data: Object data
            
        Returns:
            True if cached, False if too large
        """
        cache_key = self._make_key(bucket, key)
        data_size = len(data)
        
        # Check if object is too large for cache
        if data_size > self.max_size_bytes:
            logger.warning(f"Object too large for cache: {bucket}/{key} ({data_size} bytes)")
            return False
        
        # Evict items if needed
        while self._current_size + data_size > self.max_size_bytes and self._cache:
            self._evict_one()
        
        # Add to cache
        if cache_key in self._cache:
            # Update existing
            old_size = self._sizes[cache_key]
            self._current_size -= old_size
        
        self._cache[cache_key] = data
        self._cache.move_to_end(cache_key)
        self._sizes[cache_key] = data_size
        self._current_size += data_size
        
        logger.debug(f"Cached: {bucket}/{key} ({data_size} bytes)")
        return True
    
    def _evict_one(self):
        """Evict least recently used item."""
        if not self._cache:
            return
        
        # Remove first item (least recently used)
        cache_key, data = self._cache.popitem(last=False)
        size = self._sizes.pop(cache_key)
        self._current_size -= size
        self._evictions += 1
        
        logger.debug(f"Evicted: {cache_key[0]}/{cache_key[1]} ({size} bytes)")
    
    def invalidate(self, bucket: str, key: str):
        """
        Invalidate cached object.
        
        Args:
            bucket: Bucket name
            key: Object key
        """
        cache_key = self._make_key(bucket, key)
        if cache_key in self._cache:
            size = self._sizes.pop(cache_key)
            self._cache.pop(cache_key)
            self._current_size -= size
            logger.debug(f"Invalidated: {bucket}/{key}")
    
    def clear(self):
        """Clear entire cache."""
        self._cache.clear()
        self._sizes.clear()
        self._current_size = 0
        logger.info("Cache cleared")
    
    def get_statistics(self) -> CacheStatistics:
        """
        Get cache statistics.
        
        Returns:
            CacheStatistics object
        """
        return CacheStatistics(
            hits=self._hits,
            misses=self._misses,
            evictions=self._evictions,
            total_size_bytes=self._current_size,
            max_size_bytes=self.max_size_bytes
        )
    
    async def prefetch(
        self,
        client: 'OmnixClient',
        bucket: str,
        keys: List[str],
        max_concurrent: int = 4
    ) -> int:
        """
        Prefetch multiple objects into cache.
        
        Args:
            client: OmnixClient instance
            bucket: Bucket name
            keys: List of object keys to prefetch
            max_concurrent: Maximum concurrent downloads
            
        Returns:
            Number of objects successfully prefetched
        """
        logger.info(f"Prefetching {len(keys)} objects from {bucket}")
        
        semaphore = asyncio.Semaphore(max_concurrent)
        prefetched = 0
        
        async def fetch_one(key: str):
            nonlocal prefetched
            async with semaphore:
                try:
                    # Skip if already cached
                    if self.get(bucket, key) is not None:
                        return
                    
                    # Download
                    data = await client.get_object(bucket, key)
                    
                    # Cache
                    if self.put(bucket, key, data):
                        prefetched += 1
                        
                except Exception as e:
                    logger.warning(f"Failed to prefetch {bucket}/{key}: {e}")
        
        # Prefetch concurrently
        await asyncio.gather(*[fetch_one(key) for key in keys])
        
        logger.info(f"Prefetched {prefetched}/{len(keys)} objects")
        return prefetched


class AccessPatternTracker:
    """
    Track and analyze object access patterns.
    
    Identifies sequential access patterns to enable predictive prefetching.
    """
    
    def __init__(self, history_size: int = 100):
        """
        Initialize access pattern tracker.
        
        Args:
            history_size: Number of accesses to track
        """
        self.history_size = history_size
        self._access_history: List[Tuple[float, str, str]] = []  # (timestamp, bucket, key)
        self._access_counts: Dict[Tuple[str, str], int] = {}
    
    def record_access(self, bucket: str, key: str):
        """
        Record an object access.
        
        Args:
            bucket: Bucket name
            key: Object key
        """
        timestamp = time.time()
        self._access_history.append((timestamp, bucket, key))
        
        # Track access count
        access_key = (bucket, key)
        self._access_counts[access_key] = self._access_counts.get(access_key, 0) + 1
        
        # Trim history
        if len(self._access_history) > self.history_size:
            self._access_history = self._access_history[-self.history_size:]
        
        logger.debug(f"Recorded access: {bucket}/{key}")
    
    def is_sequential_pattern(self, lookback: int = 5) -> bool:
        """
        Detect if recent accesses follow a sequential pattern.
        
        Args:
            lookback: Number of recent accesses to analyze
            
        Returns:
            True if sequential pattern detected
        """
        if len(self._access_history) < 3:
            return False
        
        recent = self._access_history[-lookback:]
        
        # Check if keys follow numeric sequence
        try:
            # Extract numeric parts from keys
            numbers = []
            for _, bucket, key in recent:
                # Simple heuristic: look for numbers in key
                import re
                matches = re.findall(r'\d+', key)
                if matches:
                    numbers.append(int(matches[-1]))
            
            if len(numbers) < 3:
                return False
            
            # Check if numbers are sequential
            diffs = [numbers[i+1] - numbers[i] for i in range(len(numbers)-1)]
            if len(set(diffs)) == 1 and diffs[0] == 1:
                logger.debug(f"Sequential pattern detected: {numbers}")
                return True
                
        except Exception:
            pass
        
        return False
    
    def predict_next(self, count: int = 3) -> List[Tuple[str, str]]:
        """
        Predict next likely accessed objects.
        
        Args:
            count: Number of predictions to return
            
        Returns:
            List of (bucket, key) tuples
        """
        if len(self._access_history) < 2:
            return []
        
        predictions = []
        
        # Get last accessed object
        last_timestamp, last_bucket, last_key = self._access_history[-1]
        
        # Check for sequential pattern
        if self.is_sequential_pattern():
            # Predict next in sequence
            import re
            matches = re.findall(r'\d+', last_key)
            if matches:
                last_num = int(matches[-1])
                base_key = re.sub(r'\d+', '', last_key)
                
                for i in range(1, count + 1):
                    next_key = f"{base_key}{last_num + i}"
                    predictions.append((last_bucket, next_key))
        
        # Fallback: frequently accessed items
        if not predictions:
            sorted_by_freq = sorted(
                self._access_counts.items(),
                key=lambda x: x[1],
                reverse=True
            )
            predictions = [key for key, _ in sorted_by_freq[:count]]
        
        logger.debug(f"Predicted next access: {predictions}")
        return predictions
    
    def get_frequently_accessed(self, top_n: int = 10) -> List[Tuple[str, str, int]]:
        """
        Get most frequently accessed objects.
        
        Args:
            top_n: Number of results to return
            
        Returns:
            List of ((bucket, key), count) tuples
        """
        sorted_items = sorted(
            self._access_counts.items(),
            key=lambda x: x[1],
            reverse=True
        )
        
        return [(b, k, count) for (b, k), count in sorted_items[:top_n]]
