"""
OmnixClient - S3-compatible client for OmnixStorage
"""

import json
import logging
import inspect
from datetime import datetime, timedelta, timezone
from typing import Optional, Dict, BinaryIO, List, Any, AsyncIterator, Callable
from urllib.parse import urljoin, urlparse, parse_qs

from ._http import HttpClient
from ._signer import AwsSignatureV4Signer
from ._streaming import (
    CheckpointManager,
    RangeDownloader,
    RangeSpec,
    StreamPipeline,
    ProgressTracker,
    DownloadProgress,
)
from .models import (
    Bucket,
    ObjectMetadata,
    ListObjectsResult,
    PutObjectResult,
    PresignedUrlResult,
)
from .error import (
    OmnixStorageException,
    NetworkError,
    ValidationError,
    BucketNotFoundException,
    ObjectNotFoundException,
    AuthenticationException,
    AuthenticationError,
    ServerException,
    ServerError,
    AccessDeniedException,
)

# Configure structured logging
logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())


class OmnixClient:
    """
    S3-compatible client for OmnixStorage.
    
    Example:
        client = OmnixClient(
            endpoint="omnix.production.local:9000",
            access_key="admin",
            secret_key="password"
        )
        
        # Upload a file
        with open("image.jpg", "rb") as f:
            result = await client.put_object(
                bucket_name="photos",
                object_name="archive/camera-001/image.jpg",
                data=f,
                content_type="image/jpeg"
            )
    """
    
    def __init__(
        self,
        endpoint: str = "localhost:9000",
        username: str = "admin",
        password: str = "omnix-console-2026",
        access_key: str = "admin",
        secret_key: str = "omnix-secret-2026",
        use_ssl: bool = False,
        request_timeout: int = 60,
        max_retries: int = 3,
    ) -> None:
        """
        Initialize OmnixClient.
        
        Args:
            endpoint: Server address and port (e.g., "omnix.local:9000")
            username: (Deprecated) Admin username - no longer used
            password: (Deprecated) Admin password - no longer used
            access_key: S3 access key for request signing (AWS SigV4)
            secret_key: S3 secret key for request signing (AWS SigV4)
            use_ssl: Use HTTPS instead of HTTP
            request_timeout: Request timeout in seconds (default: 60, was 30)
            max_retries: Maximum number of retries for failed requests
        """
        logger.debug(f"Initializing OmnixClient with endpoint={endpoint}, ssl={use_ssl}")
        self.endpoint = endpoint
        self.username = username
        self.password = password
        self.access_key = access_key
        self.secret_key = secret_key
        self.use_ssl = use_ssl
        self.base_url = f"{'https' if use_ssl else 'http'}://{endpoint}"
        self.request_timeout = request_timeout  # Store for use in timeout calculations
        
        self._http = HttpClient(timeout=request_timeout, max_retries=max_retries)
        self._signer = AwsSignatureV4Signer(access_key, secret_key)
        logger.info(f"OmnixClient initialized with base_url={self.base_url}")
    
    @staticmethod
    def recommended_timeout(file_size_mb: float, network_speed_mbps: float = 10.0) -> int:
        """
        Calculate a recommended timeout for file uploads/downloads.
        
        Args:
            file_size_mb: File size in megabytes
            network_speed_mbps: Expected network speed in Mbps (default: 10 Mbps)
        
        Returns:
            Recommended timeout in seconds (minimum 60 seconds)
        
        Example:
            >>> client = OmnixClient()
            >>> # Large 500MB file over slower connection
            >>> timeout = OmnixClient.recommended_timeout(file_size_mb=500, network_speed_mbps=5)
            >>> # timeout will be 800+ seconds
        """
        # Calculate time needed to transfer file: (size_mb * 8) / speed_mbps
        # 8 to convert megabytes to megabits
        transfer_time = (file_size_mb * 8) / network_speed_mbps
        
        # Add 2x safety margin for network variability and overhead
        timeout = int(transfer_time * 2)
        
        # Ensure minimum timeout of 60 seconds
        return max(timeout, 60)
    
    def _validate_object_name(self, object_name: str) -> None:
        """Validate that object name doesn't contain spaces."""
        if not object_name or not isinstance(object_name, str):
            logger.warning(f"Invalid object name: {object_name}")
            raise ValidationError("Object name cannot be null or empty.")
        
        if " " in object_name:
            logger.warning(f"Object name contains spaces: {object_name}")
            raise ValidationError(
                "Object names cannot contain spaces. "
                "Please use hyphens, underscores, or other URL-safe characters instead."
            )
    
    async def _make_request(
        self,
        method: str,
        path: str,
        headers: Optional[Dict[str, str]] = None,
        content: Optional[bytes] = None,
        data: Optional[Any] = None,
        json_data: Optional[Dict[str, Any]] = None,
        stream: bool = False,
    ) -> Any:
        """Make authenticated HTTP request."""
        if headers is None:
            headers = {}
        
        url = urljoin(self.base_url, path)
        logger.debug(f"Making {method} request to {path}")
        
        # Extract host from URL for SigV4 signing
        parsed = urlparse(url)
        host = parsed.netloc
        request_path = parsed.path or "/"
        
        # Extract query parameters for SigV4 signing
        query_params: Dict[str, str] = {}
        if parsed.query:
            # For S3 multipart API compatibility, we need to handle query parameters
            # that have no value (like "?uploads") correctly.
            # parse_qs will give us {'uploads': ['']} which we need to sign as 'uploads'
            # without the '=' sign.
            
            # Split by & to preserve the exact format
            for param in parsed.query.split('&'):
                if '=' in param:
                    # Standard key=value format
                    k, v = param.split('=', 1)
                    query_params[k] = v
                else:
                    # Key with no value (like 'uploads') - store with None value
                    # to indicate it should be signed without '='
                    query_params[param] = ""
        
        # Prepare body for signing
        body_bytes: Optional[bytes] = None
        if content:
            body_bytes = content
        elif data:
            if hasattr(data, 'read'):
                body_bytes = data.read()
                # Seek back to beginning so we can read it again for the actual request
                if hasattr(data, 'seek'):
                    data.seek(0)
            else:
                # Async iterator or streaming payloads are unsigned
                body_bytes = None
        
        # Ensure Host header is included for SigV4 signing
        if "Host" not in headers and "host" not in headers:
            headers["Host"] = host
        
        # Use UNSIGNED-PAYLOAD for signing (consistent with .NET SDK)
        # This is the standard approach for S3-compatible APIs
        payload_hash = "UNSIGNED-PAYLOAD"
        
        headers["X-Amz-Content-Sha256"] = payload_hash
        
        # Sign the request with AWS SigV4
        # Pass query_params as a dict for proper canonical request construction
        signed_headers = self._signer.sign_request(
            method=method,
            host=host,
            path=request_path,
            query_params=query_params,  # Pass parsed query params
            headers=headers,
            body=None,  # Use None for UNSIGNED-PAYLOAD
        )
        headers.update(signed_headers)
        
        try:
            if method == "GET":
                # Note: stream parameter is not used by httpx.AsyncClient.request()
                # httpx uses response.aiter_bytes() for streaming responses
                response = await self._http.get(url, headers=headers)
            elif method == "HEAD":
                response = await self._http.head(url, headers=headers)
            elif method == "PUT":
                if content:
                    response = await self._http.put(url, content=content, headers=headers)
                elif data:
                    if hasattr(data, 'read'):
                        content_bytes = data.read()
                        response = await self._http.put(url, content=content_bytes, headers=headers)
                    else:
                        response = await self._http.put(url, content=data, headers=headers)
                elif json_data:
                    response = await self._http.put(url, json=json_data, headers=headers)
                else:
                    response = await self._http.put(url, content=None, headers=headers)
            elif method == "DELETE":
                response = await self._http.delete(url, headers=headers)
            else:
                logger.error(f"Unsupported HTTP method: {method}")
                raise ValueError(f"Unsupported HTTP method: {method}")
            
            logger.debug(f"{method} {path} -> {response.status_code}")
            
            if response.status_code >= 400:
                error_msg = f"Request failed with status {response.status_code}"
                if response.status_code == 404:
                    error_msg = "Resource not found"
                logger.error(f"HTTP error {response.status_code}: {error_msg}")
                if response.status_code == 400:
                    raise ValidationError(error_msg)
                if response.status_code == 401:
                    raise AuthenticationError(error_msg)
                if response.status_code == 403:
                    raise AccessDeniedException(error_msg)
                if response.status_code >= 500:
                    raise ServerError(error_msg, response.status_code)
                raise ServerException(error_msg, response.status_code)
            
            return response
        except Exception as e:
            logger.error(f"Request failed: {method} {path} - {str(e)}", exc_info=True)
            raise
    
    # Bucket operations
    
    async def bucket_exists(self, bucket_name: str) -> bool:
        """Check if a bucket exists."""
        logger.info(f"Checking if bucket exists: {bucket_name}")
        try:
            path = f"/{bucket_name}"
            await self._make_request("HEAD", path)
            logger.info(f"Bucket exists: {bucket_name}")
            return True
        except ServerException as e:
            if e.status_code == 404:
                logger.info(f"Bucket not found: {bucket_name}")
                return False
            logger.error(f"Error checking bucket existence: {bucket_name} - {str(e)}", exc_info=True)
            raise
    
    async def make_bucket(self, bucket_name: str) -> None:
        """Create a new bucket."""
        logger.info(f"Creating bucket: {bucket_name}")
        path = f"/{bucket_name}"
        await self._make_request("PUT", path)
        logger.info(f"Bucket created successfully: {bucket_name}")
    
    async def remove_bucket(self, bucket_name: str) -> None:
        """Remove a bucket (must be empty)."""
        logger.info(f"Removing bucket: {bucket_name}")
        path = f"/{bucket_name}"
        await self._make_request("DELETE", path)
        logger.info(f"Bucket removed successfully: {bucket_name}")
    
    async def list_buckets(self) -> List[Bucket]:
        """List all buckets."""
        logger.info("Listing all buckets")
        response = await self._make_request("GET", "/api/admin/buckets")
        data = response.json()
        
        buckets: List[Bucket] = []
        for bucket_data in data.get("buckets", []):
            buckets.append(
                Bucket(
                    name=bucket_data["name"],
                    creation_date=datetime.fromisoformat(
                        bucket_data["createdAt"]
                    ),
                )
            )
        logger.info(f"Listed {len(buckets)} buckets")
        return buckets
    
    # Object operations
    
    async def put_object(
        self,
        bucket_name: str,
        object_name: str,
        data: Any,
        length: Optional[int] = None,
        content_type: str = "application/octet-stream",
        metadata: Optional[Dict[str, str]] = None,
    ) -> PutObjectResult:
        """Upload an object to the bucket."""
        logger.info(f"Uploading object: {bucket_name}/{object_name}")
        self._validate_object_name(object_name)
        
        headers: Dict[str, str] = {"Content-Type": content_type}
        
        if metadata:
            for key, value in metadata.items():
                headers[f"x-amz-meta-{key}"] = value
        
        # Convert BinaryIO to bytes if needed
        if hasattr(data, 'read'):
            data = data.read()
        
        # Validate that file is not empty
        if not data or len(data) == 0:
            logger.error(f"Attempted to upload empty file: {bucket_name}/{object_name}")
            raise ValueError("Cannot upload an empty file. File size must be greater than 0 bytes.")
        
        if length:
            headers["Content-Length"] = str(length)
        
        path = f"/{bucket_name}/{object_name}"
        try:
            response = await self._make_request("PUT", path, headers=headers, content=data)
            etag = response.headers.get("ETag", "unknown")
            logger.info(f"Object uploaded successfully: {bucket_name}/{object_name} (size: {len(data)}, ETag: {etag})")
            
            return PutObjectResult(
                bucket_name=bucket_name,
                object_name=object_name,
                etag=etag,
            )
        except Exception as e:
            logger.error(f"Failed to upload object: {bucket_name}/{object_name} - {str(e)}", exc_info=True)
            raise
    
    async def get_object(
        self,
        bucket_name: str,
        object_name: str,
        output: BinaryIO,
    ) -> ObjectMetadata:
        """Download an object from the bucket."""
        logger.info(f"Downloading object: {bucket_name}/{object_name}")
        self._validate_object_name(object_name)
        
        path = f"/{bucket_name}/{object_name}"
        
        try:
            response = await self._make_request("GET", path)
        except ServerException as e:
            if e.status_code == 404:
                logger.error(f"Object not found: {bucket_name}/{object_name}")
                raise ObjectNotFoundException(bucket_name, object_name)
            logger.error(f"Failed to download object: {bucket_name}/{object_name} - {str(e)}", exc_info=True)
            raise

        output.write(response.content)
        logger.info(f"Object downloaded successfully: {bucket_name}/{object_name} (size: {len(response.content)})")

        return ObjectMetadata(
            object_name=object_name,
            bucket_name=bucket_name,
            size=len(response.content),
            content_type=response.headers.get("Content-Type"),
            etag=response.headers.get("ETag", "unknown"),
        )

    async def get_object_stream(
        self,
        bucket_name: str,
        object_name: str,
        chunk_size: int = 1024 * 1024,
        progress_callback: Optional[Callable[[int], Any]] = None,
    ) -> AsyncIterator[bytes]:
        """Stream object bytes as an async iterator."""
        logger.info(f"Streaming object: {bucket_name}/{object_name}")
        self._validate_object_name(object_name)

        path = f"/{bucket_name}/{object_name}"
        # Note: httpx responses support streaming via aiter_bytes() without explicit stream parameter
        response = await self._make_request("GET", path)

        try:
            async for chunk in response.aiter_bytes(chunk_size):
                if not chunk:
                    continue

                if progress_callback is not None:
                    result = progress_callback(len(chunk))
                    if inspect.isawaitable(result):
                        await result

                yield chunk
        finally:
            await response.aclose()

    async def put_object_stream(
        self,
        bucket_name: str,
        object_name: str,
        data: AsyncIterator[bytes],
        length: Optional[int] = None,
        content_type: str = "application/octet-stream",
        metadata: Optional[Dict[str, str]] = None,
        progress_callback: Optional[Callable[[int], Any]] = None,
    ) -> PutObjectResult:
        """Upload an object from an async iterator."""
        logger.info(f"Streaming upload: {bucket_name}/{object_name}")
        self._validate_object_name(object_name)

        headers: Dict[str, str] = {"Content-Type": content_type}
        if length is not None:
            headers["Content-Length"] = str(length)

        if metadata:
            for key, value in metadata.items():
                headers[f"x-amz-meta-{key}"] = value

        async def wrapped() -> AsyncIterator[bytes]:
            async for chunk in data:
                if progress_callback is not None:
                    result = progress_callback(len(chunk))
                    if inspect.isawaitable(result):
                        await result
                yield chunk

        path = f"/{bucket_name}/{object_name}"
        response = await self._make_request("PUT", path, headers=headers, data=wrapped())

        if response.status_code >= 400:
            raise ServerError(f"Upload failed with status {response.status_code}", response.status_code)

        return PutObjectResult(
            bucket_name=bucket_name,
            object_name=object_name,
            etag=response.headers.get("ETag", "unknown"),
        )
    
    async def stat_object(
        self,
        bucket_name: str,
        object_name: str,
    ) -> ObjectMetadata:
        """Get object metadata without downloading."""
        logger.debug(f"Getting metadata for object: {bucket_name}/{object_name}")
        self._validate_object_name(object_name)
        
        path = f"/{bucket_name}/{object_name}"
        
        try:
            response = await self._make_request("HEAD", path)
        except ServerException as e:
            if e.status_code == 404:
                logger.error(f"Object not found: {bucket_name}/{object_name}")
                raise ObjectNotFoundException(bucket_name, object_name)
            logger.error(f"Failed to stat object: {bucket_name}/{object_name} - {str(e)}", exc_info=True)
            raise
        
        size = int(response.headers.get("Content-Length", 0))
        logger.debug(f"Object metadata retrieved: {bucket_name}/{object_name} (size: {size})")
        
        return ObjectMetadata(
            object_name=object_name,
            bucket_name=bucket_name,
            size=size,
            content_type=response.headers.get("Content-Type"),
            etag=response.headers.get("ETag", "unknown"),
        )
    
    async def remove_object(
        self,
        bucket_name: str,
        object_name: str,
    ) -> None:
        """Remove an object from the bucket."""
        logger.info(f"Removing object: {bucket_name}/{object_name}")
        self._validate_object_name(object_name)
        
        path = f"/{bucket_name}/{object_name}"
        
        try:
            await self._make_request("DELETE", path)
            logger.info(f"Object removed successfully: {bucket_name}/{object_name}")
        except ServerException as e:
            # Don't fail if object doesn't exist
            if e.status_code != 404:
                logger.error(f"Failed to remove object: {bucket_name}/{object_name} - {str(e)}", exc_info=True)
                raise
            logger.info(f"Object already removed or not found: {bucket_name}/{object_name}")
    
    async def get_multiple_objects(
        self,
        bucket_name: str,
        object_names: List[str],
        max_concurrent: int = 4,
    ) -> Dict[str, bytes]:
        """
        Batch download multiple objects concurrently.
        
        Downloads multiple objects from the same bucket in parallel using
        asyncio.gather() for concurrent requests. Failed downloads are logged
        but don't fail the entire batch.
        
        Example:
            results = await client.get_multiple_objects(
                bucket_name="my-bucket",
                object_names=["file1.txt", "file2.txt", "file3.txt"],
                max_concurrent=4
            )
            # results = {"file1.txt": b"...", "file2.txt": b"...", ...}
        
        Args:
            bucket_name: Bucket containing the objects
            object_names: List of object keys to download
            max_concurrent: Maximum concurrent downloads (1-16, default 4)
        
        Returns:
            Dictionary mapping object names to their content bytes.
            Objects that failed to download are omitted.
        
        Raises:
            ValidationError: If max_concurrent is out of range or object_names empty
        """
        import asyncio
        
        if not object_names:
            raise ValidationError("object_names list cannot be empty")
        
        if not (1 <= max_concurrent <= 16):
            raise ValidationError("max_concurrent must be between 1 and 16")
        
        logger.info(f"Batch downloading {len(object_names)} objects from {bucket_name} (max_concurrent={max_concurrent})")
        
        results: Dict[str, bytes] = {}
        semaphore = asyncio.Semaphore(max_concurrent)
        
        async def download_one(object_name: str) -> tuple[str, Optional[bytes]]:
            """Download single object with semaphore control."""
            async with semaphore:
                try:
                    data = await self.get_object(bucket_name, object_name)
                    logger.debug(f"Successfully downloaded: {object_name} ({len(data)} bytes)")
                    return (object_name, data)
                except Exception as e:
                    logger.warning(f"Failed to download {object_name}: {str(e)}")
                    return (object_name, None)
        
        # Execute all downloads concurrently with semaphore limit
        download_results = await asyncio.gather(*[
            download_one(obj_name) for obj_name in object_names
        ])
        
        # Collect successful downloads
        for obj_name, data in download_results:
            if data is not None:
                results[obj_name] = data
        
        logger.info(f"Batch download complete: {len(results)}/{len(object_names)} succeeded")
        return results
    
    async def delete_multiple_objects(
        self,
        bucket_name: str,
        object_names: List[str],
        max_concurrent: int = 8,
    ) -> Dict[str, bool]:
        """
        Batch delete multiple objects concurrently.
        
        Deletes multiple objects from the same bucket in parallel using
        asyncio.gather() for concurrent requests. Failed deletions are logged
        but don't fail the entire batch.
        
        Example:
            results = await client.delete_multiple_objects(
                bucket_name="my-bucket",
                object_names=["old1.txt", "old2.txt", "old3.txt"],
                max_concurrent=8
            )
            # results = {"old1.txt": True, "old2.txt": True, "old3.txt": False}
        
        Args:
            bucket_name: Bucket containing the objects
            object_names: List of object keys to delete
            max_concurrent: Maximum concurrent deletes (1-16, default 8)
        
        Returns:
            Dictionary mapping object names to success status (True/False).
        
        Raises:
            ValidationError: If max_concurrent is out of range or object_names empty
        """
        import asyncio
        
        if not object_names:
            raise ValidationError("object_names list cannot be empty")
        
        if not (1 <= max_concurrent <= 16):
            raise ValidationError("max_concurrent must be between 1 and 16")
        
        logger.info(f"Batch deleting {len(object_names)} objects from {bucket_name} (max_concurrent={max_concurrent})")
        
        results: Dict[str, bool] = {}
        semaphore = asyncio.Semaphore(max_concurrent)
        
        async def delete_one(object_name: str) -> tuple[str, bool]:
            """Delete single object with semaphore control."""
            async with semaphore:
                try:
                    await self.remove_object(bucket_name, object_name)
                    logger.debug(f"Successfully deleted: {object_name}")
                    return (object_name, True)
                except Exception as e:
                    logger.warning(f"Failed to delete {object_name}: {str(e)}")
                    return (object_name, False)
        
        # Execute all deletions concurrently with semaphore limit
        delete_results = await asyncio.gather(*[
            delete_one(obj_name) for obj_name in object_names
        ])
        
        # Collect results
        for obj_name, success in delete_results:
            results[obj_name] = success
        
        successful = sum(1 for s in results.values() if s)
        logger.info(f"Batch delete complete: {successful}/{len(object_names)} succeeded")
        return results
    
    def multipart_upload(
        self,
        bucket_name: str,
        object_name: str,
        part_size: int = 5 * 1024 * 1024,
        metadata: Optional[Dict[str, str]] = None,
    ) -> "MultipartUploadManager":
        """
        Create a multipart upload manager for large files.
        
        Enables uploading large files in chunks with automatic merging:
        - Automatic part chunking (default 5MB, min 5MB, max 5GB)
        - Progress callbacks for each part
        - Retry logic with exponential backoff
        - Resume capability via upload ID
        - File and stream upload methods
        
        Example:
            async with client.multipart_upload("my-bucket", "large-file.zip") as upload:
                upload_id = await upload.initiate()
                await upload.upload_file("/local/large-file.zip")
                etag = await upload.complete()
        
        Args:
            bucket_name: Target bucket name
            object_name: Target object key
            part_size: Size of each part (5MB-5GB, default 5MB)
            metadata: Custom metadata for final object
        
        Returns:
            MultipartUploadManager instance for managing the upload
        
        Raises:
            ValidationError: If part_size is invalid
        """
        from .multipart import MultipartUploadManager
        
        logger.info(f"Creating multipart upload for: {bucket_name}/{object_name}")
        self._validate_object_name(object_name)
        
        return MultipartUploadManager(
            client=self,
            bucket_name=bucket_name,
            object_key=object_name,
            part_size=part_size,
            metadata=metadata
        )
    
    async def list_objects(
        self,
        bucket_name: str,
        prefix: str = "",
        delimiter: str = "",
        max_keys: int = 1000,
        continuation_token: Optional[str] = None,
    ) -> ListObjectsResult:
        """List objects in a bucket with proper query parameter encoding."""
        from urllib.parse import urlencode
        
        logger.debug(f"Listing objects in bucket: {bucket_name} (prefix={prefix}, max_keys={max_keys})")
        
        query_params: Dict[str, str] = {}
        if prefix:
            query_params["prefix"] = prefix
        if delimiter:
            query_params["delimiter"] = delimiter
        if max_keys:
            query_params["max-keys"] = str(max_keys)
        if continuation_token:
            query_params["continuation-token"] = continuation_token
        
        # Use urlencode for proper URL encoding of query parameters
        query_string = urlencode(query_params) if query_params else ""
        path = f"/{bucket_name}"
        if query_string:
            path += f"?{query_string}"
        
        response = await self._make_request("GET", path)
        data = response.json()
        
        objects: List[ObjectMetadata] = []
        for obj in data.get("contents", []):
            objects.append(
                ObjectMetadata(
                    object_name=obj["key"],
                    bucket_name=bucket_name,
                    size=obj["size"],
                    etag=obj.get("etag", "unknown"),
                    last_modified=datetime.fromisoformat(obj["lastModified"]),
                )
            )
        
        logger.info(f"Listed {len(objects)} objects in {bucket_name} (truncated: {data.get('isTruncated', False)})")
        
        return ListObjectsResult(
            objects=objects,
            is_truncated=data.get("isTruncated", False),
            continuation_token=data.get("continuationToken"),
            common_prefixes=data.get("commonPrefixes", []),
        )
    
    async def presigned_get_object(
        self,
        bucket_name: str,
        object_name: str,
        expires_in_seconds: int = 3600,
    ) -> PresignedUrlResult:
        """Generate a presigned URL for downloading an object."""
        logger.info(f"Generating presigned URL for: {bucket_name}/{object_name} (expires_in: {expires_in_seconds}s)")

        if expires_in_seconds <= 0:
            raise ValidationError("Expiration must be greater than 0 seconds.")
        if expires_in_seconds > 7 * 24 * 3600:
            raise ValidationError("Expiration cannot exceed 7 days (604800 seconds).")
        if expires_in_seconds < 3600:
            logger.warning("Presigned URL expiration is less than 1 hour: %ss", expires_in_seconds)
        path = (
            f"/api/presigned-url?"
            f"bucket={bucket_name}&"
            f"object={object_name}&"
            f"expires-in={expires_in_seconds}"
        )
        
        try:
            response = await self._make_request("GET", path)
            data = response.json()
            logger.info(f"Presigned URL generated successfully: {bucket_name}/{object_name}")
            
            return PresignedUrlResult(
                url=data["url"],
                expires_at=datetime.now(timezone.utc) + timedelta(seconds=expires_in_seconds),
            )
        except Exception as e:
            logger.error(f"Failed to generate presigned URL: {bucket_name}/{object_name} - {str(e)}", exc_info=True)
            raise
    
    # ==================== Streaming Methods (Phase 4.7) ====================
    
    async def get_object_range(
        self,
        bucket: str,
        key: str,
        start: int,
        end: Optional[int] = None
    ) -> bytes:
        """
        Download partial object using HTTP range requests.
        
        Efficiently download only a portion of an object using byte ranges,
        useful for:
        - Large file partial downloads
        - Seeking in media files
        - Resume download support
        - Bandwidth optimization
        
        Example:
            # Download first 1MB
            data = await client.get_object_range("my-bucket", "large-file.bin", 0, 1024*1024-1)
            
            # Download from position 1MB onwards
            data = await client.get_object_range("my-bucket", "large-file.bin", 1024*1024)
        
        Args:
            bucket: Bucket name
            key: Object key
            start: Starting byte position (0-indexed)
            end: Optional ending byte position (inclusive)
                If None, downloads from start to end of file
        
        Returns:
            Bytes of requested range
        
        Raises:
            ValidationError: If range is invalid
            ObjectNotFoundException: If object doesn't exist
            ServerException: If server doesn't support ranges
        """
        logger.info(f"Downloading range for {bucket}/{key}: bytes={start}-{end or ''}")
        
        if start < 0:
            raise ValidationError("Start byte must be >= 0")
        if end is not None and end < start:
            raise ValidationError("End byte must be >= start byte")
        
        # Create range header
        range_spec = RangeSpec(start=start, end=end)
        headers = {"Range": range_spec.to_header()}
        
        path = f"/{bucket}/{key}"
        response = await self._make_request("GET", path, headers=headers)
        
        # Check for partial content response
        if response.status_code == 206:
            logger.info(f"Received partial content: {len(response.content)} bytes")
        elif response.status_code == 200:
            logger.warning("Server returned full content (range not supported)")
        
        return response.content
    
    async def resume_download(
        self,
        bucket: str,
        key: str,
        local_path: str,
        checkpoint_manager: Optional[CheckpointManager] = None
    ) -> Dict[str, Any]:
        """
        Resume interrupted download from checkpoint.
        
        Automatically detects partial file and resumes download from where it left off.
        Uses HTTP range requests to avoid re-downloading existing data.
        
        Example:
            # First attempt (interrupted)
            try:
                await client.resume_download("my-bucket", "large.zip", "/tmp/large.zip")
            except NetworkError:
                pass  # Download interrupted
            
            # Second attempt (resumes automatically)
            result = await client.resume_download("my-bucket", "large.zip", "/tmp/large.zip")
            print(f"Downloaded {result['total_bytes']} bytes, resumed from {result['resumed_from']}")
        
        Args:
            bucket: Bucket name
            key: Object key
            local_path: Local file path to save
            checkpoint_manager: Optional checkpoint manager for tracking
        
        Returns:
            Dict with download statistics:
                - total_bytes: Total bytes downloaded
                - resumed_from: Byte position resumed from (0 if new)
                - is_resume: Whether this was a resumed download
                - object_size: Total object size
        
        Raises:
            ObjectNotFoundException: If object doesn't exist
            ValidationError: If file is corrupted
        """
        import os
        import aiofiles
        
        logger.info(f"Resume download: {bucket}/{key} -> {local_path}")
        
        # Initialize checkpoint manager if needed
        if checkpoint_manager is None:
            checkpoint_manager = CheckpointManager()
        
        # Get object metadata to check size
        metadata = await self.head_object(bucket, key)
        object_size = metadata.size
        
        # Check for existing partial file
        downloaded_bytes = checkpoint_manager.get_downloaded_bytes(local_path)
        
        is_resume = downloaded_bytes > 0
        if is_resume:
            logger.info(f"Found partial file: {downloaded_bytes}/{object_size} bytes")
            
            # Validate partial file size
            if downloaded_bytes >= object_size:
                logger.info(f"File already complete")
                await checkpoint_manager.delete_checkpoint(bucket, key)
                return {
                    "total_bytes": object_size,
                    "resumed_from": 0,
                    "is_resume": False,
                    "object_size": object_size
                }
        
        resume_position = downloaded_bytes
        
        # Download remaining bytes
        remaining_data = await self.get_object_range(
            bucket,
            key,
            start=resume_position,
            end=None  # To end of file
        )
        
        # Append to file
        mode = "ab" if is_resume else "wb"
        async with aiofiles.open(local_path, mode) as f:
            await f.write(remaining_data)
        
        total_bytes = resume_position + len(remaining_data)
        
        # Validate complete
        if total_bytes != object_size:
            logger.error(f"Download incomplete: {total_bytes}/{object_size} bytes")
            await checkpoint_manager.save_checkpoint(
                bucket, key, total_bytes, object_size, local_path
            )
            raise ValidationError(f"Download incomplete: {total_bytes}/{object_size} bytes")
        
        # Clean up checkpoint
        await checkpoint_manager.delete_checkpoint(bucket, key)
        
        logger.info(f"Download complete: {total_bytes} bytes (resumed from {resume_position})")
        
        return {
            "total_bytes": total_bytes,
            "resumed_from": resume_position,
            "is_resume": is_resume,
            "object_size": object_size
        }
    
    async def stream_object_chunks(
        self,
        bucket: str,
        key: str,
        chunk_size: int = 1024 * 1024  # 1MB default
    ) -> AsyncIterator[bytes]:
        """
        Stream object in chunks with constant memory usage.
        
        Memory-efficient streaming for large objects. Downloads object in chunks
        without loading entire file into memory.
        
        Example:
            # Stream and process large file
            async for chunk in client.stream_object_chunks("my-bucket", "large-file.bin"):
                process_chunk(chunk)  # Process each 1MB chunk
                # Memory usage stays constant regardless of file size
        
        Args:
            bucket: Bucket name
            key: Object key
            chunk_size: Size of each chunk in bytes (default 1MB)
        
        Yields:
            Bytes of each chunk
        
        Raises:
            ObjectNotFoundException: If object doesn't exist
            NetworkError: If connection fails
        """
        logger.info(f"Streaming object chunks: {bucket}/{key} (chunk_size={chunk_size})")
        
        path = f"/{bucket}/{key}"
        
        # Use httpx streaming
        async with self._http._client.stream("GET", f"{self._http.base_url}{path}") as response:
            if response.status_code == 404:
                raise ObjectNotFoundException(f"Object not found: {bucket}/{key}")
            if response.status_code >= 400:
                raise ServerException(f"Server error: {response.status_code}")
            
            async for chunk in response.aiter_bytes(chunk_size=chunk_size):
                yield chunk
        
        logger.info(f"Streaming complete: {bucket}/{key}")
    
    async def stream_to_file(
        self,
        bucket: str,
        key: str,
        local_path: str,
        chunk_size: int = 5 * 1024 * 1024,  # 5MB default
        progress_callback: Optional[Callable[[DownloadProgress], None]] = None,
        enable_checkpoints: bool = False
    ) -> Dict[str, Any]:
        """
        Stream object directly to file with progress tracking.
        
        Memory-efficient file download with:
        - Constant memory usage (only chunk_size in memory)
        - Progress callbacks for UI updates
        - Optional checkpointing for resume capability
        - Automatic directory creation
        
        Example:
            # Download with progress bar
            def progress(p):
                print(f"Progress: {p.percentage:.1f}% @ {p.speed_mbps:.2f} MB/s")
            
            result = await client.stream_to_file(
                "my-bucket",
                "large-file.bin",
                "/downloads/large-file.bin",
                progress_callback=progress
            )
            print(f"Downloaded {result['total_bytes']} bytes in {result['elapsed_seconds']:.1f}s")
        
        Args:
            bucket: Bucket name
            key: Object key
            local_path: Local file path to save
            chunk_size: Size of each chunk (default 5MB)
            progress_callback: Optional callback for progress updates
            enable_checkpoints: Enable checkpoint saving for resume
        
        Returns:
            Dict with download statistics:
                - total_bytes: Total bytes downloaded
                - elapsed_seconds: Total download time
                - speed_mbps: Average speed in MB/s
                - chunks_downloaded: Number of chunks
        
        Raises:
            ObjectNotFoundException: If object doesn't exist
            OSError: If file cannot be written
        """
        import aiofiles
        import os
        import time
        from pathlib import Path
        
        logger.info(f"Streaming to file: {bucket}/{key} -> {local_path}")
        
        # Create directory if needed
        Path(local_path).parent.mkdir(parents=True, exist_ok=True)
        
        # Get object size for progress tracking
        metadata = await self.head_object(bucket, key)
        object_size = metadata.size
        
        # Initialize progress tracker
        tracker = None
        if progress_callback:
            tracker = ProgressTracker(object_size, progress_callback)
        
        # Initialize checkpoint manager
        checkpoint_mgr = None
        if enable_checkpoints:
            checkpoint_mgr = CheckpointManager()
        
        start_time = time.time()
        total_bytes = 0
        chunks_downloaded = 0
        
        # Stream to file
        async with aiofiles.open(local_path, "wb") as f:
            async for chunk in self.stream_object_chunks(bucket, key, chunk_size):
                await f.write(chunk)
                total_bytes += len(chunk)
                chunks_downloaded += 1
                
                # Update progress
                if tracker:
                    await tracker.update(len(chunk))
                
                # Save checkpoint
                if checkpoint_mgr and chunks_downloaded % 10 == 0:
                    await checkpoint_mgr.save_checkpoint(
                        bucket, key, total_bytes, object_size, local_path
                    )
        
        elapsed = time.time() - start_time
        speed_mbps = (total_bytes / elapsed) / (1024 * 1024) if elapsed > 0 else 0
        
        # Clean up checkpoint
        if checkpoint_mgr:
            await checkpoint_mgr.delete_checkpoint(bucket, key)
        
        logger.info(
            f"Downloaded {total_bytes} bytes in {elapsed:.2f}s "
            f"@ {speed_mbps:.2f} MB/s ({chunks_downloaded} chunks)"
        )
        
        return {
            "total_bytes": total_bytes,
            "elapsed_seconds": elapsed,
            "speed_mbps": speed_mbps,
            "chunks_downloaded": chunks_downloaded
        }
    
    async def download_with_ranges_parallel(
        self,
        bucket: str,
        key: str,
        local_path: str,
        max_concurrent_ranges: int = 4,
        range_size: int = 5 * 1024 * 1024  # 5MB per range
    ) -> Dict[str, Any]:
        """
        Download object using parallel range requests for maximum speed.
        
        Splits large files into multiple ranges and downloads them concurrently,
        achieving 2-4x speedup over sequential downloads.
        
        Example:
            # Download 100MB file using 4 parallel connections
            result = await client.download_with_ranges_parallel(
                "my-bucket",
                "large-file.bin",
                "/downloads/large-file.bin",
                max_concurrent_ranges=4
            )
            print(f"Downloaded in {result['elapsed_seconds']:.1f}s with {result['ranges_used']} ranges")
        
        Args:
            bucket: Bucket name
            key: Object key
            local_path: Local file path to save
            max_concurrent_ranges: Maximum parallel connections (default 4)
            range_size: Size of each range in bytes (default 5MB)
        
        Returns:
            Dict with download statistics:
                - total_bytes: Total bytes downloaded
                - elapsed_seconds: Total time
                - speed_mbps: Average speed
                - ranges_used: Number of ranges downloaded
                - speedup: Speedup vs sequential (estimated)
        
        Raises:
            ObjectNotFoundException: If object doesn't exist
            ServerException: If server doesn't support ranges
        """
        import aiofiles
        import time
        from pathlib import Path
        
        logger.info(f"Parallel range download: {bucket}/{key} (workers={max_concurrent_ranges})")
        
        # Get object size
        metadata = await self.head_object(bucket, key)
        object_size = metadata.size
        
        # Small files don't benefit from parallel downloads
        if object_size < range_size * 2:
            logger.info(f"Object too small for parallel download, using sequential")
            return await self.stream_to_file(bucket, key, local_path)
        
        # Create directory
        Path(local_path).parent.mkdir(parents=True, exist_ok=True)
        
        # Initialize range downloader
        downloader = RangeDownloader(max_concurrent_ranges, range_size)
        
        # Calculate ranges
        ranges = downloader.calculate_ranges(0, object_size - 1, range_size)
        logger.info(f"Downloading {len(ranges)} ranges in parallel")
        
        # Download function for each range
        async def download_range(range_spec: RangeSpec) -> bytes:
            return await self.get_object_range(bucket, key, range_spec.start, range_spec.end)
        
        # Download all ranges in parallel
        start_time = time.time()
        chunks = await downloader.download_ranges_parallel(ranges, download_range)
        
        # Write to file
        async with aiofiles.open(local_path, "wb") as f:
            for chunk in chunks:
                await f.write(chunk)
        
        elapsed = time.time() - start_time
        speed_mbps = (object_size / elapsed) / (1024 * 1024) if elapsed > 0 else 0
        
        # Estimate speedup (rough: min(workers, ranges) / 1)
        estimated_speedup = min(max_concurrent_ranges, len(ranges)) * 0.6  # 60% efficiency
        
        logger.info(
            f"Parallel download complete: {object_size} bytes in {elapsed:.2f}s "
            f"@ {speed_mbps:.2f} MB/s ({len(ranges)} ranges, ~{estimated_speedup:.1f}x speedup)"
        )
        
        return {
            "total_bytes": object_size,
            "elapsed_seconds": elapsed,
            "speed_mbps": speed_mbps,
            "ranges_used": len(ranges),
            "speedup": estimated_speedup
        }
    
    # Health check
    
    async def health(self) -> bool:
        """Check if the server is healthy."""
        logger.debug("Checking server health")
        try:
            await self._make_request("GET", "/api/health")
            logger.info("Server is healthy")
            return True
        except Exception as e:
            logger.warning(f"Server health check failed: {str(e)}")
            return False
    
    async def close(self) -> None:
        """Close the client and cleanup resources."""
        logger.debug("Closing OmnixClient")
        await self._http.close()
        logger.info("OmnixClient closed successfully")
    
    async def __aenter__(self) -> "OmnixClient":
        """Async context manager entry."""
        logger.debug("Entering OmnixClient context")
        return self
    
    async def __aexit__(self, exc_type: Optional[type], exc_val: Optional[Exception], exc_tb: Optional[Any]) -> None:
        """Async context manager exit."""
        logger.debug("Exiting OmnixClient context")
        if exc_val is not None:
            logger.warning(f"OmnixClient context exiting with exception: {exc_val}")
        await self.close()
